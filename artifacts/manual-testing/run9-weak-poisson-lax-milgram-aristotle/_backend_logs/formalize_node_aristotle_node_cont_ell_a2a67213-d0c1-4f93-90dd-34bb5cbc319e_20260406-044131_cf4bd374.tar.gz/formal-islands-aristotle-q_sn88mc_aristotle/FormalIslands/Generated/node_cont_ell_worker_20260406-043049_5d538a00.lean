import Mathlib

/-!
# Continuity of the linear functional ℓ via Poincaré

This file formalizes the following node from the Lax–Milgram proof tree:

> The linear functional ℓ(v) := ∫_Ω f v dx is bounded on H₀¹(Ω);
> specifically, |ℓ(v)| ≤ C_P ‖f‖_{L²(Ω)} ‖v‖_{H₀¹(Ω)}.

## Mathematical content

The proof chains two analytic estimates:
1. **Cauchy–Schwarz**: |⟪f, v⟫_{L²}| ≤ ‖f‖_{L²} · ‖v‖_{L²}
2. **Poincaré inequality**: ‖v‖_{L²} ≤ C_P · ‖v‖_{H₀¹}

to obtain |ℓ(v)| ≤ C_P · ‖f‖_{L²} · ‖v‖_{H₀¹}.

## Formalization approach

Since Mathlib does not yet provide Sobolev spaces H₀¹(Ω), we model the situation abstractly:
- `V` is a real inner product space (modeling L²(Ω))
- `H` is a real inner product space (modeling H₀¹(Ω))
- `ι : H →L[ℝ] V` is the continuous inclusion H₀¹(Ω) ↪ L²(Ω)
- The Poincaré inequality is the hypothesis `‖ι v‖ ≤ C_P * ‖v‖`
- The linear functional is `ℓ(v) = ⟪f, ι v⟫_ℝ`

This captures the full inferential content of the node: Cauchy–Schwarz is applied
to the L²-inner product, and the Poincaré inequality converts from L²-norm to H₀¹-norm.
-/

/-- **Continuity of the linear functional ℓ via Poincaré.**

Let `V` model `L²(Ω)` and `H` model `H₀¹(Ω)`, with `ι : H →L[ℝ] V` the continuous inclusion.
For `f : V` and the linear functional `ℓ(v) := ⟪f, ι v⟫_ℝ`, we have
  `|ℓ(v)| ≤ C_P * ‖f‖ * ‖v‖`
by chaining the Cauchy–Schwarz inequality with the Poincaré inequality `‖ι v‖ ≤ C_P * ‖v‖`. -/
theorem node_cont_ell_aristotle
    {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
    {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℝ H]
    (ι : H →L[ℝ] V)
    (f : V)
    (C_P : ℝ) (hC_P : 0 ≤ C_P)
    (poincare : ∀ v : H, ‖ι v‖ ≤ C_P * ‖v‖)
    (v : H) :
    |⟪f, ι v⟫_ℝ| ≤ C_P * ‖f‖ * ‖v‖ :=
  calc |⟪f, ι v⟫_ℝ|
      ≤ ‖f‖ * ‖ι v‖ := abs_inner_le_norm f (ι v)
    _ ≤ ‖f‖ * (C_P * ‖v‖) :=
        mul_le_mul_of_nonneg_left (poincare v) (norm_nonneg f)
    _ = C_P * ‖f‖ * ‖v‖ := by ring
