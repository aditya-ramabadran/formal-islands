# Summary of changes
## Completed: Continuity of the linear functional ℓ via Poincaré

I formalized the target node `node_cont_ell_aristotle` in `FormalIslands/Generated/node_cont_ell_worker_20260406-043049_5d538a00.lean`.

### Mathematical content

The theorem proves:
> |⟪f, ι v⟫_ℝ| ≤ C_P · ‖f‖ · ‖v‖

by chaining:
1. **Cauchy–Schwarz** (`abs_inner_le_norm`): |⟪f, ι v⟫| ≤ ‖f‖ · ‖ι v‖
2. **Poincaré inequality** (hypothesis): ‖ι v‖ ≤ C_P · ‖v‖

### Formalization approach

Since Mathlib does not yet have Sobolev spaces H₀¹(Ω), the theorem uses an abstract setting that faithfully captures the full inferential structure:
- `V` (real inner product space) models L²(Ω)
- `H` (real inner product space) models H₀¹(Ω)
- `ι : H →L[ℝ] V` is the continuous inclusion H₀¹ ↪ L²
- The Poincaré inequality is the hypothesis `∀ v, ‖ι v‖ ≤ C_P * ‖v‖`
- The linear functional is `ℓ(v) = ⟪f, ι v⟫_ℝ`

### Proof

The proof is a clean 3-step `calc` chain using `abs_inner_le_norm`, `mul_le_mul_of_nonneg_left`, and `ring`. No sorry, no non-standard axioms.