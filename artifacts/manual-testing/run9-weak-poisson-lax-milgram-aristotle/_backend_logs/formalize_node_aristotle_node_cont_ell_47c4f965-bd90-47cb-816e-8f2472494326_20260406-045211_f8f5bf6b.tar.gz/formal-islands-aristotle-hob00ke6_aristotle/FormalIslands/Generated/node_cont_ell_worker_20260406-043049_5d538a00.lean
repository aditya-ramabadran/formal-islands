import Mathlib

/-!
# Continuity of the linear functional ℓ via Poincaré

This file formalizes the following node from the Lax–Milgram proof tree:

> The linear functional ℓ(v) := ∫_Ω f v dx is bounded on H₀¹(Ω);
> specifically, |ℓ(v)| ≤ C_P ‖f‖_{L²(Ω)} ‖v‖_{H₀¹(Ω)}.

## Mathematical content

The proof chains two analytic estimates:
1. **Cauchy–Schwarz**: |⟪f, v⟫_{L²}| ≤ ‖f‖_{L²} · ‖v‖_{L²}
2. **Poincaré inequality**: ‖v‖_{L²} ≤ C_P · ‖v‖_{H₀¹}

to obtain |ℓ(v)| ≤ C_P · ‖f‖_{L²} · ‖v‖_{H₀¹}.

## Formalization approach

We work with the concrete L² space `MeasureTheory.Lp ℝ 2 μ` on a measure space `(Ω, μ)`.
The L² inner product `⟪f, v⟫_ℝ` on `Lp ℝ 2 μ` represents the integral `∫_Ω f v dμ`,
so the linear functional ℓ(v) = ∫_Ω f v dμ is modeled as `⟪f, v⟫_ℝ`.

Since Mathlib does not yet provide Sobolev spaces H₀¹(Ω), the H₀¹-norm of `v` is
represented by a real parameter `norm_H01_v`, and the Poincaré inequality
`‖v‖_{L²} ≤ C_P · ‖v‖_{H₀¹}` is taken as a hypothesis.

The Cauchy–Schwarz inequality is supplied by Mathlib's `abs_inner_le_norm`.
-/

open MeasureTheory

/-- **Continuity of the linear functional ℓ via Poincaré.**

For `f, v ∈ L²(Ω, μ)` and the linear functional `ℓ(v) := ⟪f, v⟫_{L²}`,
assuming the Poincaré inequality `‖v‖_{L²} ≤ C_P · ‖v‖_{H₀¹}`, we have
  `|ℓ(v)| ≤ C_P · ‖f‖_{L²} · ‖v‖_{H₀¹}`
by chaining the Cauchy–Schwarz inequality with the Poincaré inequality. -/
theorem node_cont_ell_aristotle
    {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (f v : Lp ℝ 2 μ)
    (C_P : ℝ) (hC_P : 0 ≤ C_P)
    (norm_H01_v : ℝ)
    (poincare : ‖v‖ ≤ C_P * norm_H01_v) :
    |⟪f, v⟫_ℝ| ≤ C_P * ‖f‖ * norm_H01_v :=
  calc |⟪f, v⟫_ℝ|
      ≤ ‖f‖ * ‖v‖ := abs_inner_le_norm f v
    _ ≤ ‖f‖ * (C_P * norm_H01_v) :=
        mul_le_mul_of_nonneg_left poincare (norm_nonneg f)
    _ = C_P * ‖f‖ * norm_H01_v := by ring
