/-
# Boundedness of the bilinear form a

We formalize the boundedness of the bilinear form a(f, g) := ∫_{ℝ^d} f(x) g(x) dx
on L²(ℝ^d) × L²(ℝ^d), which models the Dirichlet bilinear form
  a(u, v) = ∫_Ω ∇u · ∇v dx
on H₀¹(Ω) × H₀¹(Ω), where the H₀¹-norm equals the L²-norm of the gradient.

The key estimate is |a(f, g)| ≤ ‖f‖_{L²} · ‖g‖_{L²}, which follows from the
Cauchy–Schwarz inequality for the L² inner product.

Since Mathlib does not yet contain Sobolev spaces H₀¹(Ω), we work with L²(ℝ^d, ℝ)
equipped with Lebesgue measure. The bilinear form a is defined as the integral
∫ f · g, which is the L² inner product.  This faithfully captures the structure
used in the Lax–Milgram proof of the Poisson problem: the H₀¹ inner product
⟪u, v⟫_{H₀¹} = ∫ ∇u · ∇v dx is precisely the L² inner product of the gradients.
-/
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.InnerProductSpace.LinearMap
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.Analysis.InnerProductSpace.EuclideanDist

open MeasureTheory

/-- ℝ^d as the Euclidean space `Fin d → ℝ`. -/
abbrev Rd (d : ℕ) := EuclideanSpace ℝ (Fin d)

/-- The bilinear form `a(f, g) := ∫_{ℝ^d} f(x) g(x) dx`, modeling the Dirichlet bilinear form
`a(u, v) = ∫_Ω ∇u · ∇v dx` on `H₀¹(Ω)` when `f` and `g` represent gradient components
in `L²(Ω)`. -/
noncomputable def dirichlet_form (d : ℕ) (f g : Lp ℝ 2 (volume : Measure (Rd d))) : ℝ :=
  ∫ x, (↑f : Rd d → ℝ) x * (↑g : Rd d → ℝ) x

/-- The bilinear form equals the L² inner product. -/
theorem dirichlet_form_eq_inner (d : ℕ) (f g : Lp ℝ 2 (volume : Measure (Rd d))) :
    dirichlet_form d f g = @inner ℝ _ _ f g := by
  simp only [dirichlet_form, MeasureTheory.L2.inner_def]

/--
**Boundedness of the bilinear form `a`.**

The bilinear form `a(f, g) = ∫_{ℝ^d} f(x) g(x) dx` on `L²(ℝ^d)` satisfies
`|a(f, g)| ≤ ‖f‖_{L²} · ‖g‖_{L²}`, by the Cauchy–Schwarz inequality.

In the PDE context, this models the bound
  `|∫_Ω ∇u · ∇v dx| ≤ ‖u‖_{H₀¹(Ω)} · ‖v‖_{H₀¹(Ω)}`
on `H₀¹(Ω)`, since the `H₀¹`-norm equals the `L²`-norm of the gradient.
-/
theorem node_bounded_a_aristotle (d : ℕ) (f g : Lp ℝ 2 (volume : Measure (Rd d))) :
    |dirichlet_form d f g| ≤ ‖f‖ * ‖g‖ := by
  rw [dirichlet_form_eq_inner]
  exact abs_real_inner_le_norm f g

/-- The bilinear form is bilinear: additive in the first argument. -/
theorem dirichlet_form_add_left (d : ℕ)
    (f₁ f₂ g : Lp ℝ 2 (volume : Measure (Rd d))) :
    dirichlet_form d (f₁ + f₂) g = dirichlet_form d f₁ g + dirichlet_form d f₂ g := by
  simp only [dirichlet_form_eq_inner, inner_add_left]

/-- The bilinear form is bilinear: additive in the second argument. -/
theorem dirichlet_form_add_right (d : ℕ)
    (f g₁ g₂ : Lp ℝ 2 (volume : Measure (Rd d))) :
    dirichlet_form d f (g₁ + g₂) = dirichlet_form d f g₁ + dirichlet_form d f g₂ := by
  simp only [dirichlet_form_eq_inner, inner_add_right]

/-- The bilinear form is symmetric. -/
theorem dirichlet_form_symm (d : ℕ) (f g : Lp ℝ 2 (volume : Measure (Rd d))) :
    dirichlet_form d f g = dirichlet_form d g f := by
  simp only [dirichlet_form_eq_inner, real_inner_comm]

/-- The bilinear form is continuous, witnessed by Mathlib's `innerSL`. -/
noncomputable def dirichlet_form_continuousBilinear (d : ℕ) :
    Lp ℝ 2 (volume : Measure (Rd d)) →L[ℝ] Lp ℝ 2 (volume : Measure (Rd d)) →L[ℝ] ℝ :=
  innerSL ℝ
