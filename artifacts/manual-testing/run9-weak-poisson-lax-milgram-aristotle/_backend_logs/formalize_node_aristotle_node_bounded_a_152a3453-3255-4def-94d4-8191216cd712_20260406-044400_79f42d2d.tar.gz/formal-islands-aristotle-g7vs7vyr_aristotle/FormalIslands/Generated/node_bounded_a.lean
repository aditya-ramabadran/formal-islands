/-
# Boundedness of the bilinear form a

We formalize the boundedness of the bilinear form a(u,v) := ⟪u, v⟫ on a real inner product
space V, which models H₀¹(Ω) equipped with the gradient L²-inner product
  a(u,v) = ∫_Ω ∇u · ∇v dx.

The key estimate is  |a(u,v)| ≤ ‖u‖ · ‖v‖,  which follows from the Cauchy–Schwarz
inequality for inner product spaces.

Since Mathlib does not yet contain Sobolev spaces H₀¹(Ω), we work in the abstract
setting of a real Hilbert space (InnerProductSpace ℝ V), which faithfully captures
the structure used in the Lax–Milgram proof of the Poisson problem.
-/
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.InnerProductSpace.LinearMap

open scoped InnerProductSpace

/-
## Setting

`V` is a real inner product space, modeling H₀¹(Ω) with inner product ⟪u,v⟫ = ∫ ∇u·∇v dx.
The norm ‖u‖ corresponds to the H₀¹-seminorm (= L²-norm of the gradient).
-/
variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The bilinear form `a(u, v) := ⟪u, v⟫_ℝ`, modeling the Dirichlet form
    `∫_Ω ∇u · ∇v dx` on `H₀¹(Ω)`. -/
noncomputable def a (u v : V) : ℝ := @inner ℝ V _ u v

/--
**Boundedness of the bilinear form `a`.**

The bilinear form `a(u, v) = ⟪u, v⟫` satisfies `|a(u,v)| ≤ ‖u‖ * ‖v‖`.
This is the Cauchy–Schwarz inequality, which in the PDE context says
`|∫_Ω ∇u · ∇v dx| ≤ ‖u‖_{H₀¹} ‖v‖_{H₀¹}`.
-/
theorem node_bounded_a_aristotle (u v : V) : |a u v| ≤ ‖u‖ * ‖v‖ :=
  abs_real_inner_le_norm u v

/-- The bilinear form `a` is bilinear: linear in the first argument. -/
theorem a_add_left (u₁ u₂ v : V) : a (u₁ + u₂) v = a u₁ v + a u₂ v := by
  simp [a, inner_add_left]

/-- The bilinear form `a` is bilinear: linear in the second argument. -/
theorem a_add_right (u v₁ v₂ : V) : a u (v₁ + v₂) = a u v₁ + a u v₂ := by
  simp [a, inner_add_right]

/-- Scalar multiplication in the first argument. -/
theorem a_smul_left (c : ℝ) (u v : V) : a (c • u) v = c * a u v := by
  simp [a, real_inner_smul_left]

/-- Scalar multiplication in the second argument. -/
theorem a_smul_right (c : ℝ) (u v : V) : a u (c • v) = c * a u v := by
  simp [a, inner_smul_right]

/-- `a` is symmetric. -/
theorem a_symm (u v : V) : a u v = a v u := by
  simp [a, real_inner_comm]

/-- `a` is continuous as a bilinear map, witnessed by Mathlib's `innerSL`. -/
noncomputable def a_continuousLinearMap : V →L[ℝ] V →L[ℝ] ℝ :=
  innerSL ℝ
