import Mathlib

open MeasureTheory InnerProductSpace

/-!
# Harmonic functions minimize Dirichlet energy

We formalize the theorem that weakly harmonic functions minimize the Dirichlet energy
among competitors with the same boundary values.

The setting: given an abstract measure space (Ω, μ) and gradient fields `grad_u`, `grad_v`
taking values in a real inner product space E, the Dirichlet energy of a function is
∫ ‖∇u‖² dμ. Weak harmonicity of u means ∫ ⟨∇u, ∇φ⟩ dμ = 0 for all test functions φ.

Since v and u share boundary data, w = v - u is a valid test function, giving the
orthogonality condition ∫ ⟨∇u, ∇(v-u)⟩ dμ = 0. From this we derive:
1. The Pythagorean identity: ∫‖∇v‖² = ∫‖∇u‖² + ∫‖∇(v-u)‖²
2. The minimality: ∫‖∇u‖² ≤ ∫‖∇v‖²
-/

/-
**Dirichlet energy Pythagorean identity**: if `grad_u` and `grad_v - grad_u` are
orthogonal in the L²-sense (as guaranteed by weak harmonicity of u and the fact that
v - u ∈ H₀¹), then ∫‖grad_v‖² = ∫‖grad_u‖² + ∫‖grad_v - grad_u‖².
-/
theorem dirichlet_energy_pythagorean
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (grad_u grad_v : Ω → E)
    (hu_sq : Integrable (fun x => ‖grad_u x‖ ^ 2) μ)
    (hw_sq : Integrable (fun x => ‖grad_v x - grad_u x‖ ^ 2) μ)
    (h_cross : Integrable (fun x => ⟪grad_u x, grad_v x - grad_u x⟫_ℝ) μ)
    (h_ortho : ∫ x, ⟪grad_u x, grad_v x - grad_u x⟫_ℝ ∂μ = 0) :
    ∫ x, ‖grad_v x‖ ^ 2 ∂μ =
      ∫ x, ‖grad_u x‖ ^ 2 ∂μ + ∫ x, ‖grad_v x - grad_u x‖ ^ 2 ∂μ := by
  convert ( MeasureTheory.integral_add hu_sq ( hw_sq.add ( h_cross.const_mul 2 ) ) ) using 1;
  · congr with x ; norm_num [ @norm_sub_sq ℝ ] ; ring;
    simp +decide [ inner_sub_right, real_inner_comm ] ; ring;
  · simp +zetaDelta at *;
    rw [ MeasureTheory.integral_add hw_sq ( h_cross.const_mul 2 ), MeasureTheory.integral_const_mul, h_ortho, MulZeroClass.mul_zero, add_zero ]

/-
**Harmonic functions minimize Dirichlet energy among competitors with the same
boundary values.**

Let `grad_u` and `grad_v` be gradient fields of functions u and v on a measure space
(Ω, μ), where u is weakly harmonic and v shares the same boundary data. The orthogonality
condition `h_ortho` (∫ ⟨∇u, ∇(v-u)⟩ = 0) follows from weak harmonicity since v - u is
a valid test function (it lies in H₀¹ because u and v agree on the boundary).

Then:
- ∫‖∇v‖² = ∫‖∇u‖² + ∫‖∇(v-u)‖² (Pythagorean identity)
- ∫‖∇u‖² ≤ ∫‖∇v‖² (minimality of Dirichlet energy)
-/
theorem root_aristotle
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (grad_u grad_v : Ω → E)
    (hu_sq : Integrable (fun x => ‖grad_u x‖ ^ 2) μ)
    (hw_sq : Integrable (fun x => ‖grad_v x - grad_u x‖ ^ 2) μ)
    (h_cross : Integrable (fun x => ⟪grad_u x, grad_v x - grad_u x⟫_ℝ) μ)
    (h_ortho : ∫ x, ⟪grad_u x, grad_v x - grad_u x⟫_ℝ ∂μ = 0) :
    (∫ x, ‖grad_v x‖ ^ 2 ∂μ =
      ∫ x, ‖grad_u x‖ ^ 2 ∂μ + ∫ x, ‖grad_v x - grad_u x‖ ^ 2 ∂μ) ∧
    (∫ x, ‖grad_u x‖ ^ 2 ∂μ ≤ ∫ x, ‖grad_v x‖ ^ 2 ∂μ) := by
  refine' And.intro _ ( _ : _ ≤ _ );
  · exact dirichlet_energy_pythagorean _ _ hu_sq hw_sq h_cross h_ortho;
  · rw [ dirichlet_energy_pythagorean _ _ hu_sq hw_sq h_cross h_ortho ];
    exact le_add_of_nonneg_right ( MeasureTheory.integral_nonneg fun x => sq_nonneg _ )