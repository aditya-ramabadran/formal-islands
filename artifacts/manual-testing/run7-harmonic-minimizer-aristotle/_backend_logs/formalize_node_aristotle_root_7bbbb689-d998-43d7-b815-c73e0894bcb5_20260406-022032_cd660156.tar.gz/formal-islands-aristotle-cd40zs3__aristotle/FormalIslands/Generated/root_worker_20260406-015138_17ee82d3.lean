import Mathlib

open MeasureTheory InnerProductSpace

/-!
# Harmonic functions minimize Dirichlet energy

We formalize the theorem that weakly harmonic functions minimize the Dirichlet energy
among competitors with the same boundary values.

The setting: Ω ⊂ ℝ^d is a bounded domain. Functions u, v : Ω → ℝ have gradient fields
∇u, ∇v : Ω → ℝ^d. We represent ℝ^d as `EuclideanSpace ℝ (Fin d)` and integrate with
respect to a measure μ on ℝ^d (standing for Lebesgue measure restricted to Ω).

Weak harmonicity of u means ∫_Ω ⟨∇u, ∇φ⟩ dx = 0 for all test functions φ ∈ H₀¹(Ω).
Since v and u share boundary data g on ∂Ω, w = v - u lies in H₀¹(Ω), giving the
orthogonality condition ∫ ⟨∇u, ∇(v-u)⟩ dμ = 0.

From this we derive:
1. The Pythagorean identity: ∫|∇v|² = ∫|∇u|² + ∫|∇(v-u)|²
2. The minimality: ∫|∇u|² ≤ ∫|∇v|²
-/

noncomputable section

variable {d : ℕ}

/-
Auxiliary: the Dirichlet energy Pythagorean identity. If the gradient fields ∇u and
∇(v-u) are orthogonal in L²(Ω; ℝ^d) (as guaranteed by weak harmonicity of u and the
fact that v - u ∈ H₀¹(Ω)), then ∫_Ω |∇v|² dx = ∫_Ω |∇u|² dx + ∫_Ω |∇(v-u)|² dx.
-/
theorem dirichlet_energy_pythagorean
    (d : ℕ)
    (μ : Measure (EuclideanSpace ℝ (Fin d)))
    (grad_u grad_v : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (hu_sq : Integrable (fun x => ‖grad_u x‖ ^ 2) μ)
    (hw_sq : Integrable (fun x => ‖grad_v x - grad_u x‖ ^ 2) μ)
    (h_cross : Integrable (fun x => ⟪grad_u x, grad_v x - grad_u x⟫_ℝ) μ)
    (h_ortho : ∫ x, ⟪grad_u x, grad_v x - grad_u x⟫_ℝ ∂μ = 0) :
    ∫ x, ‖grad_v x‖ ^ 2 ∂μ =
      ∫ x, ‖grad_u x‖ ^ 2 ∂μ + ∫ x, ‖grad_v x - grad_u x‖ ^ 2 ∂μ := by
  have h_split : ∫ x, ‖grad_v x‖ ^ 2 ∂μ = (∫ x, ‖grad_u x‖ ^ 2 ∂μ) + (∫ x, ‖grad_v x - grad_u x‖ ^ 2 ∂μ) + 2 * (∫ x, ⟪grad_u x, grad_v x - grad_u x⟫_ℝ ∂μ) := by
    rw [ ← MeasureTheory.integral_const_mul, ← MeasureTheory.integral_add, ← MeasureTheory.integral_add ];
    · congr; ext x; rw [ show ‖grad_v x‖ ^ 2 = ‖grad_u x‖ ^ 2 + ‖grad_v x - grad_u x‖ ^ 2 + 2 * ⟪grad_u x, grad_v x - grad_u x⟫_ℝ by rw [ show ‖grad_v x‖ ^ 2 = ‖grad_u x + ( grad_v x - grad_u x )‖ ^ 2 by rw [ add_sub_cancel ] ] ; rw [ @norm_add_sq ℝ ] ; norm_num ; ring ] ;
    · exact hu_sq.add hw_sq;
    · exact h_cross.const_mul _;
    · exact hu_sq;
    · exact hw_sq;
  linarith

/-
**Harmonic functions minimize Dirichlet energy among competitors with the same
boundary values.**

Let u be weakly harmonic in Ω ⊂ ℝ^d with u = g on ∂Ω, and let v be any sufficiently
regular function with v = g on ∂Ω. The gradient fields ∇u, ∇v : Ω → ℝ^d are represented
as functions from `EuclideanSpace ℝ (Fin d)` to `EuclideanSpace ℝ (Fin d)`, and μ stands
for Lebesgue measure restricted to Ω.

The hypothesis `h_ortho` encodes weak harmonicity tested against the admissible variation
w = v - u ∈ H₀¹(Ω): ∫_Ω ⟨∇u, ∇(v-u)⟩ dμ = 0.

Conclusion:
• ∫_Ω |∇v|² dμ = ∫_Ω |∇u|² dμ + ∫_Ω |∇(v-u)|² dμ  (Pythagorean identity)
• ∫_Ω |∇u|² dμ ≤ ∫_Ω |∇v|² dμ                       (energy minimality)
-/
theorem root_aristotle
    (d : ℕ)
    (μ : Measure (EuclideanSpace ℝ (Fin d)))
    (grad_u grad_v : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (hu_sq : Integrable (fun x => ‖grad_u x‖ ^ 2) μ)
    (hw_sq : Integrable (fun x => ‖grad_v x - grad_u x‖ ^ 2) μ)
    (h_cross : Integrable (fun x => ⟪grad_u x, grad_v x - grad_u x⟫_ℝ) μ)
    (h_ortho : ∫ x, ⟪grad_u x, grad_v x - grad_u x⟫_ℝ ∂μ = 0) :
    (∫ x, ‖grad_v x‖ ^ 2 ∂μ =
      ∫ x, ‖grad_u x‖ ^ 2 ∂μ + ∫ x, ‖grad_v x - grad_u x‖ ^ 2 ∂μ) ∧
    (∫ x, ‖grad_u x‖ ^ 2 ∂μ ≤ ∫ x, ‖grad_v x‖ ^ 2 ∂μ) := by
  convert dirichlet_energy_pythagorean d μ grad_u grad_v hu_sq hw_sq h_cross h_ortho;
  simp +zetaDelta at *;
  exact fun h => h ▸ le_add_of_nonneg_right ( MeasureTheory.integral_nonneg fun x => sq_nonneg _ )

end