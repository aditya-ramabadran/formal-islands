/-
# Dirichlet Energy Pythagorean Identity via Weak Harmonicity

This file formalizes the Pythagorean identity for Dirichlet energy in ℝ^d:
if `u` is weakly harmonic in a bounded domain `Ω ⊂ ℝ^d` and `w = v - u ∈ H₀¹(Ω)`, then

  `∫_Ω ‖∇v‖² dx = ∫_Ω ‖∇u‖² dx + ∫_Ω ‖∇w‖² dx`

The proof expands `∇v = ∇u + ∇w` pointwise using `‖a+b‖² = ‖a‖² + 2⟨a,b⟩ + ‖b‖²`,
integrates over Ω, and applies the weak harmonicity condition (with test function `w`)
to eliminate the cross term `2∫_Ω ⟨∇u, ∇w⟩ dx`.

The formalization uses `EuclideanSpace ℝ (Fin d)` as the concrete ambient space ℝ^d.
Gradients `Du` and `Dw` are functions `ℝ^d → ℝ^d`, and integration is performed with
respect to the Lebesgue (volume) measure restricted to the domain `Ω`.
-/
import Mathlib

open MeasureTheory MeasureTheory.Measure

variable {d : ℕ}

/-- **Dirichlet Energy Pythagorean Identity in ℝ^d.**

Let `Ω ⊂ ℝ^d` be a measurable domain, and let `Du`, `Dw : ℝ^d → ℝ^d` represent the
gradients of a weakly harmonic function `u` and a perturbation `w = v - u` (where
`w ∈ H₀¹(Ω)`), respectively.

The weak harmonicity condition states that `∫_Ω ⟨∇u, ∇φ⟩ dx = 0` for every test
function `φ ∈ H₀¹(Ω)`. Taking `φ = w` yields the hypothesis
`h_harmonic : ∫_Ω ⟨Du, Dw⟩ dx = 0`.

**Conclusion:**  `∫_Ω ‖Du + Dw‖² dx = ∫_Ω ‖Du‖² dx + ∫_Ω ‖Dw‖² dx`

The proof expands `‖a + b‖² = ‖a‖² + 2⟨a,b⟩ + ‖b‖²` pointwise, integrates over Ω,
and uses the vanishing cross-term from weak harmonicity. -/
theorem energy_pythagorean_aristotle
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (Du Dw : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (hDu_sq : Integrable (fun x => ‖Du x‖ ^ 2) (volume.restrict Ω))
    (hDw_sq : Integrable (fun x => ‖Dw x‖ ^ 2) (volume.restrict Ω))
    (hcross : Integrable (fun x => @inner ℝ _ _ (Du x) (Dw x)) (volume.restrict Ω))
    (h_harmonic : ∫ x in Ω, @inner ℝ _ _ (Du x) (Dw x) = 0) :
    ∫ x in Ω, ‖Du x + Dw x‖ ^ 2 =
      ∫ x in Ω, ‖Du x‖ ^ 2 + ∫ x in Ω, ‖Dw x‖ ^ 2 := by
  have key : ∀ x, ‖Du x + Dw x‖ ^ 2 =
      ‖Du x‖ ^ 2 + 2 * @inner ℝ _ _ (Du x) (Dw x) + ‖Dw x‖ ^ 2 :=
    fun x => norm_add_sq_real _ _
  simp_rw [key]
  rw [integral_add (hDu_sq.add (hcross.const_mul 2)) hDw_sq,
      integral_add hDu_sq (hcross.const_mul 2),
      integral_const_mul, h_harmonic, mul_zero, add_zero]
