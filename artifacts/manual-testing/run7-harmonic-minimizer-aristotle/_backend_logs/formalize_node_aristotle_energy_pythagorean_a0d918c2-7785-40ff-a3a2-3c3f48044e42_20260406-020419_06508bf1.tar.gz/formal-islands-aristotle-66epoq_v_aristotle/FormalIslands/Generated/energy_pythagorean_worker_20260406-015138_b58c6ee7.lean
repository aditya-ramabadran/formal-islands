/-
# Dirichlet Energy Pythagorean Identity via Weak Harmonicity

This file formalizes the Pythagorean identity for Dirichlet energy:
if `u` is weakly harmonic and `w = v - u ∈ H₀¹(Ω)`, then

  `∫_Ω ‖∇v‖² = ∫_Ω ‖∇u‖² + ∫_Ω ‖∇w‖²`

The proof expands `∇v = ∇u + ∇w` pointwise using `‖a+b‖² = ‖a‖² + 2⟨a,b⟩ + ‖b‖²`,
integrates over Ω, and applies the weak harmonicity condition (with test function `w`)
to eliminate the cross term `2∫⟨∇u, ∇w⟩`.

The formalization works over a general measure space `(α, μ)` and a real inner product
space `F` (standing in for `ℝ^d`). The gradients `Du` and `Dw` are functions `α → F`.
-/
import Mathlib

open MeasureTheory

variable {α : Type*} [MeasurableSpace α] {μ : Measure α}
variable {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]

/-- **Dirichlet Energy Pythagorean Identity.**

In the setting of the Dirichlet energy minimization problem, let `Du` and `Dw`
represent the gradients of a weakly harmonic function `u` and a perturbation
`w = v - u` (where `w ∈ H₀¹(Ω)`), valued in a real inner product space `F`
(concretely `ℝ^d`).

The weak harmonicity condition states that `∫ ⟨∇u, ∇φ⟩ dμ = 0` for every
test function `φ ∈ H₀¹(Ω)`. Taking `φ = w` yields the hypothesis
`h_harmonic : ∫ ⟨Du, Dw⟩ dμ = 0`.

**Conclusion:**  `∫ ‖Du + Dw‖² dμ = ∫ ‖Du‖² dμ + ∫ ‖Dw‖² dμ`

The proof expands `‖a + b‖² = ‖a‖² + 2⟨a,b⟩ + ‖b‖²` pointwise,
integrates, and uses the vanishing cross-term. -/
theorem energy_pythagorean_aristotle
    (Du Dw : α → F)
    (hDu_sq : Integrable (fun x => ‖Du x‖ ^ 2) μ)
    (hDw_sq : Integrable (fun x => ‖Dw x‖ ^ 2) μ)
    (hcross : Integrable (fun x => @inner ℝ F _ (Du x) (Dw x)) μ)
    (h_harmonic : ∫ x, @inner ℝ F _ (Du x) (Dw x) ∂μ = 0) :
    ∫ x, ‖Du x + Dw x‖ ^ 2 ∂μ =
      ∫ x, ‖Du x‖ ^ 2 ∂μ + ∫ x, ‖Dw x‖ ^ 2 ∂μ := by
  simp +decide only [norm_add_sq_real]
  rw [MeasureTheory.integral_add, MeasureTheory.integral_add, MeasureTheory.integral_const_mul]
  · rw [h_harmonic, mul_zero, add_zero]
  · exact hDu_sq
  · exact hcross.const_mul _
  · exact hDu_sq.add (hcross.const_mul _)
  · exact hDw_sq
