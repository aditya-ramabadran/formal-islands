import Mathlib

/-!
# Virial Identity for the Focusing Mass-Critical NLS

This file formalizes the virial identity for the Glassey blow-up argument.

For a sufficiently regular solution of the focusing mass-critical NLS on ℝ^d:

  i∂_t u + Δu = -|u|^{4/d} u

the variance `V(t) = ∫ |x|²|u(t,x)|² dx` satisfies

  V''(t) = 8∫|∇u|² dx - (16/(2+4/d))∫|u|^{2+4/d} dx = 16 E(u(t)).

## Formalization strategy

The PDE content (two rounds of integration by parts) is encoded as a
hypothesis on `HasDerivAt V'`. The algebraic identity `8K - 16P/(2+4/d) = 16E`
is proved by `ring`. The main theorem `virial_identity_aristotle` combines
the integration-by-parts hypothesis with the algebraic identity and energy
conservation to conclude `V''(t) = 16E₀` in the sense of `HasDerivAt`.

Corollaries establish that when `E₀ < 0`, the variance (which satisfies
`V(t) ≥ 0` by definition) must become negative in finite time, proving
blow-up.
-/

noncomputable section

open Real

/-- Energy functional for the focusing mass-critical NLS with spatial dimension `d > 0`.
    `E(K, P) = K/2 - P/(2 + 4/d)`, where `K = ∫|∇u|² dx` (kinetic energy)
    and `P = ∫|u|^{2+4/d} dx` (potential energy). -/
def nlsEnergy (d : ℝ) (K P : ℝ) : ℝ :=
  K / 2 - P / (2 + 4 / d)

/-- Core algebraic identity underlying the virial identity:
    `8K - (16/(2+4/d))·P = 16·E(K,P)`.

    This connects the virial second derivative formula
    `V'' = 8∫|∇u|² - (16/(2+4/d))∫|u|^{2+4/d}`
    to `16` times the energy `E = ½∫|∇u|² - 1/(2+4/d)∫|u|^{2+4/d}`. -/
theorem virial_algebraic_identity (d : ℝ) (_hd : d > 0) (K P : ℝ) :
    8 * K - (16 / (2 + 4 / d)) * P = 16 * nlsEnergy d K P := by
  unfold nlsEnergy; ring

/-- The denominator `2 + 4/d` is positive when `d > 0`. -/
theorem nls_denom_pos (d : ℝ) (_hd : d > 0) : 2 + 4 / d > 0 := by positivity

/-- The coefficient `16/(2+4/d)` that appears in the virial identity
    equals `4d/(d+2)·4/(d) = 8d/(d+2)`. This is the natural coefficient
    from the nonlinear term after integration by parts with `div(x) = d`. -/
theorem virial_coeff_eq (d : ℝ) (hd : d > 0) :
    16 / (2 + 4 / d) = 8 * d / (d + 2) := by
  field_simp
  ring

/-- **Virial Identity** (main theorem).

For any sufficiently regular solution of the focusing mass-critical NLS on ℝ^d,
the variance `V(t) = ∫|x|²|u(t,x)|² dx` satisfies `V''(t) = 16 E₀`.

Here:
- `K(t) = ∫|∇u(t)|² dx` is the kinetic energy,
- `P(t) = ∫|u(t)|^{2+4/d} dx` is the nonlinear potential,
- `E₀` is the conserved energy.

The hypothesis `hVirial` encodes the PDE computation (two rounds of integration
by parts): the linear part gives `8∫|∇u|²` and the nonlinear part gives
`-(16/(2+4/d))∫|u|^{2+4/d}`, so that V' has derivative
`8K(t) - (16/(2+4/d))P(t)` at each time t.

The hypothesis `hE` is energy conservation: `E(K(t),P(t)) = E₀` for all t.

The theorem combines these via the algebraic identity
`8K - (16/(2+4/d))P = 16E` to conclude `HasDerivAt V' (16 * E₀) t`. -/
theorem virial_identity_aristotle
    (d : ℝ) (hd : d > 0)
    (V V' K P : ℝ → ℝ)
    (E₀ : ℝ)
    -- V' is the time derivative of V
    (_hV_diff : ∀ t, HasDerivAt V (V' t) t)
    -- Energy conservation: E(K(t), P(t)) = E₀ for all t
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    -- The virial computation from integration by parts:
    -- V''(t) = 8∫|∇u|² dx - (16/(2+4/d))∫|u|^{2+4/d} dx = 8K(t) - (16/(2+4/d))P(t)
    (hVirial : ∀ t, HasDerivAt V' (8 * K t - (16 / (2 + 4 / d)) * P t) t)
    (t : ℝ) :
    HasDerivAt V' (16 * E₀) t := by
  have h := hVirial t
  rw [virial_algebraic_identity d hd (K t) (P t), hE t] at h
  exact h

/-- The virial identity in pointwise form: V''(t) = 16E₀ for all t,
    where V'' is the second `deriv`. -/
theorem virial_identity_deriv
    (d : ℝ) (hd : d > 0)
    (V K P : ℝ → ℝ)
    (E₀ : ℝ)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    (hVirial : ∀ t, deriv (deriv V) t = 8 * K t - (16 / (2 + 4 / d)) * P t)
    (t : ℝ) :
    deriv (deriv V) t = 16 * E₀ := by
  rw [hVirial t, virial_algebraic_identity d hd, hE]

/-
Key consequence for blow-up: a quadratic `V₀ + a·t + b·t²` with `b < 0`
    and `V₀ > 0` must become negative for some `t > 0`.

    In the virial argument: since `V''(t) = 16E₀` is constant with `E₀ < 0`,
    `V` is a downward-opening parabola. Since `V(t) = ∫|x|²|u|² ≥ 0`,
    this forces finite-time blow-up.
-/
theorem quadratic_becomes_negative
    (V₀ a b : ℝ) (hV₀ : V₀ > 0) (hb : b < 0) :
    ∃ T : ℝ, T > 0 ∧ V₀ + a * T + b * T ^ 2 < 0 := by
  exact ⟨ ( |a| + V₀ + 1 ) / ( -b ) + 1, by nlinarith [ abs_nonneg a, mul_div_cancel₀ ( |a| + V₀ + 1 ) ( by linarith : ( -b ) ≠ 0 ) ], by cases abs_cases a <;> nlinarith [ mul_div_cancel₀ ( |a| + V₀ + 1 ) ( by linarith : ( -b ) ≠ 0 ) ] ⟩

/-- **Virial blow-up corollary.** If V''(t) = 16E₀ with E₀ < 0 and V(0) > 0,
    then V becomes negative in finite forward time. Since V(t) ≥ 0 by definition,
    the solution cannot exist past that time. -/
theorem virial_blowup
    (V V' : ℝ → ℝ) (E₀ : ℝ)
    (hE_neg : E₀ < 0)
    (hV₀ : V 0 > 0)
    (hV_quad : ∀ t, V t = V 0 + V' 0 * t + 8 * E₀ * t ^ 2) :
    ∃ T : ℝ, T > 0 ∧ V T < 0 := by
  have hb : 8 * E₀ < 0 := by nlinarith
  obtain ⟨T, hT_pos, hT_neg⟩ := quadratic_becomes_negative _ _ _ hV₀ hb
  exact ⟨T, hT_pos, hV_quad T ▸ hT_neg⟩

end