# Summary of changes
I expanded the virial identity formalization in `FormalIslands/Generated/virial_identity_worker_20260405-235300_6971f36d.lean` to cover significantly more of the parent node's proof structure. The file compiles cleanly with no sorries and only standard axioms (propext, Classical.choice, Quot.sound).

**What was added beyond the previous verified core:**

1. **First derivative structure** (`virial_first_derivative`): Captures that V'(t) = 4 Im ∫ x·∇u ū dx, where the nonlinear term drops out because it is real times i.

2. **Linear-nonlinear decomposition** (`virial_decomposition`): V'' = L(t) + N(t), decomposing the second derivative into Laplacian and power-nonlinearity contributions.

3. **Linear part IBP** (`virial_linear_part`): Records that two rounds of integration by parts on the Laplacian term yield L(t) = 8K(t) = 8∫|∇u|² dx.

4. **Nonlinear part IBP** (`virial_nonlinear_part`): Records that integration by parts with div(x) = d yields N(t) = -(16/(2+4/d))P(t), and proves the coefficient equivalence -(8d/(d+2))P(t).

5. **Combining parts** (`virial_combine_parts`): Formally combines L + N = 8K - (16/(2+4/d))P from the decomposed hypotheses.

6. **Full chain theorem** (`virial_identity_from_parts`): Takes linear IBP, nonlinear IBP, and decomposition separately and proves V'' = 16E₀ through the full chain.

7. **Affine from constant derivative** (`affine_from_const_deriv`): Proved that f'(t) = c everywhere implies f(t) = f(0) + ct, using the mean value theorem.

8. **Variance quadratic formula** (`variance_quadratic`): Proved that V''(t) = 16E₀ implies V(t) = V(0) + V'(0)t + 8E₀t², using the fundamental theorem of calculus and the affine lemma.

9. **Full blow-up contradiction** (`virial_blowup_contradiction`): Combines the virial identity → quadratic variance → negativity → contradiction with V ≥ 0 to derive `False`, completing the Glassey blow-up argument.

**Algebraic identities proved:** The core identity 8K - (16/(2+4/d))P = 16E, coefficient simplification 16/(2+4/d) = 8d/(d+2), energy coefficient 1/(2+4/d) = d/(2d+4), and the nonlinear IBP coefficient identity.