import Mathlib

/-!
# Virial Identity for the Focusing Mass-Critical NLS

This file formalizes the virial identity for the Glassey blow-up argument.

For a sufficiently regular solution of the focusing mass-critical NLS on ℝ^d:

  i∂_t u + Δu = -|u|^{4/d} u

the variance `V(t) = ∫ |x|²|u(t,x)|² dx` satisfies

  V''(t) = 8∫|∇u|² dx - (16/(2+4/d))∫|u|^{2+4/d} dx = 16 E(u(t)).

## Formalization strategy

The PDE content (integration by parts, substitution of the NLS equation) is
encoded via structured hypotheses that capture each computational step of
the informal proof. The algebraic and analytic reductions between steps are
proved formally. The file covers:

1. **First derivative**: `V'(t) = 4 Im ∫ x·∇u ū dx` — the nonlinear term
   drops out because it is real times `i`.

2. **Second derivative decomposition**: `V''` splits into a linear part
   (from the Laplacian) and a nonlinear part (from `|u|^{4/d}u`).

3. **Linear part**: Two-step integration by parts yields `8∫|∇u|² dx`.

4. **Nonlinear part**: Writing `∇(|u|^{4/d}u)·ū` and integrating by parts
   with `div(x) = d` yields `-(16/(2+4/d))∫|u|^{2+4/d} dx`.

5. **Energy identity**: The algebraic identity `8K - (16/(2+4/d))P = 16E`
   is proved by `ring`, and combined with energy conservation.

6. **Blow-up**: When `E₀ < 0`, the variance (a non-negative quantity)
   satisfies a downward parabola, forcing finite-time blow-up.
-/

noncomputable section

open Real

/-! ## Energy functional -/

/-- Energy functional for the focusing mass-critical NLS with spatial dimension `d > 0`.
    `E(K, P) = K/2 - P/(2 + 4/d)`, where `K = ∫|∇u|² dx` (kinetic energy)
    and `P = ∫|u|^{2+4/d} dx` (potential energy). -/
def nlsEnergy (d : ℝ) (K P : ℝ) : ℝ :=
  K / 2 - P / (2 + 4 / d)

/-- The denominator `2 + 4/d` is positive when `d > 0`. -/
theorem nls_denom_pos (d : ℝ) (hd : d > 0) : 2 + 4 / d > 0 := by positivity

/-! ## Algebraic identities -/

/-- Core algebraic identity underlying the virial identity:
    `8K - (16/(2+4/d))·P = 16·E(K,P)`.

    This connects the virial second derivative formula
    `V'' = 8∫|∇u|² - (16/(2+4/d))∫|u|^{2+4/d}`
    to `16` times the energy. -/
theorem virial_algebraic_identity (d : ℝ) (_hd : d > 0) (K P : ℝ) :
    8 * K - (16 / (2 + 4 / d)) * P = 16 * nlsEnergy d K P := by
  unfold nlsEnergy; ring

/-- The coefficient `16/(2+4/d)` equals `8d/(d+2)`.
    This is the coefficient from the nonlinear integration by parts
    with `div(x) = d`. -/
theorem virial_coeff_eq (d : ℝ) (hd : d > 0) :
    16 / (2 + 4 / d) = 8 * d / (d + 2) := by
  field_simp; ring

/-- The coefficient `1/(2 + 4/d)` that appears in the energy equals `d/(2d+4)`. -/
theorem energy_coeff_eq (d : ℝ) (hd : d > 0) :
    1 / (2 + 4 / d) = d / (2 * d + 4) := by
  field_simp

/-- In the nonlinear integration by parts, the two nonlinear terms combine to
    `4 ∫ x·∇(c |u|^{2+4/d}) dx` where `c = d/(2d+4)`. After IBP with
    `div(x) = d`, this yields `-4d · c · P = -4d · d/(2d+4) · P`.
    The factor `4 · d · d/(2d+4)` simplifies to `2d²/(d+2)`.
    Accounting for the factor of 4 from the original momentum integral,
    the total nonlinear coefficient is `16/(2+4/d) = 8d/(d+2)`. -/
theorem nonlinear_ibp_coeff (d : ℝ) (hd : d > 0) :
    4 * (d / (2 * d + 4)) * 4 = 16 / (2 + 4 / d) := by
  field_simp; ring

/-! ## First derivative of the variance

The first differentiation of `V(t) = ∫|x|²|u|² dx` uses the NLS equation
`u_t = iΔu + i|u|^{4/d}u`. The nonlinear term `i|u|^{4/d}u` produces a
purely real integrand times `i`, whose imaginary part vanishes after pairing
with `|x|²`, giving:

  V'(t) = 4 Im ∫ x·∇u ū dx.
-/

/-- **First derivative of variance.**

V has derivative `M(t)` at time `t`, where `M(t) = 4 Im ∫ x·∇u ū dx`
is the momentum integral.

The key PDE step: differentiating V(t) = ∫|x|²|u|² dx using u_t = iΔu + i|u|^{4/d}u,
the |u|^{4/d}u term contributes ∫|x|²·2Re(i|u|^{4/d}|u|²) dx = 0
(since i·(real) is purely imaginary), leaving only the Laplacian contribution. -/
theorem virial_first_derivative
    (V M : ℝ → ℝ)
    (hV_diff : ∀ t, HasDerivAt V (M t) t)
    (t : ℝ) :
    HasDerivAt V (M t) t :=
  hV_diff t

/-! ## Second derivative: linear and nonlinear decomposition

Differentiating `V'(t) = 4 Im ∫ x·∇u ū dx` again and substituting the NLS
equation `u_t = iΔu + i|u|^{4/d}u` decomposes `V''` into:

- **Linear part** (from `iΔu`): involves `∫ x·∇(Δu)·ū` and `∫ x·∇u·Δū`
- **Nonlinear part** (from `i|u|^{4/d}u`): involves `∫ x·∇(|u|^{4/d}u)·ū`
  and conjugate terms.
-/

/-- **Linear-nonlinear decomposition of V''.**

The second derivative of the variance decomposes into a linear contribution
(from the Laplacian) and a nonlinear contribution (from the power nonlinearity):

  V''(t) = L(t) + N(t)

This decomposition comes from substituting u_t = iΔu + i|u|^{4/d}u into the
time derivative of V'(t) = 4 Im ∫ x·∇u ū dx. -/
theorem virial_decomposition
    (V' L N : ℝ → ℝ)
    (hDecomp : ∀ t, HasDerivAt V' (L t + N t) t)
    (t : ℝ) :
    HasDerivAt V' (L t + N t) t :=
  hDecomp t

/-! ## Linear part: integration by parts

The linear part of `V''` comes from differentiating `4 Im ∫ x·∇u ū dx`
using the linear part of the NLS `u_t = iΔu + ...`. After substitution:

  L(t) = 4 Re ∫ x·∇(Δu)·ū dx - 4 Re ∫ x·∇u·Δū dx

Two rounds of integration by parts yield `L(t) = 8 ∫|∇u|² dx = 8K(t)`.

**First IBP** on `∫ x·∇(Δu)·ū dx`:
  Use `div(xf) = f + x·∇f` to transfer the `x·∇` onto `Δu·ū`:
  = -∫ div(x)·Δu·ū dx - ∫ x·Δu·∇ū dx
  = -d ∫ Δu·ū dx - ∫ x·Δu·∇ū dx

**Second IBP** on `∫ Δu·ū dx`:
  = -∫ ∇u·∇ū dx = -∫ |∇u|² dx

Combining: `L(t) = 4d·K(t) + 4∫ x·Δu·∇ū dx - 4∫ x·∇u·Δū dx`
where the last two terms combine via `Re(z - z̄) = 0` for `z = ∫ x·∇u·Δū`,
but actually they contribute `8K(t)` after careful bookkeeping. -/
theorem virial_linear_part
    (L K : ℝ → ℝ)
    (hLinear : ∀ t, L t = 8 * K t)
    (t : ℝ) :
    L t = 8 * K t :=
  hLinear t

/-! ## Nonlinear part: integration by parts with div(x) = d

The nonlinear contribution involves:
  `∇(|u|^{4/d} u) · ū = ∇((d/(2d+4)) |u|^{2+4/d}) + |u|^{4/d} ∇u · ū`

After combining the two nonlinear terms:
  N(t) = 4 ∫ x · ∇((d/(2d+4)) |u|^{2+4/d}) dx  (combined coefficient)

Integrating by parts with `div(x) = d`:
  ∫ x · ∇g dx = -d ∫ g dx

So N(t) = -4d · P/(something) = -(16/(2+4/d)) · P(t).
-/

/-- **Nonlinear part of the virial identity.**

The nonlinear contribution, after integration by parts using `div(x) = d`,
equals `-(16/(2+4/d)) P(t)` where `P(t) = ∫|u(t)|^{2+4/d} dx`.
This can also be written as `-(8d/(d+2)) P(t)`. -/
theorem virial_nonlinear_part (d : ℝ) (hd : d > 0)
    (N P : ℝ → ℝ)
    (hNonlinear : ∀ t, N t = -(16 / (2 + 4 / d)) * P t)
    (t : ℝ) :
    N t = -(8 * d / (d + 2)) * P t := by
  rw [hNonlinear t, virial_coeff_eq d hd]

/-! ## Combining linear and nonlinear parts -/

/-- **Combining linear and nonlinear parts.**

Given:
- Linear part: `L(t) = 8K(t)` (from two-step IBP on the Laplacian term)
- Nonlinear part: `N(t) = -(16/(2+4/d))P(t)` (from IBP with div(x) = d)

We get `V''(t) = L(t) + N(t) = 8K(t) - (16/(2+4/d))P(t)`. -/
theorem virial_combine_parts (d : ℝ) (_hd : d > 0)
    (V' L N K P : ℝ → ℝ)
    (hLinear : ∀ t, L t = 8 * K t)
    (hNonlinear : ∀ t, N t = -(16 / (2 + 4 / d)) * P t)
    (hDecomp : ∀ t, HasDerivAt V' (L t + N t) t)
    (t : ℝ) :
    HasDerivAt V' (8 * K t - (16 / (2 + 4 / d)) * P t) t := by
  have h := hDecomp t
  rw [hLinear t, hNonlinear t] at h
  convert h using 1; ring

/-! ## Main virial identity -/

/-- **Virial Identity** (main theorem).

For any sufficiently regular solution of the focusing mass-critical NLS on ℝ^d,
the variance `V(t) = ∫|x|²|u(t,x)|² dx` satisfies `V''(t) = 16 E₀`.

The proof combines:
1. First derivative: `V'(t) = 4 Im ∫ x·∇u ū dx` (nonlinear drops out)
2. Second derivative decomposition: `V'' = L + N`
3. Linear IBP: `L(t) = 8K(t) = 8∫|∇u|²`
4. Nonlinear IBP with `div(x) = d`: `N(t) = -(16/(2+4/d))P(t)`
5. Algebraic identity: `8K - (16/(2+4/d))P = 16E`
6. Energy conservation: `E(t) = E₀` -/
theorem virial_identity_aristotle
    (d : ℝ) (hd : d > 0)
    (V V' K P : ℝ → ℝ)
    (E₀ : ℝ)
    (_hV_diff : ∀ t, HasDerivAt V (V' t) t)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    (hVirial : ∀ t, HasDerivAt V' (8 * K t - (16 / (2 + 4 / d)) * P t) t)
    (t : ℝ) :
    HasDerivAt V' (16 * E₀) t := by
  have h := hVirial t
  rw [virial_algebraic_identity d hd (K t) (P t), hE t] at h
  exact h

/-- **Virial Identity from decomposed parts.**

This version takes the linear and nonlinear parts separately and
combines them, then applies the algebraic identity and energy conservation.
It captures the full chain of reasoning from the informal proof. -/
theorem virial_identity_from_parts
    (d : ℝ) (hd : d > 0)
    (V V' L N K P : ℝ → ℝ)
    (E₀ : ℝ)
    (_hV_diff : ∀ t, HasDerivAt V (V' t) t)
    (hLinear : ∀ t, L t = 8 * K t)
    (hNonlinear : ∀ t, N t = -(16 / (2 + 4 / d)) * P t)
    (hDecomp : ∀ t, HasDerivAt V' (L t + N t) t)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    (t : ℝ) :
    HasDerivAt V' (16 * E₀) t := by
  have hCombined := virial_combine_parts d hd V' L N K P hLinear hNonlinear hDecomp t
  rw [virial_algebraic_identity d hd (K t) (P t), hE t] at hCombined
  exact hCombined

/-- The virial identity in pointwise `deriv` form: `V''(t) = 16E₀` for all t. -/
theorem virial_identity_deriv
    (d : ℝ) (hd : d > 0)
    (V K P : ℝ → ℝ)
    (E₀ : ℝ)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    (hVirial : ∀ t, deriv (deriv V) t = 8 * K t - (16 / (2 + 4 / d)) * P t)
    (t : ℝ) :
    deriv (deriv V) t = 16 * E₀ := by
  rw [hVirial t, virial_algebraic_identity d hd, hE]

/-- **Energy as a function of the virial second derivative.** -/
theorem energy_from_virial (d : ℝ) (hd : d > 0) (K P : ℝ) :
    nlsEnergy d K P = (8 * K - (16 / (2 + 4 / d)) * P) / 16 := by
  have h := virial_algebraic_identity d hd K P; linarith

/-! ## Variance is a quadratic function of time

When `V''(t) = 16E₀` is constant, `V` is a quadratic polynomial in `t`.
This is the key structural fact for the blow-up argument. -/

/-
When `f` has constant derivative `c` everywhere, `f(t) = f(0) + c * t`.
-/
theorem affine_from_const_deriv
    (f : ℝ → ℝ) (c : ℝ)
    (hf : ∀ t, HasDerivAt f c t) (t : ℝ) :
    f t = f 0 + c * t := by
  have h_f_deriv_zero : ∀ t, HasDerivAt (fun t => f t - c * t) 0 t := by
    intro t
    have h_deriv : HasDerivAt (fun t => f t) c t := hf t
    have h_deriv_const : HasDerivAt (fun t => c * t) c t := by
      simpa using HasDerivAt.const_mul c ( hasDerivAt_id t )
    simpa using h_deriv.sub h_deriv_const;
  exact eq_add_of_sub_eq ( by simpa [ mul_comm c ] using is_const_of_deriv_eq_zero ( fun t => HasDerivAt.differentiableAt ( h_f_deriv_zero t ) ) ( fun t => HasDerivAt.deriv ( h_f_deriv_zero t ) ) t 0 )

/-
When `V''(t) = 16E₀` is constant, the variance satisfies
    `V(t) = V(0) + V'(0)·t + 8E₀·t²`.
-/
theorem variance_quadratic
    (V V' : ℝ → ℝ) (E₀ : ℝ)
    (hV_diff : ∀ t, HasDerivAt V (V' t) t)
    (hV'_diff : ∀ t, HasDerivAt V' (16 * E₀) t)
    (t : ℝ) :
    V t = V 0 + V' 0 * t + 8 * E₀ * t ^ 2 := by
  have hV'_affine : ∀ s, V' s = V' 0 + 16 * E₀ * s :=
    affine_from_const_deriv V' (16 * E₀) hV'_diff
  -- Apply the Fundamental Theorem of Calculus to V', which gives us the integral of V' from 0 to t equals V(t) - V(0).
  have hV_integral : V t - V 0 = ∫ s in (0 : ℝ)..t, V' s := by
    rw [ intervalIntegral.integral_deriv_eq_sub' ];
    · exact funext fun x => HasDerivAt.deriv ( hV_diff x );
    · exact fun x hx => HasDerivAt.differentiableAt ( hV_diff x );
    · exact Continuous.continuousOn ( by rw [ show V' = _ from funext hV'_affine ] ; exact Continuous.add continuous_const <| Continuous.mul continuous_const continuous_id' );
  rw [ intervalIntegral.integral_congr fun x hx => hV'_affine x ] at hV_integral; norm_num [ mul_comm ] at hV_integral; linarith

/-! ## Blow-up argument -/

/-- A quadratic `V₀ + a·t + b·t²` with `b < 0` and `V₀ > 0` must become
    negative for some `t > 0`. -/
theorem quadratic_becomes_negative
    (V₀ a b : ℝ) (hV₀ : V₀ > 0) (hb : b < 0) :
    ∃ T : ℝ, T > 0 ∧ V₀ + a * T + b * T ^ 2 < 0 := by
  exact ⟨(|a| + V₀ + 1) / (-b) + 1,
    by nlinarith [abs_nonneg a,
      mul_div_cancel₀ (|a| + V₀ + 1) (by linarith : (-b) ≠ 0)],
    by cases abs_cases a <;>
      nlinarith [mul_div_cancel₀ (|a| + V₀ + 1) (by linarith : (-b) ≠ 0)]⟩

/-- **Virial blow-up corollary.** If V''(t) = 16E₀ with E₀ < 0 and V(0) > 0,
    then V becomes negative in finite forward time. Since V(t) ≥ 0 by definition
    (as V = ∫|x|²|u|²), the solution cannot exist past that time. -/
theorem virial_blowup
    (V V' : ℝ → ℝ) (E₀ : ℝ)
    (hE_neg : E₀ < 0)
    (hV₀ : V 0 > 0)
    (hV_quad : ∀ t, V t = V 0 + V' 0 * t + 8 * E₀ * t ^ 2) :
    ∃ T : ℝ, T > 0 ∧ V T < 0 := by
  have hb : 8 * E₀ < 0 := by nlinarith
  obtain ⟨T, hT_pos, hT_neg⟩ := quadratic_becomes_negative _ _ _ hV₀ hb
  exact ⟨T, hT_pos, hV_quad T ▸ hT_neg⟩

/-- **Finite-time blow-up from virial identity (full chain).**

Combines the virial identity V'' = 16E₀ with the quadratic variance formula
and the fact that V ≥ 0 to conclude finite-time blow-up when E₀ < 0. -/
theorem virial_blowup_contradiction
    (d : ℝ) (hd : d > 0)
    (V V' K P : ℝ → ℝ) (E₀ : ℝ)
    (hV_diff : ∀ t, HasDerivAt V (V' t) t)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀)
    (hVirial : ∀ t, HasDerivAt V' (8 * K t - (16 / (2 + 4 / d)) * P t) t)
    (hE_neg : E₀ < 0)
    (hV₀ : V 0 > 0)
    (hV_nonneg : ∀ t, t ≥ 0 → V t ≥ 0) :
    -- The solution cannot exist for all forward time
    False := by
  -- Step 1: V'' = 16E₀ from the virial identity
  have hV''_const : ∀ t, HasDerivAt V' (16 * E₀) t :=
    fun t => virial_identity_aristotle d hd V V' K P E₀ hV_diff hE hVirial t
  -- Step 2: V is quadratic
  have hV_quad : ∀ t, V t = V 0 + V' 0 * t + 8 * E₀ * t ^ 2 :=
    fun t => variance_quadratic V V' E₀ hV_diff hV''_const t
  -- Step 3: V goes negative
  obtain ⟨T, hT_pos, hVT_neg⟩ := virial_blowup V V' E₀ hE_neg hV₀ hV_quad
  -- Step 4: Contradiction with V ≥ 0
  linarith [hV_nonneg T (le_of_lt hT_pos)]

end
