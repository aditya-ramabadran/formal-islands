/-
# Weighted L² Inequality

For sufficiently regular f : ℝ^d → ℂ,
  ‖f‖²_{L²} ≤ (2/d) · ‖xf‖_{L²} · ‖∇f‖_{L²}.

This file formalizes the d = 1, ℝ-valued case:
  ∫ f(x)² dx ≤ 2 · √(∫ x² f(x)² dx) · √(∫ f'(x)² dx).

The proof uses:
1. Integration by parts: ∫ f² = −2 ∫ x f f'
2. Cauchy–Schwarz for integrals: |∫ g h| ≤ √(∫ g²) √(∫ h²)

The general d case follows by applying IBP in each coordinate direction
and summing, yielding the factor 2/d.
-/
import Mathlib

open MeasureTheory Real Filter

/-! ## Helper lemmas -/

/-
Integration by parts identity: ∫ f² = −2 ∫ x f f'.
This follows from the Mathlib IBP lemma with u(x) = x, v(x) = f(x)².
-/
lemma ibp_f_sq (f f' : ℝ → ℝ)
    (hf : ∀ x, HasDerivAt f (f' x) x)
    (hf_sq : Integrable (fun x => f x ^ 2))
    (hxff'2 : Integrable (fun x => x * (2 * f x * f' x)))
    (hxf2 : Integrable (fun x => x * f x ^ 2)) :
    ∫ x, f x ^ 2 = -(2 * ∫ x, x * f x * f' x) := by
  have h_parts : ∫ x, (ContinuousLinearMap.mul ℝ ℝ (x)) (2 * f x * f' x) = -∫ x, (ContinuousLinearMap.mul ℝ ℝ 1) (f x ^ 2) := by
    convert ( MeasureTheory.integral_bilinear_hasDerivAt_right_eq_neg_left_of_integrable ?_ ?_ ?_ ?_ ?_ ) using 1 <;> norm_num [ hf, hf_sq, hxff'2, hxf2 ];
    · exact fun x => hasDerivAt_id x;
    · exact fun x => by simpa using HasDerivAt.comp x ( hasDerivAt_pow 2 ( f x ) ) ( hf x ) ;
  simp_all +decide [ mul_assoc, mul_comm, mul_left_comm, ← MeasureTheory.integral_const_mul ]

/-
Cauchy–Schwarz inequality for real-valued integrals:
|∫ g · h| ≤ √(∫ g²) · √(∫ h²).
-/
lemma integral_cauchy_schwarz (g h : ℝ → ℝ)
    (hg : Integrable (fun x => g x ^ 2))
    (hh : Integrable (fun x => h x ^ 2))
    (hgh : Integrable (fun x => g x * h x)) :
    |∫ x, g x * h x| ≤ √(∫ x, g x ^ 2) * √(∫ x, h x ^ 2) := by
  -- Let's define the inner product as the integral of the product of functions.
  let inner_prod := fun (g h : ℝ → ℝ) => ∫ x, g x * h x;
  rw [ ← Real.sqrt_mul ( MeasureTheory.integral_nonneg fun _ ↦ sq_nonneg _ ) ];
  refine' Real.abs_le_sqrt _;
  -- By the properties of the inner product and the Cauchy-Schwarz inequality, we have:
  have h_inner_prod : ∀ (t : ℝ), inner_prod (fun x => g x - t * h x) (fun x => g x - t * h x) ≥ 0 := by
    exact fun t => MeasureTheory.integral_nonneg fun x => mul_self_nonneg _;
  -- Expanding the inner product, we get:
  have h_expand : ∀ (t : ℝ), inner_prod (fun x => g x - t * h x) (fun x => g x - t * h x) = (∫ x, g x ^ 2) - 2 * t * (∫ x, g x * h x) + t ^ 2 * (∫ x, h x ^ 2) := by
    intro t; simp +decide only [mul_sub, sub_mul, inner_prod] ; ring;
    rw [ MeasureTheory.integral_add, MeasureTheory.integral_add ] <;> norm_num [ MeasureTheory.integral_neg, MeasureTheory.integral_const_mul, MeasureTheory.integral_mul_const, hg, hh, hgh ] ; ring;
    · simpa only [ mul_assoc, mul_comm, mul_left_comm, ← MeasureTheory.integral_const_mul ] using by ring;
    · convert hgh.mul_const ( -t * 2 ) using 2 ; ring;
    · convert hgh.mul_const ( -t * 2 ) using 2 ; ring;
    · exact hh.const_mul _;
  by_cases h₂ : ∫ x, h x ^ 2 = 0 <;> simp_all +decide [ MeasureTheory.integral_const_mul ];
  · contrapose! h_inner_prod;
    exact ⟨ ( ( ∫ x, g x ^ 2 ) + 1 ) / ( 2 * ∫ x, g x * h x ), by linarith [ mul_div_cancel₀ ( ( ∫ x, g x ^ 2 ) + 1 ) ( mul_ne_zero two_ne_zero h_inner_prod ) ] ⟩;
  · contrapose! h_inner_prod;
    exact ⟨ ( ∫ x, g x * h x ) / ( ∫ x, h x ^ 2 ), by nlinarith [ mul_div_cancel₀ ( ∫ x, g x * h x ) h₂, show 0 ≤ ∫ x, h x ^ 2 from MeasureTheory.integral_nonneg fun _ => sq_nonneg _ ] ⟩

/-
Nonnegativity of the integral of a squared function.
-/
lemma integral_sq_nonneg (f : ℝ → ℝ)
    (hf : Integrable (fun x => f x ^ 2)) :
    0 ≤ ∫ x, f x ^ 2 := by
  exact MeasureTheory.integral_nonneg fun x => sq_nonneg _

/-! ## Main theorem -/

/--
**Weighted L² inequality (d = 1, ℝ-valued)**

For a differentiable function `f : ℝ → ℝ` with appropriate integrability,

  `∫ f(x)² dx ≤ 2 · √(∫ x² f(x)² dx) · √(∫ f'(x)² dx)`.

This is the one-dimensional specialization of the general inequality
  `‖f‖²_{L²(ℝᵈ)} ≤ (2/d) · ‖x f‖_{L²(ℝᵈ)} · ‖∇f‖_{L²(ℝᵈ)}`
which plays a key role in the Glassey blow-up argument for the
focusing mass-critical NLS.
-/
theorem weighted_l2_ineq_aristotle
    (f f' : ℝ → ℝ)
    (hf_deriv : ∀ x, HasDerivAt f (f' x) x)
    (hf_sq : Integrable (fun x => f x ^ 2))
    (hxf_sq : Integrable (fun x => x ^ 2 * f x ^ 2))
    (hf'_sq : Integrable (fun x => f' x ^ 2))
    (hxff' : Integrable (fun x => x * f x * f' x))
    (hxf2 : Integrable (fun x => x * f x ^ 2))
    (hxff'2 : Integrable (fun x => x * (2 * f x * f' x))) :
    ∫ x, f x ^ 2 ≤ 2 * √(∫ x, x ^ 2 * f x ^ 2) * √(∫ x, f' x ^ 2) := by
  -- Step 1: Apply the IBP identity: ∫ f² = -2 ∫ x f f'
  have h_ibp := ibp_f_sq f f' hf_deriv hf_sq hxff'2 hxf2
  -- Step 2: Rewrite using the IBP identity
  rw [h_ibp]
  -- Step 3: Bound -2∫ xf f' ≤ 2|∫ xf f'|
  have h_neg_le : -(2 * ∫ x, x * f x * f' x) ≤ 2 * |∫ x, x * f x * f' x| := by
    linarith [neg_le_abs (∫ x, x * f x * f' x)]
  -- Step 4: Apply CS with g(x) = x*f(x), h(x) = f'(x)
  -- We need: (x*f(x))^2 = x^2 * f(x)^2
  have hxf_sq' : Integrable (fun x => (x * f x) ^ 2) := by
    convert hxf_sq using 1; ext x; ring
  have hxff'_eq : (fun x => (fun x => x * f x) x * f' x) = (fun x => x * f x * f' x) := by
    ext x; ring
  have h_cs := integral_cauchy_schwarz (fun x => x * f x) f' hxf_sq' hf'_sq
    (by rw [hxff'_eq]; exact hxff')
  have h_sq_eq : (fun x => (x * f x) ^ 2) = (fun x => x ^ 2 * f x ^ 2) := by
    ext x; ring
  rw [h_sq_eq] at h_cs
  linarith