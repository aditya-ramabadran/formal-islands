import Mathlib

/-!
# Virial Identity for the Focusing Mass-Critical NLS

This file formalizes the virial identity and its consequences for the Glassey
blow-up argument. The virial identity states that for a sufficiently regular
solution of the focusing mass-critical NLS on ℝ^d, the variance
V(t) = ∫ |x|²|u(t,x)|² dx satisfies

  V''(t) = 8∫|∇u|² dx - (16/(2+4/d))∫|u|^{2+4/d} dx = 16 E(u(t)).

The PDE content (differentiating V and integrating by parts) is encoded via
hypotheses on the second derivative of V. The algebraic identity
8K - (16/(2+4/d))P = 16E and the finite-time blow-up consequence (a downward
parabola V₀ + V₀'t + 8E₀t² with E₀ < 0 must become negative) are proved.
-/

noncomputable section

open Real

/-- Energy functional for the focusing mass-critical NLS with spatial dimension `d > 0`.
    `E(K, P) = K/2 - P/(2 + 4/d)`, where `K = ∫|∇u|² dx` (kinetic energy)
    and `P = ∫|u|^{2+4/d} dx` (potential energy). -/
def nlsEnergy (d : ℝ) (K P : ℝ) : ℝ :=
  K / 2 - P / (2 + 4 / d)

/-- Core algebraic identity underlying the virial identity:
    `8K - (16/(2+4/d))·P = 16·E(K,P)`.
    This connects the virial second derivative `V'' = 8K - (16/(2+4/d))P`
    to the energy `E = K/2 - P/(2+4/d)`. -/
theorem virial_algebraic_identity (d : ℝ) (_hd : d > 0) (K P : ℝ) :
    8 * K - (16 / (2 + 4 / d)) * P = 16 * nlsEnergy d K P := by
  unfold nlsEnergy; ring

/-- Abstract virial identity with energy conservation: given that the virial
    second derivative equals `8K - (16/(2+4/d))P` and that energy is conserved,
    we conclude `V'' = 16E₀` for all time. -/
theorem virial_equals_16E
    (d : ℝ) (hd : d > 0)
    (K P : ℝ → ℝ) (E₀ : ℝ)
    (hE : ∀ t, nlsEnergy d (K t) (P t) = E₀) (t : ℝ) :
    8 * K t - (16 / (2 + 4 / d)) * P t = 16 * E₀ := by
  rw [virial_algebraic_identity d hd, hE]

/-- Key consequence for blow-up: a quadratic `V₀ + a·t + b·t²` with `b < 0`
    and `V₀ > 0` must become negative for some `t > 0`. In the virial argument,
    `b = 8E₀ < 0` (since `V'' = 16E₀` and `E₀ < 0`, so V is a downward parabola).
    Since `V(t) = ∫|x|²|u|² ≥ 0`, this forces finite-time blow-up. -/
theorem quadratic_becomes_negative
    (V₀ a b : ℝ) (hV₀ : V₀ > 0) (hb : b < 0) :
    ∃ T : ℝ, T > 0 ∧ V₀ + a * T + b * T ^ 2 < 0 := by
  exact ⟨(|a| + V₀ + 1) / (-b) + 1,
    by nlinarith [abs_nonneg a,
      mul_div_cancel₀ (|a| + V₀ + 1) (by linarith : (-b) ≠ 0)],
    by cases abs_cases a <;>
      nlinarith [mul_div_cancel₀ (|a| + V₀ + 1) (by linarith : (-b) ≠ 0)]⟩

/-- **Virial identity blow-up theorem.** Combining the algebraic identity with
    energy conservation and the blow-up consequence: if the variance `V(t)` of a
    sufficiently regular NLS solution satisfies `V'' = 8K(t) - (16/(2+4/d))P(t)`
    (the virial identity from integration by parts), energy is conserved with
    `E₀ < 0`, and `V(0) > 0`, then `V` must become negative at some future
    time `T > 0`.

    Since `V(t) = ∫|x|²|u(t,x)|²dx ≥ 0`, this contradicts the solution
    existing past time `T`, establishing finite-time blow-up.

    The hypothesis `hV_quad` encodes the PDE content: two rounds of integration
    by parts show `V'' = 16E₀` (constant by energy conservation), making `V`
    exactly quadratic. The algebraic reduction and blow-up conclusion are proved. -/
theorem virial_identity_aristotle
    (d : ℝ) (_hd : d > 0)
    (V : ℝ → ℝ)
    (_K _P : ℝ → ℝ)
    (E₀ : ℝ)
    (_hE : ∀ t, nlsEnergy d (_K t) (_P t) = E₀)
    (hE_neg : E₀ < 0)
    (hV₀ : V 0 > 0)
    (V₀' : ℝ)
    (hV_quad : ∀ t, V t = V 0 + V₀' * t + 8 * E₀ * t ^ 2) :
    ∃ T : ℝ, T > 0 ∧ V T < 0 := by
  have hb : 8 * E₀ < 0 := mul_neg_of_pos_of_neg (by norm_num : (8:ℝ) > 0) hE_neg
  obtain ⟨T, hT_pos, hT_neg⟩ := quadratic_becomes_negative _ _ _ hV₀ hb
  exact ⟨T, hT_pos, hV_quad T ▸ hT_neg⟩

end
