# Summary of changes
Successfully formalized the virial identity for the focusing mass-critical NLS in `FormalIslands/Generated/virial_identity_worker_20260405-235300_6971f36d.lean`.

The file contains four sorry-free, fully verified theorems:

1. **`nlsEnergy`** — Definition of the NLS energy functional E(K,P) = K/2 - P/(2+4/d), parameterized by spatial dimension d > 0, kinetic energy K = ∫|∇u|², and potential energy P = ∫|u|^{2+4/d}.

2. **`virial_algebraic_identity`** — The core algebraic identity: 8K - (16/(2+4/d))·P = 16·E(K,P). This is the algebraic backbone connecting the virial second derivative to the energy.

3. **`virial_equals_16E`** — With energy conservation (E(t) = E₀ for all t), the virial expression equals 16E₀ at all times.

4. **`quadratic_becomes_negative`** — A downward-opening quadratic V₀ + at + bt² with b < 0 and V₀ > 0 must become negative at some T > 0. An explicit witness T = (|a| + V₀ + 1)/(-b) + 1 is constructed.

5. **`virial_identity_aristotle`** (main theorem) — Combines everything: given the NLS energy definition, energy conservation with E₀ < 0, and the quadratic form of the variance V(t) = V(0) + V'(0)t + 8E₀t² (encoding the PDE content from two rounds of integration by parts), the variance V must become negative at some future time T > 0. Since V(t) = ∫|x|²|u|² ≥ 0, this contradicts the solution existing past T, establishing finite-time blow-up.

The PDE content (differentiating the variance and integrating by parts to show V'' = 8K - (16/(2+4/d))P) is encoded as hypotheses, since Mathlib lacks the required PDE infrastructure. The algebraic reduction V'' = 16E₀ and the finite-time blow-up consequence are fully proved. The file compiles cleanly with only standard axioms (propext, Classical.choice, Quot.sound).