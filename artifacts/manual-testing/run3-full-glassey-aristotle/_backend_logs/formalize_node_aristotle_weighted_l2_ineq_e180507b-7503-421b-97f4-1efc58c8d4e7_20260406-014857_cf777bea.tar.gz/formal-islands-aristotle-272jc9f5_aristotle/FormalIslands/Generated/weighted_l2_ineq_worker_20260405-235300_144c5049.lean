/-
# Weighted L² Inequality

For sufficiently regular f : ℝ^d → ℂ,
  ‖f‖²_{L²} ≤ (2/d) · ‖xf‖_{L²} · ‖∇f‖_{L²}.

This file formalizes the d = 1, ℝ-valued case:
  ∫ f(x)² dx ≤ 2 · √(∫ x² f(x)² dx) · √(∫ f'(x)² dx).

The proof uses:
1. Integration by parts: ∫ f² = −2 ∫ x f f'  (via line-derivative IBP, no boundary terms)
2. Cauchy–Schwarz for integrals: |∫ g h| ≤ √(∫ g²) √(∫ h²)  (via Hölder with p=q=2)

The general d case follows by applying IBP in each coordinate direction
and summing, yielding the factor 2/d.
-/
import Mathlib

open MeasureTheory Real Filter

/-! ## Helper lemma 1: Integration by parts identity -/

/-
Integration by parts identity: `∫ f² = −2 ∫ x f f'`.

Uses the Mathlib line-derivative IBP lemma
`integral_bilinear_hasLineDerivAt_right_eq_neg_left_of_integrable`
with `u(x) = x`, `v(x) = f(x)²`, direction `v = 1`.
-/
lemma ibp_f_sq (f f' : ℝ → ℝ)
    (hf : ∀ x, HasDerivAt f (f' x) x)
    (hf_sq : Integrable (fun x => f x ^ 2))
    (hxff'2 : Integrable (fun x => x * (2 * f x * f' x)))
    (hxf2 : Integrable (fun x => x * f x ^ 2)) :
    ∫ x, f x ^ 2 = -(2 * ∫ x, x * f x * f' x) := by
  -- Apply the integration by parts formula with $u(x) = x$ and $v'(x) = f(x)^2$.
  have h_parts : ∫ x, f x ^ 2 = -∫ x, x * (2 * f x * f' x) := by
    rw [ ← MeasureTheory.integral_neg ];
    have h_parts : ∫ x, (ContinuousLinearMap.mul ℝ ℝ (f x ^ 2) 1) = -∫ x, (ContinuousLinearMap.mul ℝ ℝ (2 * f x * f' x) x) := by
      convert integral_bilinear_hasLineDerivAt_right_eq_neg_left_of_integrable _ _ _ _ _ using 1 <;> norm_num [ hf, hf_sq, hxff'2, hxf2 ];
      all_goals try infer_instance;
      exact 1;
      · simpa only [ mul_assoc, mul_comm, mul_left_comm ] using hxff'2;
      · simpa only [ mul_comm ] using hxf2;
      · intro x; specialize hf x; have := hf.pow 2; simp_all +decide [ hasLineDerivAt_iff_isLittleO_nhds_zero ] ;
        rw [ hasDerivAt_iff_isLittleO_nhds_zero ] at this; aesop;
      · simp [HasLineDerivAt];
        exact fun x => by simpa using hasDerivAt_id 0 |> HasDerivAt.const_add x;
    simp_all +decide [ mul_comm, MeasureTheory.integral_neg ];
  exact h_parts.trans ( by rw [ ← MeasureTheory.integral_const_mul ] ; congr; ext; ring )

/-! ## Helper lemma 2: Cauchy–Schwarz for integrals -/

/-
Cauchy–Schwarz inequality for real-valued integrals:
`|∫ g · h| ≤ √(∫ g²) · √(∫ h²)`.
-/
lemma integral_cauchy_schwarz (g h : ℝ → ℝ)
    (hg : Integrable (fun x => g x ^ 2))
    (hh : Integrable (fun x => h x ^ 2))
    (hgh : Integrable (fun x => g x * h x)) :
    |∫ x, g x * h x| ≤ √(∫ x, g x ^ 2) * √(∫ x, h x ^ 2) := by
  rw [ ← Real.sqrt_mul ( MeasureTheory.integral_nonneg fun _ ↦ sq_nonneg _ ) ];
  refine' Real.abs_le_sqrt _;
  -- By the properties of the inner product and the Cauchy-Schwarz inequality, we have:
  have h_inner : ∫ x, (g x - (∫ x, g x * h x ∂volume) / (∫ x, h x ^ 2 ∂volume) * h x) ^ 2 ∂volume ≥ 0 := by
    exact MeasureTheory.integral_nonneg fun x => sq_nonneg _;
  by_cases h_int_zero : ∫ x, h x ^ 2 ∂volume = 0 <;> simp_all +decide [ sub_sq, mul_pow ];
  · rw [ MeasureTheory.integral_eq_zero_iff_of_nonneg ( fun x => sq_nonneg _ ) ] at h_int_zero;
    · exact MeasureTheory.integral_eq_zero_of_ae ( h_int_zero.mono fun x hx => by aesop );
    · exact hh;
  · rw [ MeasureTheory.integral_add, MeasureTheory.integral_sub ] at h_inner;
    · simp_all +decide [ mul_assoc, mul_comm, mul_left_comm, MeasureTheory.integral_const_mul, MeasureTheory.integral_mul_const ];
      simp_all +decide [ ← mul_assoc, MeasureTheory.integral_mul_const ];
      nlinarith [ mul_div_cancel₀ ( ∫ x, g x * h x ) h_int_zero, show 0 ≤ ∫ x, g x ^ 2 from MeasureTheory.integral_nonneg fun _ => sq_nonneg _, show 0 ≤ ∫ x, h x ^ 2 from MeasureTheory.integral_nonneg fun _ => sq_nonneg _ ];
    · exact hg;
    · convert hgh.mul_const ( 2 * ( ( ∫ x, g x * h x ) / ∫ x, h x ^ 2 ) ) using 2 ; ring;
    · refine' MeasureTheory.Integrable.sub hg _;
      convert hgh.mul_const ( 2 * ( ( ∫ x, g x * h x ) / ∫ x, h x ^ 2 ) ) using 2 ; ring;
    · exact hh.const_mul _

/-! ## Main theorem -/

/-
**Weighted L² inequality (d = 1, ℝ-valued)**

For a differentiable function `f : ℝ → ℝ` with appropriate integrability,

  `∫ f(x)² dx ≤ 2 · √(∫ x² f(x)² dx) · √(∫ f'(x)² dx)`.

This is the one-dimensional specialization of the general inequality
  `‖f‖²_{L²(ℝᵈ)} ≤ (2/d) · ‖x f‖_{L²(ℝᵈ)} · ‖∇f‖_{L²(ℝᵈ)}`
which plays a key role in the Glassey blow-up argument for the
focusing mass-critical NLS.
-/
theorem weighted_l2_ineq_aristotle
    (f f' : ℝ → ℝ)
    (hf_deriv : ∀ x, HasDerivAt f (f' x) x)
    (hf_sq : Integrable (fun x => f x ^ 2))
    (hxf_sq : Integrable (fun x => x ^ 2 * f x ^ 2))
    (hf'_sq : Integrable (fun x => f' x ^ 2))
    (hxff' : Integrable (fun x => x * f x * f' x))
    (hxf2 : Integrable (fun x => x * f x ^ 2))
    (hxff'2 : Integrable (fun x => x * (2 * f x * f' x))) :
    ∫ x, f x ^ 2 ≤ 2 * √(∫ x, x ^ 2 * f x ^ 2) * √(∫ x, f' x ^ 2) := by
  have h₁ := integral_cauchy_schwarz ( fun x => x * f x ) ( fun x => f' x ) ?_ ?_ ?_;
  · have h₂ := ibp_f_sq f f' hf_deriv hf_sq hxff'2 hxf2;
    norm_num [ mul_pow ] at * ; linarith [ abs_le.mp h₁ ];
  · convert hxf_sq using 1 ; ext ; ring;
  · grind +extAll;
  · exact hxff'