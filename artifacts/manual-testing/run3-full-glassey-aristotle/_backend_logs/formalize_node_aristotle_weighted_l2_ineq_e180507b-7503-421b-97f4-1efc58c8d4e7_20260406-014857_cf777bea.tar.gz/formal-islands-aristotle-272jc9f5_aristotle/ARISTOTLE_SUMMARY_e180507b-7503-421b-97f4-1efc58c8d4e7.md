# Summary of changes
Successfully formalized and proved the Weighted L² Inequality (`weighted_l2_ineq_aristotle`) in the file `FormalIslands/Generated/weighted_l2_ineq_worker_20260405-235300_144c5049.lean`.

**Theorem statement (d=1, ℝ-valued specialization):**
For a differentiable function f : ℝ → ℝ with appropriate integrability conditions:
  ∫ f(x)² dx ≤ 2 · √(∫ x² f(x)² dx) · √(∫ f'(x)² dx)

This is the one-dimensional case of the general inequality ‖f‖²_{L²(ℝᵈ)} ≤ (2/d) · ‖xf‖_{L²(ℝᵈ)} · ‖∇f‖_{L²(ℝᵈ)}, which is a key ingredient in the Glassey blow-up argument for the focusing mass-critical NLS.

**Proof structure (3 lemmas, all sorry-free):**

1. **`ibp_f_sq`** — Integration by parts identity: ∫ f² = −2 ∫ x·f·f'. Uses Mathlib's `integral_bilinear_hasLineDerivAt_right_eq_neg_left_of_integrable` (line-derivative IBP with no boundary conditions) applied with u(x) = x, v(x) = f(x)², direction v = 1.

2. **`integral_cauchy_schwarz`** — Cauchy–Schwarz for real-valued integrals: |∫ g·h| ≤ √(∫ g²) · √(∫ h²). Proved from scratch via the discriminant argument: the nonnegative integral ∫ (g − t·h)² ≥ 0 for all t implies the discriminant is ≤ 0.

3. **`weighted_l2_ineq_aristotle`** — Main theorem combining the IBP identity with Cauchy–Schwarz applied to g(x) = x·f(x) and h(x) = f'(x).