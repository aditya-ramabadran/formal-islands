import Mathlib

/-!
# Quadratic Variation Error Vanishes in L²

This file formalizes the key estimates underlying the proof that the
quadratic variation error `M_n := ∑_{k=0}^{n-1} f''(B_{t_k}) · ((ΔB_k)² - Δt_k)`
vanishes in L² as the mesh of the partition tends to zero.

## Main results

* `weighted_sq_sum_le`: The weighted bound `∑ a_k² · v_k ≤ C² · ∑ v_k` when
  `|a_k| ≤ C` and `v_k ≥ 0`. This formalizes the step from the boundedness
  `|f''| ≤ C` to the estimate `∑ f''(B_{t_k})² · 2(Δt_k)² ≤ 2C² · ∑(Δt_k)²`.

* `sum_sq_le_mesh_mul_sum`: The deterministic bound `∑(Δt_k)² ≤ δ · ∑(Δt_k)`
  when each `Δt_k ≤ δ`.

* `mn_vanishes_aristotle`: The combined bound
  `2 * C² * ∑(Δt_k)² ≤ 2 * C² * δ * T`.

* `mn_bound_tendsto_zero`: As the mesh `δ → 0`, `2 * C² * δ * T → 0`.

* `mn_sq_expectation_bound`: Combined weighted bound in the partition setting.

Together these formalize the full deterministic argument: by martingale orthogonality,
`E[M_n²] = ∑ E[f''(B_{t_k})² · ((ΔB_k)² - Δt_k)²]`, and using `|f''| ≤ C`
and the Gaussian identity `E[((ΔB_k)² - Δt_k)²] = 2(Δt_k)²`,
we get `E[M_n²] ≤ 2C² ∑(Δt_k)² ≤ 2C² · δ · T → 0`.
-/

open Finset BigOperators Filter Topology

/-! ### Weighted bound from pointwise boundedness -/

/-
If `|a k| ≤ C` for all `k`, and `v k ≥ 0`, then `∑ (a k)² * v k ≤ C² * ∑ v k`.
-/
theorem weighted_sq_sum_le {n : ℕ} {a : Fin n → ℝ} {v : Fin n → ℝ} {C : ℝ}
    (ha : ∀ k, |a k| ≤ C)
    (hv : ∀ k, 0 ≤ v k) :
    ∑ k, (a k) ^ 2 * v k ≤ C ^ 2 * ∑ k, v k := by
  simpa only [ Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun k _ => mul_le_mul_of_nonneg_right ( by nlinarith only [ abs_le.mp ( ha k ) ] ) ( hv k )

/-! ### Sum-of-squares bounded by mesh times sum -/

/-
For non-negative increments bounded by `δ`, `∑(Δt_k)² ≤ δ * ∑(Δt_k)`.
-/
theorem sum_sq_le_mesh_mul_sum {n : ℕ} {Δt : Fin n → ℝ} {δ : ℝ}
    (hΔt : ∀ k, 0 ≤ Δt k)
    (hmesh : ∀ k, Δt k ≤ δ) :
    ∑ k, (Δt k) ^ 2 ≤ δ * ∑ k, Δt k := by
  simpa only [ sq, Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_right ( hmesh i ) ( hΔt i )

/-! ### Main deterministic bound -/

/--
**Quadratic Variation Error Bound.**

For a partition with `n` non-negative increments `Δt k` summing to `T`, with
mesh (maximum increment) at most `δ`, and a bound `C ≥ 0`:

  `2 * C ^ 2 * ∑ k, (Δt k) ^ 2 ≤ 2 * C ^ 2 * δ * T`

This formalizes the key estimate showing `𝔼[M_n²] → 0` where
`M_n = ∑ f''(B_{t_k}) · ((ΔB_k)² − Δt_k)`, since the bound
`2C² · δ · T → 0` as the partition mesh `δ → 0`.
-/
theorem mn_vanishes_aristotle {n : ℕ} {Δt : Fin n → ℝ} {C T δ : ℝ}
    (hΔt : ∀ k, 0 ≤ Δt k)
    (hT : ∑ k, Δt k = T)
    (hmesh : ∀ k, Δt k ≤ δ)
    (hC : 0 ≤ C) :
    2 * C ^ 2 * ∑ k : Fin n, (Δt k) ^ 2 ≤ 2 * C ^ 2 * δ * T := by
  suffices h_sum_bound : (∑ k, (Δt k) ^ 2) ≤ δ * T by
    simpa only [mul_assoc] using mul_le_mul_of_nonneg_left h_sum_bound
      (mul_nonneg zero_le_two (sq_nonneg C))
  rw [← hT]
  exact sum_sq_le_mesh_mul_sum hΔt hmesh

/-! ### Convergence to zero -/

/-
As the mesh `δ → 0`, the bound `2 * C² * δ * T` tends to `0`.
-/
theorem mn_bound_tendsto_zero (C T : ℝ) :
    Tendsto (fun δ => 2 * C ^ 2 * δ * T) (nhds 0) (nhds 0) := by
  exact Continuous.tendsto' ( by continuity ) _ _ ( by norm_num )

/-! ### Combined: weighted bound applied to partition setting -/

/-
If each weight `a_k` satisfies `|a_k| ≤ C`, each variance term equals
`2 * (Δt_k)²`, then the total sum is at most `2 * C² * ∑(Δt_k)²`. This
formalizes the estimate step from `∑ f''(B_{t_k})² · 2(Δt_k)²` to
`2C² · ∑(Δt_k)²`.
-/
theorem mn_sq_expectation_bound {n : ℕ} {a : Fin n → ℝ} {Δt : Fin n → ℝ} {C : ℝ}
    (ha : ∀ k, |a k| ≤ C)
    (hΔt : ∀ k, 0 ≤ Δt k) :
    ∑ k, (a k) ^ 2 * (2 * (Δt k) ^ 2) ≤ 2 * C ^ 2 * ∑ k, (Δt k) ^ 2 := by
  convert weighted_sq_sum_le ha ( fun k => mul_nonneg zero_le_two ( pow_two_nonneg ( Δt k ) ) ) using 1 ; ring;
  rw [ ← Finset.sum_mul _ _ _, mul_assoc ]