# Summary of changes
## Quadratic Variation Error Vanishes in L² — Expanded Formalization

I expanded the previously verified deterministic bound into a comprehensive formalization covering the full chain of estimates in the node. The file `FormalIslands/Generated/mn_vanishes_worker_20260406-062552_d371361a.lean` now contains five fully proven theorems (no `sorry`s) that together formalize the complete deterministic argument underlying the L² convergence:

### Theorems proved

1. **`weighted_sq_sum_le`**: If `|a_k| ≤ C` and `v_k ≥ 0`, then `∑ a_k² · v_k ≤ C² · ∑ v_k`. This formalizes the step from `|f''| ≤ C` to bounding the weighted sum `∑ f''(B_{t_k})² · 2(Δt_k)²`.

2. **`sum_sq_le_mesh_mul_sum`**: For non-negative increments bounded by mesh `δ`, `∑(Δt_k)² ≤ δ · ∑(Δt_k)`.

3. **`mn_vanishes_aristotle`** (main theorem): For a partition with non-negative increments summing to `T` and mesh ≤ `δ`: `2C² · ∑(Δt_k)² ≤ 2C² · δ · T`.

4. **`mn_bound_tendsto_zero`**: As `δ → 0`, `2C²δT → 0` (topological convergence in `ℝ`).

5. **`mn_sq_expectation_bound`**: Combined weighted bound: `∑ a_k² · 2(Δt_k)² ≤ 2C² · ∑(Δt_k)²`, formalizing the transition from per-term Gaussian fourth-moment estimates to the aggregate bound.

### Coverage of the node

The full node states: `E[M_n²] ≤ 2C² ∑(Δt_k)² → 0`. The formalization covers:
- The **weighted bound** step (from `|f''| ≤ C` and per-term variance `2(Δt_k)²` to `2C²∑(Δt_k)²`) via `weighted_sq_sum_le` and `mn_sq_expectation_bound`
- The **deterministic mesh estimate** `2C²∑(Δt_k)² ≤ 2C²δT` via `mn_vanishes_aristotle`
- The **convergence to zero** as mesh → 0 via `mn_bound_tendsto_zero`

The Gaussian fourth-moment identity `E[((ΔB_k)² − Δt_k)²] = 2(Δt_k)²` and martingale orthogonality are documented in the module docstring as the probabilistic inputs that feed into these deterministic estimates, but are not formalized due to the absence of Brownian motion infrastructure in Mathlib.