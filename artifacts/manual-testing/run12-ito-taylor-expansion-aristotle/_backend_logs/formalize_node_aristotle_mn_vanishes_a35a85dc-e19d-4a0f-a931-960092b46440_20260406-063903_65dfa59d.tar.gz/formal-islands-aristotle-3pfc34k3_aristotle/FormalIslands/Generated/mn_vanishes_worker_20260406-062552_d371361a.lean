import Mathlib

/-!
# Quadratic Variation Error Vanishes in L²

This file formalizes the key estimate in the proof that the quadratic variation error
vanishes in L² in the proof of Itô's formula.

## Main result

Given a partition with increments `d k ≥ 0` summing to `T`, and coefficients `a k`
bounded in absolute value by `C`, the sum

  `∑ k, a k ^ 2 * (2 * d k ^ 2)`

is bounded above by `2 * C ^ 2 * δ * T` where `δ` is an upper bound on the mesh
(i.e., `d k ≤ δ` for all `k`).

In the context of Itô's formula, `a k = f''(B_{t_k})` (bounded by `C = ‖f''‖_∞`),
`d k = Δt_k` (the partition increments), and `2 * d k ^ 2` comes from the Gaussian
fourth-moment identity `𝔼[(ΔB_k² - Δt_k)²] = 2(Δt_k)²`. The cross terms vanish
by martingale orthogonality, reducing `𝔼[M_n²]` to `∑ a_k² · 2(Δt_k)²`.

Since `2C² δ T → 0` as `δ → 0`, this gives `𝔼[M_n²] → 0`.
-/

open Finset BigOperators

/-! ### Helper lemmas -/

/-
For non-negative reals each bounded by `B`, the sum of squares is at most `B` times
the sum. This is the key estimate: `∑ dₖ² ≤ mesh · ∑ dₖ`.
-/
theorem sum_sq_le_sup_mul_sum {ι : Type*} {s : Finset ι} {d : ι → ℝ}
    (hd : ∀ i ∈ s, 0 ≤ d i) {B : ℝ} (hB : ∀ i ∈ s, d i ≤ B) :
    ∑ i ∈ s, d i ^ 2 ≤ B * ∑ i ∈ s, d i := by
  simpa only [ Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun i hi => by nlinarith only [ hd i hi, hB i hi ] ;

/-
Weighted sum with bounded coefficients: if `|a k| ≤ C` and `v k ≥ 0`, then
`∑ a k ^ 2 * v k ≤ C ^ 2 * ∑ v k`.
-/
theorem weighted_sum_le_sq_bound {ι : Type*} {s : Finset ι} {a : ι → ℝ} {v : ι → ℝ}
    {C : ℝ} (hC : 0 ≤ C)
    (ha : ∀ i ∈ s, |a i| ≤ C) (hv : ∀ i ∈ s, 0 ≤ v i) :
    ∑ i ∈ s, a i ^ 2 * v i ≤ C ^ 2 * ∑ i ∈ s, v i := by
  simpa only [ Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun i hi => mul_le_mul_of_nonneg_right ( by nlinarith only [ abs_le.mp ( ha i hi ) ] ) ( hv i hi )

/-! ### Main theorem -/

/-
**Quadratic Variation Error Bound.**

For a partition with non-negative increments `d k` summing to `T`, mesh at most `δ`,
and coefficients `a k` with `|a k| ≤ C`:

  `∑ k, a k ^ 2 * (2 * d k ^ 2) ≤ 2 * C ^ 2 * δ * T`

In the Itô's formula proof, this bounds `𝔼[M_n²]` where
`M_n = ∑ f''(B_{tₖ}) · ((ΔBₖ)² - Δtₖ)`. The `2 * d k ^ 2` factor comes from the
Gaussian fourth-moment identity, and the cross terms vanish by martingale orthogonality.

As the partition mesh `δ → 0`, the right side `2C²δT → 0`, giving `𝔼[M_n²] → 0`.
-/
theorem mn_vanishes_aristotle {n : ℕ} {d : Fin n → ℝ} {a : Fin n → ℝ}
    {C T δ : ℝ}
    (hd : ∀ k, 0 ≤ d k)
    (hT : ∑ k, d k = T)
    (hmesh : ∀ k, d k ≤ δ)
    (ha : ∀ k, |a k| ≤ C)
    (hC : 0 ≤ C) :
    ∑ k : Fin n, a k ^ 2 * (2 * (d k) ^ 2) ≤ 2 * C ^ 2 * δ * T := by
  -- Apply the weighted sum bound to get ∑ k, a k ^ 2 * (2 * d k ^ 2) ≤ C ^ 2 * ∑ k, (2 * d k ^ 2).
  have h1 : ∑ k, a k ^ 2 * (2 * d k ^ 2) ≤ C ^ 2 * ∑ k, (2 * d k ^ 2) := by
    simpa only [ Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun k _ => mul_le_mul_of_nonneg_right ( by simpa using pow_le_pow_left₀ ( abs_nonneg _ ) ( ha k ) 2 ) ( mul_nonneg zero_le_two ( sq_nonneg _ ) );
  -- Apply the sum_sq_le_sup_mul_sum theorem to get ∑ k, 2 * d k ^ 2 ≤ 2 * δ * ∑ k, d k.
  have h2 : ∑ k, 2 * d k ^ 2 ≤ 2 * δ * ∑ k, d k := by
    simpa only [ Finset.mul_sum _ _ _, sq, mul_assoc, mul_left_comm ] using Finset.sum_le_sum fun i _ => mul_le_mul_of_nonneg_left ( show d i ^ 2 ≤ δ * d i by nlinarith only [ hd i, hmesh i ] ) zero_le_two;
  exact h1.trans ( by rw [ hT ] at h2; nlinarith )