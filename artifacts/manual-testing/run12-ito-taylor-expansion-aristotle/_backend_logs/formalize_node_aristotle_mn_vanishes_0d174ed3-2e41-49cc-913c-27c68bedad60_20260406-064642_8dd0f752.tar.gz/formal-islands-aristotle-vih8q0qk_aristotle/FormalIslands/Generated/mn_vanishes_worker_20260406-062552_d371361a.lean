import Mathlib

/-!
# Quadratic Variation Error Vanishes in L²

This file formalizes the key deterministic estimate underlying the proof that the
quadratic variation error vanishes in L² in the proof of Itô's formula for Brownian
motion.

## Setting

In the Itô formula proof, one defines
  `M_n := ∑_{k=0}^{n-1} f''(B_{t_k}) · ((ΔB_k)² - Δt_k)`.

By martingale orthogonality (the cross terms vanish because each increment is
independent of the past), we have
  `𝔼[M_n²] = ∑_k 𝔼[f''(B_{t_k})² · ((ΔB_k)² - Δt_k)²]`.

Using `|f''| ≤ C` and the Gaussian fourth-moment identity
  `𝔼[((ΔB_k)² - Δt_k)²] = 2(Δt_k)²`,
we obtain the bound
  `𝔼[M_n²] ≤ 2C² ∑_k (Δt_k)²`.

We formalize below the **deterministic** bound
  `2C² ∑_k (Δt_k)² ≤ 2C² · mesh · T`,
which shows that the right-hand side tends to 0 as the mesh tends to 0.

## Main result

`mn_vanishes_aristotle`: For a partition of `[0, T]` with non-negative increments
`Δt k` summing to `T`, mesh at most `δ`, and `C ≥ 0`:
  `2 * C² * ∑ k, (Δt k)² ≤ 2 * C² * δ * T`.
-/

open Finset BigOperators

/--
**Quadratic Variation Error Bound.**

For a partition with `n` non-negative increments `Δt k` summing to `T`, with
mesh (maximum increment) at most `δ`, and a bound `C ≥ 0`:

  `2 * C ^ 2 * ∑ k, (Δt k) ^ 2 ≤ 2 * C ^ 2 * δ * T`

This formalizes the key estimate showing `𝔼[M_n²] → 0` where
`M_n = ∑ f''(B_{t_k}) · ((ΔB_k)² − Δt_k)`, since the bound
`2C² · δ · T → 0` as the partition mesh `δ → 0`.
-/
theorem mn_vanishes_aristotle {n : ℕ} {Δt : Fin n → ℝ} {C T δ : ℝ}
    (hΔt : ∀ k, 0 ≤ Δt k)
    (hT : ∑ k, Δt k = T)
    (hmesh : ∀ k, Δt k ≤ δ)
    (hC : 0 ≤ C) :
    2 * C ^ 2 * ∑ k : Fin n, (Δt k) ^ 2 ≤ 2 * C ^ 2 * δ * T := by
  -- We need to show `2 * C^2 * ∑ k, (Δt k)^2 ≤ 2 * C^2 * δ * T`. Since `2 * C^2 ≥ 0`, it suffices to show `∑ k, (Δt k)^2 ≤ δ * T`.
  suffices h_sum_bound : (∑ k, (Δt k) ^ 2) ≤ δ * T by
    simpa only [ mul_assoc ] using mul_le_mul_of_nonneg_left h_sum_bound ( mul_nonneg zero_le_two ( sq_nonneg C ) );
  rw [ ← hT, Finset.mul_sum _ _ _ ] ; exact Finset.sum_le_sum fun k _ => by nlinarith only [ hΔt k, hmesh k ] ;