/-
  Taylor Expansion Identity with Remainder Bound

  For a C² function f and a finite sequence of real numbers x₀, x₁, ..., xₙ,
  the telescoping sum of Taylor expansions yields:

    f(xₙ) - f(x₀) = Σ_{k<n} f'(xₖ)(xₖ₊₁ - xₖ) + (1/2) Σ_{k<n} f''(xₖ)(xₖ₊₁ - xₖ)² + R

  where the remainder R satisfies |R| ≤ (1/2) · ω(δ) · Σ_{k<n} (xₖ₊₁ - xₖ)²
  for any modulus of continuity ω of f'' and any δ ≥ max_k |xₖ₊₁ - xₖ|.

  This is the key deterministic step in the proof of Itô's formula.
-/
import Mathlib.Analysis.Calculus.Taylor

open Finset BigOperators Set

noncomputable section

/-
Second-order Taylor remainder bound for a C² function.
For any C² function f and points a, b, the second-order Taylor remainder
  f(b) - f(a) - f'(a)(b-a) - (1/2)f''(a)(b-a)²
is bounded by (1/2) · ω(|b-a|) · (b-a)², where ω is a modulus of continuity for f''.
-/
lemma taylor_second_order_remainder_bound
    (f : ℝ → ℝ) (a b : ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ t, 0 ≤ ω t) (hω_mono : Monotone ω)
    (hω_mod : ∀ u v, |deriv (deriv f) u - deriv (deriv f) v| ≤ ω (|u - v|)) :
    |f b - f a - deriv f a * (b - a) - 1 / 2 * deriv (deriv f) a * (b - a) ^ 2|
      ≤ 1 / 2 * ω (|b - a|) * (b - a) ^ 2 := by
  by_cases hab : b = a;
  · aesop;
  · -- Apply the Lagrange remainder form to get:
    have h_remaining : ∃ x' ∈ Set.Ioo (min a b) (max a b), f b - f a - deriv f a * (b - a) = (1 / 2) * deriv (deriv f) x' * (b - a) ^ 2 := by
      cases le_total a b;
      · have := @taylor_mean_remainder_lagrange_iteratedDeriv;
        specialize this ( lt_of_le_of_ne ‹_› ( Ne.symm hab ) ) ( hf.contDiffOn );
        simp_all +decide [ taylorWithinEval, iteratedDeriv_succ' ];
        obtain ⟨ x', hx', hx ⟩ := this; use x'; simp_all +decide [ taylorWithin ];
        norm_num [ Finset.sum_range_succ, taylorCoeffWithin ] at hx;
        rw [ derivWithin ] at hx;
        rw [ fderivWithin_eq_fderiv ] at hx;
        · norm_num [ fderiv_apply_one_eq_deriv ] at hx; linarith;
        · exact uniqueDiffOn_Icc ( by linarith ) a ( by norm_num; linarith );
        · exact hf.contDiffAt.differentiableAt ( by norm_num );
      · -- Define the auxiliary function $g(x) = f(x) - f(a) - deriv f a * (x - a) - \frac{(f(b) - f(a) - deriv f a * (b - a))}{(b - a)^2} * (x - a)^2$
        set g : ℝ → ℝ := fun x => f x - f a - deriv f a * (x - a) - ((f b - f a - deriv f a * (b - a)) / (b - a)^2) * (x - a)^2;
        -- By Rolle's theorem, since $g(b) = g(a) = 0$, there exists some $c \in (b, a)$ such that $g'(c) = 0$.
        obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo b a, deriv g c = 0 := by
          apply_mod_cast exists_deriv_eq_zero;
          · exact lt_of_le_of_ne ‹_› hab;
          · exact ContinuousOn.sub ( ContinuousOn.sub ( ContinuousOn.sub ( hf.continuous.continuousOn ) ( continuousOn_const ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const ) ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const |> ContinuousOn.pow <| 2 ) );
          · grind;
        -- By definition of $g$, we know that its derivative is $g'(x) = deriv f x - deriv f a - 2 * ((f b - f a - deriv f a * (b - a)) / (b - a)^2) * (x - a)$.
        have hg' : ∀ x, deriv g x = deriv f x - deriv f a - 2 * ((f b - f a - deriv f a * (b - a)) / (b - a)^2) * (x - a) := by
          intro x; norm_num [ g, hf.contDiffAt.differentiableAt ] ; ring;
        -- Apply the mean value theorem to the interval $[a, c]$.
        obtain ⟨x', hx'⟩ : ∃ x' ∈ Set.Ioo c a, deriv (deriv f) x' = (deriv f a - deriv f c) / (a - c) := by
          apply_rules [ exists_deriv_eq_slope ];
          · linarith [ hc.1.2 ];
          · exact hf.continuous_deriv ( by norm_num ) |> Continuous.continuousOn;
          · fun_prop;
        grind;
    rcases h_remaining with ⟨ x', hx', h ⟩ ; rw [ h ] ; norm_num [ mul_assoc, abs_mul ];
    rw [ ← mul_sub, abs_mul, abs_of_nonneg ( by norm_num : ( 0 : ℝ ) ≤ 1 / 2 ) ];
    exact mul_le_mul_of_nonneg_left ( by rw [ show deriv ( deriv f ) x' * ( b - a ) ^ 2 - deriv ( deriv f ) a * ( b - a ) ^ 2 = ( deriv ( deriv f ) x' - deriv ( deriv f ) a ) * ( b - a ) ^ 2 by ring ] ; rw [ abs_mul, abs_sq ] ; exact mul_le_mul_of_nonneg_right ( hω_mod x' a |> le_trans <| hω_mono <| by cases max_cases a b <;> cases min_cases a b <;> cases abs_cases ( x' - a ) <;> cases abs_cases ( b - a ) <;> linarith [ hx'.1, hx'.2 ] ) <| sq_nonneg _ ) <| by norm_num

/-
The telescoping Taylor expansion identity with remainder bound.

For a C² function f and a sequence of points x₀, ..., xₙ, we have:
  f(xₙ) - f(x₀) = Σ f'(xₖ)·Δxₖ + (1/2)·Σ f''(xₖ)·(Δxₖ)² + R
where the remainder R satisfies |R| ≤ (1/2)·ω(δ)·Σ(Δxₖ)² for any δ bounding max|Δxₖ|.
-/
theorem taylor_expansion_aristotle
    (n : ℕ) (f : ℝ → ℝ) (x : ℕ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ t, 0 ≤ ω t) (hω_mono : Monotone ω)
    (hω_mod : ∀ u v, |deriv (deriv f) u - deriv (deriv f) v| ≤ ω (|u - v|))
    (δ : ℝ) (hδ : ∀ k, k < n → |x (k + 1) - x k| ≤ δ) :
    ∃ R : ℝ,
      f (x n) - f (x 0) =
        (∑ k ∈ Finset.range n, deriv f (x k) * (x (k + 1) - x k))
        + 1 / 2 * (∑ k ∈ Finset.range n, deriv (deriv f) (x k) * (x (k + 1) - x k) ^ 2)
        + R
      ∧ |R| ≤ 1 / 2 * ω δ * ∑ k ∈ Finset.range n, (x (k + 1) - x k) ^ 2 := by
  refine' ⟨ _, _, _ ⟩;
  exact ∑ k ∈ Finset.range n, ( f ( x ( k + 1 ) ) - f ( x k ) - deriv f ( x k ) * ( x ( k + 1 ) - x k ) - 1 / 2 * deriv ( deriv f ) ( x k ) * ( x ( k + 1 ) - x k ) ^ 2 );
  · exact Nat.recOn n ( by norm_num ) fun n ih => by norm_num [ Finset.sum_range_succ ] at * ; linarith;
  · refine' le_trans ( Finset.abs_sum_le_sum_abs _ _ ) _;
    rw [ Finset.mul_sum _ _ _ ];
    exact Finset.sum_le_sum fun i hi => le_trans ( taylor_second_order_remainder_bound f ( x i ) ( x ( i + 1 ) ) hf ω hω_nonneg hω_mono hω_mod ) ( by nlinarith only [ hδ i ( Finset.mem_range.mp hi ), hω_mono ( show |x ( i + 1 ) - x i| ≤ δ from hδ i ( Finset.mem_range.mp hi ) ), abs_mul_abs_self ( x ( i + 1 ) - x i ) ] )

end
