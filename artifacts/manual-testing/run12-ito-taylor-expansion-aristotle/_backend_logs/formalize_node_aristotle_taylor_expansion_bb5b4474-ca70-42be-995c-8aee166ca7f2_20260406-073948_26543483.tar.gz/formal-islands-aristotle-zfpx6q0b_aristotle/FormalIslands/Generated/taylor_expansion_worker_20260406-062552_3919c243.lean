/-
  Taylor Expansion Identity with Remainder Bound

  For a C² function f and a finite sequence of real numbers x₀, x₁, ..., xₙ,
  the telescoping sum of Taylor expansions yields:

    f(xₙ) - f(x₀) = Σ_{k<n} f'(xₖ)(xₖ₊₁ - xₖ) + (1/2) Σ_{k<n} f''(xₖ)(xₖ₊₁ - xₖ)² + R

  where the remainder R satisfies |R| ≤ (1/2) · ω(δ) · Σ_{k<n} (xₖ₊₁ - xₖ)²
  for any modulus of continuity ω of f'' and any δ ≥ max_k |xₖ₊₁ - xₖ|.

  This is the key deterministic step in the proof of Itô's formula.
-/
import Mathlib.Analysis.Calculus.Taylor
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Analysis.Calculus.MeanValue

open Finset BigOperators Set

noncomputable section

/-
Second-order Taylor remainder bound for a single step.
For a C² function f and points a, b, the second-order Taylor remainder
  f(b) - f(a) - f'(a)(b-a) - (1/2)f''(a)(b-a)²
is bounded by (1/2) · ω(|b-a|) · (b-a)², where ω is a modulus of continuity for f''.
-/
lemma taylor_second_order_remainder_bound
    (f : ℝ → ℝ) (a b : ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ t, 0 ≤ ω t) (hω_mono : Monotone ω)
    (hω_mod : ∀ u v, |deriv (deriv f) u - deriv (deriv f) v| ≤ ω (|u - v|)) :
    |f b - f a - deriv f a * (b - a) - 1 / 2 * deriv (deriv f) a * (b - a) ^ 2|
      ≤ 1 / 2 * ω (|b - a|) * (b - a) ^ 2 := by
  by_cases hab : a < b <;> simp_all +decide [ abs_le ];
  · -- Use taylor_mean_remainder_lagrange_iteratedDeriv from Mathlib for the case a < b: it gives ξ ∈ (a,b) with f(b) - taylorWithinEval f 1 (Icc a b) a b = iteratedDeriv 2 f ξ * (b-a)² / 2!.
    obtain ⟨ξ, hξ⟩ : ∃ ξ ∈ Set.Ioo a b, f b - f a - deriv f a * (b - a) = (1 / 2) * deriv (deriv f) ξ * (b - a) ^ 2 := by
      have := taylor_mean_remainder_lagrange_iteratedDeriv hab ( show ContDiffOn ℝ 2 f ( Set.Icc a b ) from hf.contDiffOn ) ; norm_num at *;
      obtain ⟨ ξ, hξ₁, hξ₂ ⟩ := this; use ξ; rw [ derivWithin ] at hξ₂; simp_all +decide [ mul_comm, iteratedDeriv_succ ] ; ring;
      rw [ fderivWithin_eq_fderiv ] at hξ₂;
      · norm_num [ fderiv_apply_one_eq_deriv ] at hξ₂; linarith;
      · exact uniqueDiffOn_Icc ( by linarith ) a ( by norm_num; linarith );
      · exact hf.contDiffAt.differentiableAt ( by norm_num );
    have := hω_mod ξ a; norm_num at * ; constructor <;> nlinarith [ hω_nonneg |b - a|, hω_mono ( show |ξ - a| ≤ |b - a| by cases abs_cases ( ξ - a ) <;> cases abs_cases ( b - a ) <;> linarith [ hξ.1.1, hξ.1.2 ] ) ] ;
  · cases eq_or_lt_of_le hab <;> simp_all +decide [ abs_of_nonpos, abs_of_nonneg ];
    -- Apply the taylor_mean_remainder_lagrange_iteratedDeriv lemma to the interval [b, a].
    obtain ⟨ξ, hξ⟩ : ∃ ξ ∈ Set.Ioo b a, deriv (deriv f) ξ = (2 * (f b - f a - deriv f a * (b - a))) / (b - a) ^ 2 := by
      have h_taylor : ∃ ξ ∈ Set.Ioo b a, deriv (fun x => f x - f a - deriv f a * (x - a) - (f b - f a - deriv f a * (b - a)) / (b - a) ^ 2 * (x - a) ^ 2) ξ = 0 := by
        apply_rules [ exists_deriv_eq_zero ];
        · exact ContinuousOn.sub ( ContinuousOn.sub ( ContinuousOn.sub ( hf.continuous.continuousOn ) ( continuousOn_const ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const ) ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const |> ContinuousOn.pow <| 2 ) );
        · rw [ div_mul_cancel₀ ] <;> nlinarith;
      norm_num [ hf.contDiffAt.differentiableAt ] at *;
      obtain ⟨ ξ, hξ₁, hξ₂ ⟩ := h_taylor;
      have h_mean_value : ∃ c ∈ Set.Ioo ξ a, deriv (deriv f) c = (deriv f a - deriv f ξ) / (a - ξ) := by
        apply_rules [ exists_deriv_eq_slope ];
        · linarith;
        · exact hf.continuous_deriv ( by norm_num ) |> Continuous.continuousOn;
        · fun_prop;
      grind;
    have := hω_mod a ξ; simp_all +decide [ abs_of_neg, abs_of_nonneg, le_of_lt ];
    constructor <;> nlinarith [ hω_mono ( show a - ξ ≤ a - b by linarith ), mul_div_cancel₀ ( 2 * ( f b - f a - deriv f a * ( b - a ) ) ) ( by nlinarith : ( b - a ) ^ 2 ≠ 0 ) ]

/-
The telescoping Taylor expansion identity with remainder bound.

For a C² function f and a sequence of points x₀, ..., xₙ, we have:
  f(xₙ) - f(x₀) = Σ f'(xₖ)·Δxₖ + (1/2)·Σ f''(xₖ)·(Δxₖ)² + R
where the remainder R satisfies |R| ≤ (1/2)·ω(δ)·Σ(Δxₖ)² for any δ bounding max|Δxₖ|.
-/
theorem taylor_expansion_aristotle
    (n : ℕ) (f : ℝ → ℝ) (x : ℕ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ t, 0 ≤ ω t) (hω_mono : Monotone ω)
    (hω_mod : ∀ u v, |deriv (deriv f) u - deriv (deriv f) v| ≤ ω (|u - v|))
    (δ : ℝ) (hδ : ∀ k, k < n → |x (k + 1) - x k| ≤ δ) :
    ∃ R : ℝ,
      f (x n) - f (x 0) =
        (∑ k ∈ Finset.range n, deriv f (x k) * (x (k + 1) - x k))
        + 1 / 2 * (∑ k ∈ Finset.range n, deriv (deriv f) (x k) * (x (k + 1) - x k) ^ 2)
        + R
      ∧ |R| ≤ 1 / 2 * ω δ * ∑ k ∈ Finset.range n, (x (k + 1) - x k) ^ 2 := by
  refine' ⟨ _, eq_add_of_sub_eq' rfl, _ ⟩;
  -- Apply the single-step bound to each term in the sum.
  have h_remainder_bound : ∀ k < n, |(f (x (k + 1)) - f (x k) - deriv f (x k) * (x (k + 1) - x k) - 1 / 2 * deriv (deriv f) (x k) * (x (k + 1) - x k) ^ 2)| ≤ 1 / 2 * ω (|x (k + 1) - x k|) * (x (k + 1) - x k) ^ 2 := by
    exact fun k a => taylor_second_order_remainder_bound f (x k) (x (k + 1)) hf ω hω_nonneg hω_mono hω_mod;
  -- By the triangle inequality, we can bound the absolute value of the sum.
  have h_triangle : |∑ k ∈ Finset.range n, (f (x (k + 1)) - f (x k) - deriv f (x k) * (x (k + 1) - x k) - 1 / 2 * deriv (deriv f) (x k) * (x (k + 1) - x k) ^ 2)| ≤ ∑ k ∈ Finset.range n, (1 / 2 * ω δ) * (x (k + 1) - x k) ^ 2 := by
    exact le_trans ( Finset.abs_sum_le_sum_abs _ _ ) ( Finset.sum_le_sum fun i hi => le_trans ( h_remainder_bound i ( Finset.mem_range.mp hi ) ) ( by gcongr ; aesop ) );
  convert h_triangle using 1 <;> norm_num [ Finset.mul_sum _ _ _, mul_assoc ];
  rw [ ← Finset.sum_sub_distrib ] ; rw [ Finset.sum_range_sub ( fun i => f ( x i ) ) ] ; ring;

end