import Mathlib

open Real

/-!
# Convexity of G: G''(u) ≥ 0 on (0, 2)

We formalize the convexity of the function G arising in the two-point
logarithmic Sobolev inequality. Specifically:

- G(u) = (√u - √(2-u))² - u·log(u) - (2-u)·log(2-u)
       = 2 - 2√(u(2-u)) - u·log(u) - (2-u)·log(2-u)
- G'(u) = 2(u-1)/√(u(2-u)) - log(u/(2-u))
- G''(u) = 2(1 - √(u(2-u))) / ((u(2-u))·√(u(2-u)))

We prove G(1) = 0, G'(1) = 0, that G has derivative G' and G' has derivative G''
on (0,2), and that G''(u) ≥ 0 on (0,2).
-/

/-! ## Definitions -/

/-- The function G(u) = 2 - 2√(u(2-u)) - u·log(u) - (2-u)·log(2-u),
which represents the "gap" in the two-point log-Sobolev inequality after
substituting u = a², 2-u = b² (with a²+b² = 2). -/
noncomputable def G (u : ℝ) : ℝ :=
  2 - 2 * sqrt (u * (2 - u)) - u * log u - (2 - u) * log (2 - u)

/-- The first derivative G'(u) = 2(u-1)/√(u(2-u)) - log(u/(2-u)). -/
noncomputable def G' (u : ℝ) : ℝ :=
  2 * (u - 1) / sqrt (u * (2 - u)) - log (u / (2 - u))

/-- The second derivative G''(u) = 2(1 - √(u(2-u))) / ((u(2-u))·√(u(2-u))),
which equals 2(1 - √(u(2-u))) / (u(2-u))^(3/2). -/
noncomputable def G'' (u : ℝ) : ℝ :=
  2 * (1 - sqrt (u * (2 - u))) / ((u * (2 - u)) * sqrt (u * (2 - u)))

/-! ## Basic estimates -/

/-- For any real u, u(2-u) = 1 - (u-1)² ≤ 1. -/
lemma u_mul_two_sub_u_le_one (u : ℝ) : u * (2 - u) ≤ 1 := by
  linarith [sq_nonneg (u - 1)]

/-- For any real u, √(u(2-u)) ≤ 1. -/
lemma sqrt_u_mul_two_sub_u_le_one (u : ℝ) : sqrt (u * (2 - u)) ≤ 1 := by
  rw [Real.sqrt_le_left] <;> linarith [sq_nonneg (u - 1)]

/-- For u ∈ (0,2), the product u*(2-u) is positive. -/
lemma u_mul_two_sub_u_pos (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    0 < u * (2 - u) := by
  nlinarith

/-! ## Values at u = 1 -/

/-
G(1) = 0: the gap vanishes when a = b (i.e., u = 1).
-/
lemma G_at_one : G 1 = 0 := by
  unfold G; norm_num;

/-
G'(1) = 0: the first derivative vanishes at the symmetric point u = 1.
-/
lemma G'_at_one : G' 1 = 0 := by
  norm_num [ G' ]

/-! ## Derivative computations -/

/-
For u ∈ (0,2), the derivative of G at u equals G'(u).

This uses:
  d/du [u·log(u)] = log(u) + 1
  d/du [(2-u)·log(2-u)] = -(log(2-u) + 1)
  d/du [2√(u(2-u))] = 2·(1-u)/√(u(2-u))

Combining: G'(u) = -2·(1-u)/√(u(2-u)) - log(u) + log(2-u)
                  = 2(u-1)/√(u(2-u)) - log(u/(2-u))
-/
theorem hasDerivAt_G (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    HasDerivAt G (G' u) u := by
      convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( HasDerivAt.sqrt ( HasDerivAt.mul ( hasDerivAt_id u ) ( hasDerivAt_id u |> HasDerivAt.const_sub _ ) ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_id u ) <| Real.hasDerivAt_log hu0.ne' ) ) ( HasDerivAt.mul ( hasDerivAt_id u |> HasDerivAt.const_sub _ ) <| HasDerivAt.log ( hasDerivAt_id u |> HasDerivAt.const_sub _ ) _ ) using 1;
      · norm_num [ neg_div, div_div, mul_div_cancel_left₀, ne_of_gt hu0, ne_of_gt ( sub_pos.mpr hu2 ) ] ; ring;
        unfold G';
        rw [ Real.log_div ] <;> ring <;> nlinarith;
      · exact mul_ne_zero hu0.ne' ( by norm_num; linarith );
      · norm_num; linarith

/-
For u ∈ (0,2), the derivative of G' at u equals G''(u).

This uses:
  d/du [2(u-1)/√(u(2-u))] = 2/(u(2-u))^(3/2)
  d/du [log(u/(2-u))] = 1/u + 1/(2-u) = 2/(u(2-u))

Hence G''(u) = 2/(u(2-u))^(3/2) - 2/(u(2-u))
             = 2(1 - √(u(2-u))) / (u(2-u))^(3/2)
-/
theorem hasDerivAt_G' (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    HasDerivAt G' (G'' u) u := by
      convert HasDerivAt.sub ( HasDerivAt.div ( HasDerivAt.const_mul 2 ( hasDerivAt_id' u |> HasDerivAt.sub <| hasDerivAt_const _ _ ) ) ( HasDerivAt.sqrt ( HasDerivAt.mul ( hasDerivAt_id' u ) ( hasDerivAt_id' u |> HasDerivAt.const_sub _ ) ) _ ) _ ) ( HasDerivAt.log ( HasDerivAt.div ( hasDerivAt_id' u ) ( hasDerivAt_id' u |> HasDerivAt.const_sub _ ) _ ) _ ) using 1 <;> norm_num [ hu0.ne', hu2.ne, ne_of_gt hu0, ne_of_gt ( sub_pos.mpr hu2 ) ];
      · unfold G'';
        field_simp;
        rw [ div_sub_div, div_eq_div_iff ];
        · rw [ show Real.sqrt ( u * ( 2 - u ) ) ^ 3 = Real.sqrt ( u * ( 2 - u ) ) * Real.sqrt ( u * ( 2 - u ) ) ^ 2 by ring, Real.sq_sqrt ] <;> nlinarith;
        · exact mul_ne_zero ( by linarith ) ( Real.sqrt_ne_zero'.mpr ( by nlinarith ) );
        · exact mul_ne_zero ( pow_ne_zero 3 ( Real.sqrt_ne_zero'.mpr ( mul_pos hu0 ( sub_pos.mpr hu2 ) ) ) ) ( sub_ne_zero.mpr hu2.ne' );
        · exact pow_ne_zero _ <| ne_of_gt <| Real.sqrt_pos.mpr <| mul_pos hu0 <| sub_pos.mpr hu2;
        · linarith;
      · exact ne_of_gt <| Real.sqrt_pos.mpr <| mul_pos hu0 <| sub_pos.mpr hu2

/-! ## Convexity: G''(u) ≥ 0 -/

/-
**Convexity of G**: For u ∈ (0, 2), the second derivative of G satisfies
G''(u) = 2(1 - √(u(2-u))) / (u(2-u))^(3/2) ≥ 0.

Since u(2-u) = 1-(u-1)² ≤ 1, we have √(u(2-u)) ≤ 1, so the numerator is
nonnegative. The denominator is positive for u ∈ (0,2).
-/
theorem G''_nonneg (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    0 ≤ G'' u := by
      exact div_nonneg ( mul_nonneg zero_le_two ( sub_nonneg.mpr ( Real.sqrt_le_iff.mpr ⟨ by linarith, by nlinarith [ sq_nonneg ( u - 1 ) ] ⟩ ) ) ) ( mul_nonneg ( by nlinarith ) ( Real.sqrt_nonneg _ ) )

/-- The main convexity result, expressed without the G'' wrapper:
2(1 - √(u(2-u))) / ((u(2-u))·√(u(2-u))) ≥ 0 for u ∈ (0,2). -/
theorem G_convex_aristotle (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    0 ≤ 2 * (1 - sqrt (u * (2 - u))) / ((u * (2 - u)) * sqrt (u * (2 - u))) := by
  exact div_nonneg (mul_nonneg zero_le_two (sub_nonneg.2 (Real.sqrt_le_iff.2
    ⟨by nlinarith, by nlinarith [u_mul_two_sub_u_le_one u]⟩)))
    (mul_nonneg (mul_nonneg hu0.le (by linarith)) (Real.sqrt_nonneg _))