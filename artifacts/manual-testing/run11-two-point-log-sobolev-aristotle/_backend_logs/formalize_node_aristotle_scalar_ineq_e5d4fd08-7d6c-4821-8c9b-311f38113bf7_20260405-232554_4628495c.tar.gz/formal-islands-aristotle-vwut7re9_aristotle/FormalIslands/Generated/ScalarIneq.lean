import Mathlib

open Real in
/-- The function G(u) = (√u - √(2-u))² - u·log(u) - (2-u)·log(2-u),
    with the convention 0·log(0) = 0. -/
noncomputable def G (u : ℝ) : ℝ :=
  (Real.sqrt u - Real.sqrt (2 - u)) ^ 2 - u * Real.log u - (2 - u) * Real.log (2 - u)

/-
The normalized one-variable inequality: G(u) ≥ 0 for all u ∈ [0, 2].
    This is the core scalar inequality underlying the two-point logarithmic Sobolev inequality.
-/
theorem scalar_ineq_aristotle (u : ℝ) (hu0 : 0 ≤ u) (hu2 : u ≤ 2) :
    0 ≤ G u := by
  -- Define $h(s) = G(1+s)$ for $s \in [-1,1]$. Then $h(s) = 2 - 2\sqrt{1-s^2} - (1+s)\log(1+s) - (1-s)\log(1-s)$.
  set h : ℝ → ℝ := fun s => 2 - 2 * Real.sqrt (1 - s ^ 2) - (1 + s) * Real.log (1 + s) - (1 - s) * Real.log (1 - s);
  -- We need to show that $h(s) \geq 0$ for all $s \in [-1, 1]$.
  have h_nonneg : ∀ s ∈ Set.Icc (-1 : ℝ) 1, 0 ≤ h s := by
    -- We'll use the fact that $h(s)$ is non-negative if its second derivative is non-negative.
    have h_second_deriv_nonneg : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, 0 ≤ deriv^[2] h s := by
      -- Let's calculate the first derivative of $h(s)$.
      have h_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv h s = 2 * s / Real.sqrt (1 - s ^ 2) - Real.log (1 + s) + Real.log (1 - s) := by
        intro s hs; refine' HasDerivAt.deriv _ ; convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) <| HasDerivAt.sqrt ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_pow 2 s ) _ ) ) <| HasDerivAt.mul ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ ) <| HasDerivAt.mul ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ using 1 <;> norm_num <;> ring;
        · grind;
        · nlinarith [ hs.1, hs.2 ];
        · linarith [ hs.1, hs.2 ];
        · linarith [ hs.1, hs.2 ];
      -- Let's calculate the second derivative of $h(s)$.
      have h_second_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv^[2] h s = 2 / (Real.sqrt (1 - s ^ 2)) ^ 3 - 1 / (1 + s) - 1 / (1 - s) := by
        intro s hs; refine' HasDerivAt.deriv _ ; convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hs.1 hs.2 ) fun x hx => h_deriv x hx ) using 1 ; ring;
        convert HasDerivAt.add ( HasDerivAt.sub ( HasDerivAt.mul ( HasDerivAt.mul ( hasDerivAt_id' s ) ( HasDerivAt.inv ( HasDerivAt.sqrt ( HasDerivAt.const_sub 1 ( hasDerivAt_pow 2 s ) ) ( by nlinarith [ hs.1, hs.2 ] ) ) ( ne_of_gt ( Real.sqrt_pos.mpr ( by nlinarith [ hs.1, hs.2 ] ) ) ) ) ) ( hasDerivAt_const _ _ ) ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_add 1 ) ( by nlinarith [ hs.1, hs.2 ] ) ) ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_sub 1 ) ( by nlinarith [ hs.1, hs.2 ] ) ) using 1 ; ring!;
        grind;
      intro s hs; rw [ h_second_deriv s hs ] ; rw [ div_sub_div, div_sub_div, le_div_iff₀ ] <;> norm_num;
      any_goals nlinarith [ hs.1, hs.2, Real.sqrt_nonneg ( 1 - s ^ 2 ), Real.mul_self_sqrt ( by nlinarith [ hs.1, hs.2 ] : 0 ≤ 1 - s ^ 2 ) ];
      · exact mul_pos ( mul_pos ( pow_pos ( Real.sqrt_pos.mpr ( by nlinarith [ hs.1, hs.2 ] ) ) 3 ) ( by nlinarith [ hs.1, hs.2 ] ) ) ( by nlinarith [ hs.1, hs.2 ] );
      · exact ⟨ ne_of_gt <| Real.sqrt_pos.mpr <| by nlinarith [ hs.1, hs.2 ], by nlinarith [ hs.1, hs.2 ] ⟩;
    -- Since $h(s)$ is convex and $h(0) = 0$, we have $h(s) \geq h(0) = 0$ for all $s \in [-1, 1]$.
    have h_convex : ConvexOn ℝ (Set.Icc (-1 : ℝ) 1) h := by
      apply_rules [ convexOn_of_deriv2_nonneg, convex_Icc ];
      · fun_prop;
      · norm_num +zetaDelta at *;
        exact fun x hx => DifferentiableAt.differentiableWithinAt ( by exact DifferentiableAt.sub ( DifferentiableAt.sub ( DifferentiableAt.sub ( differentiableAt_const _ ) ( DifferentiableAt.mul ( differentiableAt_const _ ) ( DifferentiableAt.sqrt ( by norm_num ) ( by nlinarith [ hx.1, hx.2 ] ) ) ) ) ( DifferentiableAt.mul ( differentiableAt_id.const_add _ ) ( DifferentiableAt.log ( differentiableAt_id.const_add _ ) ( by linarith [ hx.1, hx.2 ] ) ) ) ) ( DifferentiableAt.mul ( differentiableAt_id.const_sub _ ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hx.1, hx.2 ] ) ) ) );
      · -- Let's calculate the first derivative of $h$.
        have h_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv h s = (2 * s) / Real.sqrt (1 - s ^ 2) - Real.log (1 + s) + Real.log (1 - s) := by
          intro s hs;
          convert HasDerivAt.deriv ( HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( HasDerivAt.sqrt ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 s ) ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_id' s |> HasDerivAt.const_add _ ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_add _ ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_id' s |> HasDerivAt.const_sub _ ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_sub _ ) _ ) ) ) using 1 <;> norm_num <;> ring <;> try nlinarith [ hs.1, hs.2 ] ;
          grind;
        norm_num at *;
        exact DifferentiableOn.congr ( fun s hs => DifferentiableAt.differentiableWithinAt <| by exact DifferentiableAt.add ( DifferentiableAt.sub ( DifferentiableAt.div ( differentiableAt_id.const_mul _ ) ( DifferentiableAt.sqrt ( by norm_num ) <| by nlinarith [ hs.1, hs.2 ] ) <| ne_of_gt <| Real.sqrt_pos.mpr <| by nlinarith [ hs.1, hs.2 ] ) <| DifferentiableAt.log ( differentiableAt_id.const_add _ ) <| by linarith [ hs.1, hs.2 ] ) <| DifferentiableAt.log ( differentiableAt_id.const_sub _ ) <| by linarith [ hs.1, hs.2 ] ) fun s hs => h_deriv s hs.1 hs.2;
      · aesop;
    -- Since $h(s)$ is convex and $h(0) = 0$, we have $h(s) \geq h(0) = 0$ for all $s \in [-1, 1]$ by the definition of convexity.
    intros s hs
    have h_midpoint : h ((1 / 2) * s + (1 / 2) * (-s)) ≤ (1 / 2) * h s + (1 / 2) * h (-s) := by
      exact h_convex.2 hs ( show -s ∈ Set.Icc ( -1 ) 1 from ⟨ by linarith [ hs.1, hs.2 ], by linarith [ hs.1, hs.2 ] ⟩ ) ( by norm_num ) ( by norm_num ) ( by norm_num );
    simp +zetaDelta at *;
    grind;
  convert h_nonneg ( u - 1 ) ⟨ by linarith, by linarith ⟩ using 1 ; ring;
  unfold G h; ring;
  rw [ Real.sq_sqrt ( by linarith ), Real.sq_sqrt ( by linarith ) ] ; rw [ ← Real.sqrt_mul ( by linarith ) ] ; ring;