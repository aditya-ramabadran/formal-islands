import Mathlib

open Real in
/-- The function G(u) = (√u - √(2-u))² - u·log(u) - (2-u)·log(2-u),
    with the convention 0·log(0) = 0. -/
noncomputable def G (u : ℝ) : ℝ :=
  (Real.sqrt u - Real.sqrt (2 - u)) ^ 2 - u * Real.log u - (2 - u) * Real.log (2 - u)

/-
The two-point logarithmic Sobolev inequality in normalized one-variable form:
    G(u) ≥ 0 for all u ∈ [0, 2].

    Proof sketch: G is continuous on [0,2] and smooth on (0,2). One checks G(1) = 0 and
    G'(1) = 0. The second derivative G''(u) ≥ 0 on (0,2) (convexity), so G attains its
    minimum at u = 1 where the derivative vanishes. Hence G(u) ≥ G(1) = 0.
-/
theorem scalar_ineq_aristotle (u : ℝ) (hu0 : 0 ≤ u) (hu2 : u ≤ 2) :
    0 ≤ G u := by
  -- We use the substitution $s = u - 1$, so $s \in [-1, 1]$ and $G(1 + s) = h(s)$ where $h(s) = 2 - 2\sqrt{1 - s^2} - (1+s)\log(1+s) - (1-s)\log(1-s)$.
  set s : ℝ := u - 1
  set h := fun s : ℝ => 2 - 2 * Real.sqrt (1 - s^2) - (1 + s) * Real.log (1 + s) - (1 - s) * Real.log (1 - s);
  -- We need to show that $h(s) \geq 0$ for $s \in [-1, 1]$. Notice that $h(s)$ is convex on $[-1, 1]$.
  have h_convex : ConvexOn ℝ (Set.Icc (-1 : ℝ) 1) h := by
    apply_rules [ convexOn_of_deriv2_nonneg, convex_Icc ];
    · refine' ContinuousOn.sub ( ContinuousOn.sub ( continuousOn_const.sub ( continuousOn_const.mul ( Real.continuous_sqrt.comp_continuousOn ( continuousOn_const.sub ( continuousOn_pow 2 ) ) ) ) ) _ ) _;
      · exact Continuous.continuousOn ( by simpa using Real.continuous_mul_log.comp ( continuous_const.add continuous_id' ) );
      · exact Continuous.continuousOn ( by exact Real.continuous_mul_log.comp ( continuous_const.sub continuous_id' ) );
    · norm_num [ DifferentiableOn ];
      exact fun x hx₁ hx₂ => DifferentiableAt.differentiableWithinAt <| by exact DifferentiableAt.sub ( DifferentiableAt.sub ( DifferentiableAt.sub ( differentiableAt_const _ ) <| DifferentiableAt.mul ( differentiableAt_const _ ) <| DifferentiableAt.sqrt ( by norm_num ) <| by nlinarith ) <| DifferentiableAt.mul ( differentiableAt_id.const_add _ ) <| DifferentiableAt.log ( differentiableAt_id.const_add _ ) <| by linarith ) <| DifferentiableAt.mul ( differentiableAt_id.const_sub _ ) <| DifferentiableAt.log ( differentiableAt_id.const_sub _ ) <| by linarith;
    · -- Let's calculate the first derivative of $h$.
      have h_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv h s = 2 * s / Real.sqrt (1 - s^2) - Real.log (1 + s) + Real.log (1 - s) := by
        intro s hs; refine' HasDerivAt.deriv _ ; convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) <| HasDerivAt.sqrt ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_pow 2 s ) _ ) ) <| HasDerivAt.mul ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ ) <| HasDerivAt.mul ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ using 1 <;> norm_num <;> ring;
        · grind;
        · nlinarith [ hs.1, hs.2 ];
        · linarith [ hs.1, hs.2 ];
        · linarith [ hs.1, hs.2 ];
      norm_num +zetaDelta at *;
      exact DifferentiableOn.congr ( fun x hx => DifferentiableAt.differentiableWithinAt <| by exact DifferentiableAt.add ( DifferentiableAt.sub ( DifferentiableAt.div ( differentiableAt_id.const_mul _ ) ( DifferentiableAt.sqrt ( by norm_num ) <| by nlinarith [ hx.1, hx.2 ] ) <| ne_of_gt <| Real.sqrt_pos.mpr <| by nlinarith [ hx.1, hx.2 ] ) <| DifferentiableAt.log ( differentiableAt_id.const_add _ ) <| by linarith [ hx.1, hx.2 ] ) <| DifferentiableAt.log ( differentiableAt_id.const_sub _ ) <| by linarith [ hx.1, hx.2 ] ) fun x hx => h_deriv x hx.1 hx.2;
    · -- Let's calculate the second derivative of $h(s)$.
      have h_second_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv^[2] h s = 2 / (1 - s^2)^(3 / 2 : ℝ) - 1 / (1 + s) - 1 / (1 - s) := by
        -- Let's calculate the first derivative of $h(s)$.
        have h_first_deriv : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, deriv h s = 2 * s / Real.sqrt (1 - s^2) - Real.log (1 + s) + Real.log (1 - s) := by
          intro s hs; refine' HasDerivAt.deriv _ ; convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) <| HasDerivAt.sqrt ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_pow 2 s ) _ ) ) <| HasDerivAt.mul ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.add ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ ) <| HasDerivAt.mul ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) <| HasDerivAt.log ( HasDerivAt.sub ( hasDerivAt_const _ _ ) <| hasDerivAt_id s ) _ using 1 <;> norm_num <;> ring;
          · grind;
          · nlinarith [ hs.1, hs.2 ];
          · linarith [ hs.1, hs.2 ];
          · linarith [ hs.1, hs.2 ];
        intro s hs; refine' HasDerivAt.deriv _ ; convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hs.1 hs.2 ) fun x hx => h_first_deriv x hx ) using 1 ; ring;
        convert HasDerivAt.add ( HasDerivAt.sub ( HasDerivAt.mul ( HasDerivAt.mul ( hasDerivAt_id' s ) ( HasDerivAt.inv ( HasDerivAt.sqrt ( HasDerivAt.const_sub 1 ( hasDerivAt_pow 2 s ) ) ( by nlinarith [ hs.1, hs.2 ] ) ) ( ne_of_gt ( Real.sqrt_pos.mpr ( by nlinarith [ hs.1, hs.2 ] ) ) ) ) ) ( hasDerivAt_const _ _ ) ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_add 1 ) ( by linarith [ hs.1, hs.2 ] ) ) ) ( HasDerivAt.log ( hasDerivAt_id' s |> HasDerivAt.const_sub 1 ) ( by linarith [ hs.1, hs.2 ] ) ) using 1 ; ring;
        rw [ inv_pow, Real.sqrt_eq_rpow, ← Real.rpow_natCast _ 3, ← Real.rpow_mul ( by nlinarith [ hs.1, hs.2 ] ) ] ; norm_num ; ring;
        rw [ show ( 3 / 2 : ℝ ) = 1 + 1 / 2 by norm_num, Real.rpow_add ( by nlinarith [ hs.1, hs.2 ] ), Real.rpow_one ] ; rw [ Real.sqrt_eq_rpow ] ; ring;
        grind +splitIndPred;
      -- We need to show that $2 / (1 - s^2)^{3/2} - 1 / (1 + s) - 1 / (1 - s) \geq 0$ for $s \in (-1, 1)$.
      have h_nonneg : ∀ s ∈ Set.Ioo (-1 : ℝ) 1, 2 / (1 - s^2)^(3 / 2 : ℝ) ≥ 1 / (1 + s) + 1 / (1 - s) := by
        intro s hs; rw [ div_add_div, ge_iff_le, div_le_div_iff₀ ] <;> norm_num <;> try nlinarith [ hs.1, hs.2 ] ;
        · rw [ show ( 3 / 2 : ℝ ) = 1 + 1 / 2 by norm_num, Real.rpow_add' ] <;> norm_num;
          · rw [ ← Real.sqrt_eq_rpow ] ; nlinarith [ hs.1, hs.2, Real.sqrt_nonneg ( 1 - s ^ 2 ), Real.mul_self_sqrt ( by nlinarith [ hs.1, hs.2 ] : 0 ≤ 1 - s ^ 2 ) ] ;
          · exact abs_le.mpr ⟨ by linarith [ hs.1 ], by linarith [ hs.2 ] ⟩;
        · exact Real.rpow_pos_of_pos ( by nlinarith [ hs.1, hs.2 ] ) _;
      exact fun x hx => h_second_deriv x ( by simpa using hx ) ▸ by linarith [ h_nonneg x ( by simpa using hx ) ] ;
  -- Since $h$ is convex on $[-1, 1]$ and $h(0) = 0$, we have $h(s) \geq h(0) + h'(0)(s - 0)$ for all $s \in [-1, 1]$.
  have h_lower_bound : ∀ s ∈ Set.Icc (-1 : ℝ) 1, h s ≥ h 0 + deriv h 0 * (s - 0) := by
    have h_lower_bound : ∀ s ∈ Set.Icc (-1 : ℝ) 1, h s ≥ h 0 + deriv h 0 * (s - 0) := by
      intro s hs
      have h_convexity : ∀ t ∈ Set.Ioo 0 1, (h (t * s) - h 0) / t ≤ h s - h 0 := by
        intros t ht
        have h_convexity : h (t * s) ≤ t * h s + (1 - t) * h 0 := by
          have := h_convex.2;
          simpa using @this s hs 0 ( by norm_num ) t ( 1 - t ) ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] );
        rw [ div_le_iff₀ ] <;> linarith [ ht.1, ht.2 ]
      -- Taking the limit of $h_convexity$ as $t$ approaches $0$ from the right, we get the desired inequality.
      have h_limit : Filter.Tendsto (fun t => (h (t * s) - h 0) / t) (nhdsWithin 0 (Set.Ioi 0)) (nhds (deriv h 0 * s)) := by
        have h_limit : HasDerivAt (fun t => h (t * s)) (deriv h 0 * s) 0 := by
          convert HasDerivAt.comp 0 ( show HasDerivAt h _ _ from hasDerivAt_deriv_iff.mpr ?_ ) ( HasDerivAt.mul ( hasDerivAt_id 0 ) ( hasDerivAt_const _ _ ) ) using 1 <;> norm_num;
          exact DifferentiableAt.sub ( DifferentiableAt.sub ( DifferentiableAt.sub ( differentiableAt_const _ ) ( DifferentiableAt.mul ( differentiableAt_const _ ) ( DifferentiableAt.sqrt ( by norm_num ) ( by norm_num ) ) ) ) ( DifferentiableAt.mul ( differentiableAt_id.const_add _ ) ( DifferentiableAt.log ( differentiableAt_id.const_add _ ) ( by norm_num ) ) ) ) ( DifferentiableAt.mul ( differentiableAt_id.const_sub _ ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by norm_num ) ) );
        simpa [ div_eq_inv_mul ] using h_limit.tendsto_slope_zero_right;
      simp +zetaDelta at *;
      exact le_of_tendsto h_limit ( Filter.eventually_of_mem ( Ioo_mem_nhdsGT_of_mem ⟨ by norm_num, by norm_num ⟩ ) fun t ht => h_convexity t ht.1 ht.2 );
    assumption;
  -- Since $h(0) = 0$ and $h'(0) = 0$, we have $h(s) \geq 0$ for all $s \in [-1, 1]$.
  have h_zero : h 0 = 0 ∧ deriv h 0 = 0 := by
    norm_num +zetaDelta at *;
    convert HasDerivAt.deriv ( HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( HasDerivAt.sqrt ( HasDerivAt.sub ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 _ ) ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_id 0 |> HasDerivAt.const_add _ ) ( HasDerivAt.log ( hasDerivAt_id 0 |> HasDerivAt.const_add _ ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_id 0 |> HasDerivAt.const_sub _ ) ( HasDerivAt.log ( hasDerivAt_id 0 |> HasDerivAt.const_sub _ ) _ ) ) ) using 1 <;> norm_num;
  convert h_lower_bound s ⟨ by linarith, by linarith ⟩ |> le_trans _ using 1;
  · unfold G h; ring;
    rw [ Real.sq_sqrt ( by linarith ), Real.sq_sqrt ( by linarith ) ] ; rw [ show 1 - ( u - 1 ) ^ 2 = u * ( 2 - u ) by ring ] ; rw [ Real.sqrt_mul ( by linarith ) ] ; ring;
    grind;
  · norm_num [ h_zero ]