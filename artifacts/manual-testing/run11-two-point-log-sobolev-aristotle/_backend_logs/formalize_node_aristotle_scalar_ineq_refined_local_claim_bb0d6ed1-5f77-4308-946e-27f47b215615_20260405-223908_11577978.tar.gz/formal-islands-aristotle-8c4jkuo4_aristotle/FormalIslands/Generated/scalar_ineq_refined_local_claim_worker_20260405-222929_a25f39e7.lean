/-
  Formalization of: Critical point of G at u=1: G'(1)=0

  In the context of the two-point logarithmic Sobolev inequality, we define
  G(u) = 2 - 2√(u(2-u)) - u·log(u) - (2-u)·log(2-u)  for u ∈ (0,2),
  whose derivative is
  G'(u) = 2(u-1)/√(u(2-u)) - log(u/(2-u)).

  We prove that G'(1) = 0 (and G(1) = 0), establishing u=1 as a critical point.
  Together with convexity of G, this shows u=1 is the global minimizer and G ≥ 0.
-/
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real

noncomputable section

open Real

/-- The function G(u) = 2 - 2√(u(2-u)) - u·log(u) - (2-u)·log(2-u)
    arising in the two-point logarithmic Sobolev inequality. -/
def G (u : ℝ) : ℝ := 2 - 2 * sqrt (u * (2 - u)) - u * log u - (2 - u) * log (2 - u)

/-- The derivative formula G'(u) = 2(u-1)/√(u(2-u)) - log(u/(2-u)). -/
def G_deriv (u : ℝ) : ℝ := 2 * (u - 1) / sqrt (u * (2 - u)) - log (u / (2 - u))

/-
**Critical point of G at u=1: G'(1)=0.**

The derivative of G at u=1 vanishes:
  G'(1) = 2(1-1)/√(1·1) - log(1/1) = 0 - 0 = 0.
Equivalently, u=1 is a critical point of G on (0,2).
This is the key fact that, combined with convexity of G, shows u=1 is
the global minimizer and hence G ≥ 0, yielding the two-point log-Sobolev inequality.
-/
theorem scalar_ineq_refined_local_claim_aristotle : G_deriv 1 = 0 := by
  unfold G_deriv; norm_num;

/-
The value of G at the critical point is zero: G(1) = 0.
-/
theorem G_at_one : G 1 = 0 := by
  unfold G; norm_num;

end