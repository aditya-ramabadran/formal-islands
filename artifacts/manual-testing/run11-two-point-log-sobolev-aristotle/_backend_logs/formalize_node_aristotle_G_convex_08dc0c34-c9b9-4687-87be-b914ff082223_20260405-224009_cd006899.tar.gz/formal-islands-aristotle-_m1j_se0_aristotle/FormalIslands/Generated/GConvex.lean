import Mathlib

open Real

/-!
# Convexity of G: G''(u) ≥ 0 on (0, 2)

We formalize the key nonnnegativity result for the second derivative of the function
G arising in the two-point logarithmic Sobolev inequality.

The second derivative is:
  G''(u) = 2(1 - √(u(2-u))) / (u(2-u))^(3/2)

We express (u(2-u))^(3/2) as (u(2-u)) * √(u(2-u)) to avoid `rpow`.

The proof uses the identity u(2-u) = 1 - (u-1)² ≤ 1, so √(u(2-u)) ≤ 1,
making the numerator nonnegative, and the denominator is positive on (0,2).
-/

/-
For any real u, u * (2 - u) ≤ 1. This is because u*(2-u) = 1 - (u-1)².
-/
lemma u_mul_two_sub_u_le_one (u : ℝ) : u * (2 - u) ≤ 1 := by
  linarith [ sq_nonneg ( u - 1 ) ]

/-
For any real u, √(u(2-u)) ≤ 1.
-/
lemma sqrt_u_mul_two_sub_u_le_one (u : ℝ) : sqrt (u * (2 - u)) ≤ 1 := by
  rw [ Real.sqrt_le_left ] <;> linarith [ sq_nonneg ( u - 1 ) ]

/-
For u ∈ (0,2), the product u*(2-u) is positive.
-/
lemma u_mul_two_sub_u_pos (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    0 < u * (2 - u) := by
  nlinarith

/-
**Convexity of G**: For u ∈ (0, 2), the second derivative of G satisfies
G''(u) = 2(1 - √(u(2-u))) / (u(2-u))^(3/2) ≥ 0.

Expressed without rpow: 2 * (1 - √(u(2-u))) / ((u(2-u)) * √(u(2-u))) ≥ 0.

Since u(2-u) = 1-(u-1)² ≤ 1, we have √(u(2-u)) ≤ 1, so the numerator is
nonnegative. The denominator is positive for u ∈ (0,2).
-/
theorem G_convex_aristotle (u : ℝ) (hu0 : 0 < u) (hu2 : u < 2) :
    0 ≤ 2 * (1 - sqrt (u * (2 - u))) / ((u * (2 - u)) * sqrt (u * (2 - u))) := by
  exact div_nonneg ( mul_nonneg zero_le_two ( sub_nonneg.2 ( Real.sqrt_le_iff.2 ⟨ by nlinarith, by nlinarith [ u_mul_two_sub_u_le_one u ] ⟩ ) ) ) ( mul_nonneg ( mul_nonneg hu0.le ( by linarith ) ) ( Real.sqrt_nonneg _ ) )