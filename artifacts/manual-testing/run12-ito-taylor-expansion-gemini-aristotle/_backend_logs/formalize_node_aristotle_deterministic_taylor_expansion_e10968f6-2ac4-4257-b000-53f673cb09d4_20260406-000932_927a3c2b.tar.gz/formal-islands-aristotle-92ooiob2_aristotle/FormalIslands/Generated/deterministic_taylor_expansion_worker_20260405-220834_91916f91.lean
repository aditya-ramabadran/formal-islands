/-
Deterministic Taylor expansion for increments of a C² function.

This formalizes the following result: Let f : ℝ → ℝ be a C² function and let
ω be a modulus of continuity for f''. For any finite sequence B₀, B₁, …, Bₙ,
letting ΔBₖ = B_{k+1} - Bₖ,

  f(Bₙ) - f(B₀) = Σₖ f'(Bₖ) ΔBₖ + ½ Σₖ f''(Bₖ)(ΔBₖ)² + Rₙ

where |Rₙ| ≤ ½ · ω(max|ΔBₖ|) · Σₖ (ΔBₖ)².
-/
import Mathlib.Analysis.Calculus.Taylor
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Analysis.Calculus.IteratedDeriv.Defs
import Mathlib.Analysis.SpecificLimits.Basic

open Finset BigOperators Set

noncomputable section

/-! ### Single-step Taylor bound -/

/-
For a C² function f : ℝ → ℝ, if ω is a modulus of continuity for f'' (i.e.,
|f''(x) - f''(y)| ≤ ω(|x - y|) for all x, y, and ω is monotone), then
for any a, b : ℝ,

  |f(b) - f(a) - f'(a)(b - a) - ½ f''(a)(b - a)²| ≤ ½ ω(|b - a|) (b - a)².

The proof uses the Lagrange form of Taylor's remainder: there exists ξ between
a and b such that f(b) = f(a) + f'(a)(b-a) + ½ f''(ξ)(b-a)², so the remainder
is ½(f''(ξ) - f''(a))(b-a)², bounded by ½ ω(|b-a|)(b-a)².
-/
theorem taylor_single_step_bound
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_mono : Monotone ω)
    (hω_mod : ∀ x y, |iteratedDeriv 2 f x - iteratedDeriv 2 f y| ≤ ω (|x - y|))
    (a b : ℝ) :
    |f b - f a - deriv f a * (b - a) - 1 / 2 * iteratedDeriv 2 f a * (b - a) ^ 2| ≤
    1 / 2 * ω (|b - a|) * (b - a) ^ 2 := by
      rcases lt_trichotomy a b with ( h | rfl | h ) <;> norm_num at *;
      · -- Use taylor_mean_remainder_lagrange_iteratedDeriv with n := 1 to get ξ ∈ Ioo a b such that f b - taylorWithinEval f 1 (Icc a b) a b = iteratedDeriv 2 f ξ * (b-a)^2 / 2!.
        obtain ⟨ξ, hξ⟩ : ∃ ξ ∈ Set.Ioo a b, f b = f a + (deriv f a) * (b - a) + (1 / 2) * (iteratedDeriv 2 f ξ) * (b - a) ^ 2 := by
          have := @taylor_mean_remainder_lagrange_iteratedDeriv;
          specialize @this f b a 1 ; norm_num at this;
          exact this h ( hf.contDiffOn ) |> fun ⟨ x', hx', hx'' ⟩ => ⟨ x', hx', by rw [ show derivWithin f ( Set.Icc a b ) a = deriv f a from by rw [ derivWithin ] ; exact HasDerivWithinAt.derivWithin ( by exact DifferentiableAt.hasDerivAt ( hf.contDiffAt.differentiableAt ( by norm_num ) ) |> HasDerivAt.hasDerivWithinAt ) ( uniqueDiffOn_Icc ( by linarith ) _ ( by constructor <;> linarith ) ) ] at hx'' ; linarith ⟩;
        rw [ abs_le ] ; constructor <;> nlinarith [ abs_le.mp ( hω_mod ξ a ), abs_of_pos ( sub_pos.mpr h ), hω_mono ( show |ξ - a| ≤ |b - a| by cases abs_cases ( ξ - a ) <;> cases abs_cases ( b - a ) <;> linarith [ hξ.1.1, hξ.1.2 ] ) ] ;
      · -- For $b < a$, use the Lagrange form of Taylor's remainder with $n = 1$ for $f$ restricted to $[b, a]$.
        obtain ⟨ξ, hξ⟩ : ∃ ξ ∈ Set.Ioo b a, iteratedDeriv 2 f ξ = (2 * (f b - f a - deriv f a * (b - a))) / ((b - a) ^ 2) := by
          -- Apply the mean value theorem to the interval $[b, a]$.
          have h_mvt : ∃ ξ ∈ Set.Ioo b a, deriv (fun x => f x - f a - deriv f a * (x - a) - (f b - f a - deriv f a * (b - a)) / ((b - a) ^ 2) * (x - a) ^ 2) ξ = 0 := by
            apply_rules [ exists_deriv_eq_zero ];
            · exact ContinuousOn.sub ( ContinuousOn.sub ( ContinuousOn.sub ( hf.continuous.continuousOn ) ( continuousOn_const ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const ) ) ) ( continuousOn_const.mul ( continuousOn_id.sub continuousOn_const |> ContinuousOn.pow <| 2 ) );
            · rw [ div_mul_cancel₀ _ ( pow_ne_zero 2 ( sub_ne_zero_of_ne h.ne ) ) ] ; ring;
          norm_num [ hf.contDiffAt.differentiableAt, iteratedDeriv_succ' ] at *;
          -- Apply the mean value theorem to the interval $[ξ, a]$.
          obtain ⟨η, hη⟩ : ∃ η ∈ Set.Ioo (h_mvt.choose) a, deriv (deriv f) η = (deriv f a - deriv f h_mvt.choose) / (a - h_mvt.choose) := by
            apply_rules [ exists_deriv_eq_slope ];
            · linarith [ h_mvt.choose_spec ];
            · exact hf.continuous_deriv ( by norm_num ) |> Continuous.continuousOn;
            · fun_prop;
          grind;
        -- Substitute $ξ$ into the inequality from the Lagrange form.
        have h_sub : |iteratedDeriv 2 f ξ - iteratedDeriv 2 f a| ≤ ω |b - a| := by
          exact le_trans ( hω_mod _ _ ) ( hω_mono ( by cases abs_cases ( ξ - a ) <;> cases abs_cases ( b - a ) <;> linarith [ hξ.1.1, hξ.1.2 ] ) );
        rw [ abs_le ] at *;
        constructor <;> nlinarith [ mul_div_cancel₀ ( 2 * ( f b - f a - deriv f a * ( b - a ) ) ) ( by nlinarith : ( b - a ) ^ 2 ≠ 0 ) ]

/-! ### Main theorem: deterministic Taylor expansion for increments -/

/-- The maximum absolute increment of a sequence B over indices 0..n-1. -/
def maxAbsIncrement (B : ℕ → ℝ) (n : ℕ) : ℝ :=
  Finset.fold max 0 (fun k => |B (k + 1) - B k|) (Finset.range n)

/-
Each |ΔBₖ| is at most the maximum absolute increment.
-/
lemma le_maxAbsIncrement (B : ℕ → ℝ) (n : ℕ) (k : ℕ) (hk : k < n) :
    |B (k + 1) - B k| ≤ maxAbsIncrement B n := by
      -- By definition of maxAbsIncrement, we know that |B (k + 1) - B k| ≤ maxAbsIncrement B n for any k < n.
      have h_max : ∀ n, ∀ k < n, |B (k + 1) - B k| ≤ (Finset.range n).fold max 0 (fun k => |B (k + 1) - B k|) := by
        intro n k hk; induction' hk with n h IH <;> simp_all +decide [ Finset.range_add_one ] ;
      exact h_max n k hk

/-
**Deterministic Taylor expansion for increments.**

Let f : ℝ → ℝ be a C² function and ω a modulus of continuity for f''.
For any finite sequence B : ℕ → ℝ and any n, there exists R such that

  f(B n) - f(B 0) = Σ_{k<n} f'(B k) · ΔBₖ + ½ Σ_{k<n} f''(B k) · (ΔBₖ)² + R

and |R| ≤ ½ · ω(maxΔ) · Σ_{k<n} (ΔBₖ)², where maxΔ = max_{k<n} |ΔBₖ|.
-/
theorem deterministic_taylor_expansion_aristotle
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ x, 0 ≤ x → 0 ≤ ω x) (hω_mono : Monotone ω)
    (hω_mod : ∀ x y, |iteratedDeriv 2 f x - iteratedDeriv 2 f y| ≤ ω (|x - y|))
    (n : ℕ) (B : ℕ → ℝ) :
    ∃ R : ℝ,
      f (B n) - f (B 0) =
        ∑ k ∈ range n, deriv f (B k) * (B (k+1) - B k) +
        1 / 2 * ∑ k ∈ range n, iteratedDeriv 2 f (B k) * (B (k+1) - B k) ^ 2 + R ∧
      |R| ≤ 1 / 2 * ω (maxAbsIncrement B n) *
        ∑ k ∈ range n, (B (k+1) - B k) ^ 2 := by
          refine' ⟨ _, _, _ ⟩;
          exact ∑ k ∈ Finset.range n, ( f ( B ( k + 1 ) ) - f ( B k ) - deriv f ( B k ) * ( B ( k + 1 ) - B k ) - 1 / 2 * iteratedDeriv 2 f ( B k ) * ( B ( k + 1 ) - B k ) ^ 2 );
          · exact Nat.recOn n ( by norm_num ) fun n ih => by norm_num [ Finset.sum_range_succ ] at * ; linarith;
          · rw [ Finset.mul_sum _ _ _ ];
            refine' le_trans ( Finset.abs_sum_le_sum_abs _ _ ) ( Finset.sum_le_sum fun i hi => _ );
            refine' le_trans ( taylor_single_step_bound f hf ω hω_mono hω_mod ( B i ) ( B ( i + 1 ) ) ) _;
            gcongr;
            exact hω_mono ( le_maxAbsIncrement B n i ( Finset.mem_range.mp hi ) )

end