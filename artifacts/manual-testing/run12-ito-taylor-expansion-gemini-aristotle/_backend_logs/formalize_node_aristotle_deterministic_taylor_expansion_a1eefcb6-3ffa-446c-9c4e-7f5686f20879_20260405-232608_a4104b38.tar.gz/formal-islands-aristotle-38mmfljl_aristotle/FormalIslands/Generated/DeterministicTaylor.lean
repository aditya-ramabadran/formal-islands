/-
Deterministic Taylor expansion for increments of a C² function.

This formalizes the following result: Let f : ℝ → ℝ be a C² function and let
ω be a modulus of continuity for f''. For any finite sequence B₀, B₁, …, Bₙ,
letting ΔBₖ = B_{k+1} - Bₖ,

  f(Bₙ) - f(B₀) = Σₖ f'(Bₖ) ΔBₖ + ½ Σₖ f''(Bₖ)(ΔBₖ)² + Rₙ

where |Rₙ| ≤ ½ · ω(max|ΔBₖ|) · Σₖ (ΔBₖ)².
-/
import Mathlib.Analysis.Calculus.Taylor

open Finset BigOperators Set

noncomputable section

/-! ### Step 1: Lagrange form of Taylor for globally C² functions -/

/-
For a globally C² function f and a < b, there exists ξ ∈ (a, b) such that
f(b) - f(a) - f'(a)(b-a) = (1/2) f''(ξ) (b-a)².
-/
lemma taylor_lagrange_C2 (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f) (a b : ℝ) (hab : a < b) :
    ∃ ξ ∈ Ioo a b,
      f b - f a - deriv f a * (b - a) =
        1 / 2 * iteratedDeriv 2 f ξ * (b - a) ^ 2 := by
          -- By the Lagrange form of Taylor's remainder for n=1, there exists ξ ∈ (a, b) such that
          obtain ⟨ξ, hξ⟩ : ∃ ξ ∈ Set.Ioo a b, f b - (f a + deriv f a * (b - a)) = (iteratedDeriv (1 + 1) f ξ) * (b - a) ^ (1 + 1) / ((1 + 1).factorial : ℝ) := by
            convert taylor_mean_remainder_lagrange_iteratedDeriv hab ( hf.contDiffOn ) using 1;
            norm_num [ Finset.sum_range_succ, taylorCoeffWithin ];
            rw [ derivWithin ];
            rw [ fderivWithin_eq_fderiv ] <;> norm_num [ mul_comm ];
            · exact uniqueDiffOn_Icc ( by linarith ) a ( by norm_num; linarith );
            · exact hf.contDiffAt.differentiableAt ( by norm_num );
          exact ⟨ ξ, hξ.1, by norm_num [ Nat.factorial ] at hξ; linear_combination hξ.2 ⟩

/-! ### Step 2: Single-step bound from Lagrange form -/

/-
The single-step bound for a < b.
-/
lemma taylor_single_step_bound_lt
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ x, 0 ≤ x → 0 ≤ ω x) (hω_mono : Monotone ω)
    (hω_mod : ∀ x y, |iteratedDeriv 2 f x - iteratedDeriv 2 f y| ≤ ω (|x - y|))
    (a b : ℝ) (hab : a < b) :
    |f b - f a - deriv f a * (b - a) - 1 / 2 * iteratedDeriv 2 f a * (b - a) ^ 2| ≤
    1 / 2 * ω (|b - a|) * (b - a) ^ 2 := by
      have := @taylor_lagrange_C2 f hf a b hab;
      obtain ⟨ ξ, hξ₁, hξ₂ ⟩ := this; rw [ abs_le ] ; constructor <;> nlinarith [ abs_le.mp ( hω_mod ξ a ), abs_sub_comm a ξ, mul_le_mul_of_nonneg_right ( hω_mono ( show |ξ - a| ≤ |b - a| by cases abs_cases ( ξ - a ) <;> cases abs_cases ( b - a ) <;> linarith [ hξ₁.1, hξ₁.2 ] ) ) ( sq_nonneg ( b - a ) ) ] ;

/-
The function t ↦ f(a - t) is C².
-/
lemma contDiff_comp_neg (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f) (a : ℝ) :
    ContDiff ℝ 2 (fun t => f (a - t)) := by
      -- Assume f is a C^k function. We need to show f(a - t) is C^k.
      set g : ℝ → ℝ := fun t => f (a - t);
      have h_cont_diff : ContDiff ℝ 2 (fun t => f t) := by
        exact hf;
      -- By definition of $g$, we know that its second derivative is given by the second derivative of $f$ evaluated at $a - t$.
      have h_deriv2_g : ∀ t, deriv (deriv g) t = deriv (deriv f) (a - t) := by
        rw [ show deriv g = fun t => deriv f ( a - t ) * ( -1 ) from funext fun t => ?_ ];
        · intro t; rw [ show deriv ( fun t => deriv f ( a - t ) * -1 ) t = deriv ( fun t => deriv f ( a - t ) ) t * ( -1 ) by simp +decide [ mul_comm ] ] ; rw [ show deriv ( fun t => deriv f ( a - t ) ) t = deriv ( deriv f ∘ fun t => a - t ) t by rfl ] ; rw [ deriv_comp ] <;> norm_num [ sub_eq_add_neg ];
          · fun_prop;
          · exact differentiableAt_id.neg;
        · exact HasDerivAt.deriv ( by simpa using HasDerivAt.scomp t ( h_cont_diff.contDiffAt.differentiableAt ( by norm_num ) |> DifferentiableAt.hasDerivAt ) ( hasDerivAt_id t |> HasDerivAt.const_sub a ) );
      -- Since $f$ is $C^2$, its second derivative is continuous.
      have h_cont_diff_second : Continuous (deriv (deriv f)) := by
        fun_prop;
      -- Since $deriv (deriv f)$ is continuous, $deriv (deriv g)$ is also continuous.
      have h_cont_diff_second_g : Continuous (deriv (deriv g)) := by
        rw [ show deriv ( deriv g ) = _ from funext h_deriv2_g ] ; exact h_cont_diff_second.comp ( continuous_const.sub continuous_id' ) ;
      have h_cont_diff_g : ContDiff ℝ 1 (deriv g) := by
        rw [ contDiff_one_iff_deriv ];
        have h_diff_g : Differentiable ℝ (deriv g) := by
          have h_diff_f : Differentiable ℝ (deriv f) := by
            fun_prop
          have h_diff_g : Differentiable ℝ (fun t => -deriv f (a - t)) := by
            exact Differentiable.neg ( h_diff_f.comp ( differentiable_id.const_sub a ) );
          convert h_diff_g using 1;
          ext t; erw [ deriv_comp ] <;> norm_num [ h_cont_diff.contDiffAt.differentiableAt, sub_eq_add_neg ];
          · erw [ deriv_sub ] <;> norm_num;
          · exact differentiableAt_id.const_sub _;
        exact ⟨ h_diff_g, h_cont_diff_second_g ⟩;
      have h_cont_diff_g : ContDiff ℝ (1 + 1) g := by
        rw [ contDiff_succ_iff_deriv ];
        exact ⟨ Differentiable.comp ( h_cont_diff.differentiable ( by norm_num ) ) ( differentiable_id.const_sub _ ), by norm_num, h_cont_diff_g ⟩;
      exact h_cont_diff_g

/-
The second iterated derivative of t ↦ f(a - t) equals f'' at the reflected point.
-/
lemma iteratedDeriv_comp_neg (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f) (a t : ℝ) :
    iteratedDeriv 2 (fun t => f (a - t)) t = iteratedDeriv 2 f (a - t) := by
      have h_deriv_comp_neg : iteratedDeriv 1 (fun t => f (a - t)) = fun t => -deriv f (a - t) := by
        exact funext fun x => by simpa [ iteratedDeriv_succ ] using deriv_comp x ( show DifferentiableAt ℝ f _ from hf.contDiffAt.differentiableAt ( by norm_num ) ) ( show DifferentiableAt ℝ ( fun t => a - t ) _ from differentiableAt_id.const_sub _ ) |> fun h => h.trans ( by norm_num [ sub_eq_add_neg ] ) ;
      simp_all +decide [ iteratedDeriv_succ ];
      convert congr_arg Neg.neg ( HasDerivAt.deriv ( HasDerivAt.comp t ( show HasDerivAt ( deriv f ) _ _ from hasDerivAt_deriv_iff.mpr ?_ ) ( hasDerivAt_id' t |> HasDerivAt.const_sub a ) ) ) using 1 ; ring!;
      fun_prop

/-
The first derivative of t ↦ f(a - t) equals -f' at the reflected point.
-/
lemma deriv_comp_neg (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f) (a t : ℝ) :
    deriv (fun t => f (a - t)) t = -(deriv f (a - t)) := by
      exact HasDerivAt.deriv ( by simpa using HasDerivAt.comp t ( hf.contDiffAt.differentiableAt ( by norm_num ) |> DifferentiableAt.hasDerivAt ) ( hasDerivAt_id t |> HasDerivAt.const_sub a ) )

/-
For a C² function, the single-step Taylor remainder satisfies a bound
in terms of a modulus of continuity of f''.
-/
theorem taylor_single_step_bound
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ x, 0 ≤ x → 0 ≤ ω x) (hω_mono : Monotone ω)
    (hω_mod : ∀ x y, |iteratedDeriv 2 f x - iteratedDeriv 2 f y| ≤ ω (|x - y|))
    (a b : ℝ) :
    |f b - f a - deriv f a * (b - a) - 1 / 2 * iteratedDeriv 2 f a * (b - a) ^ 2| ≤
    1 / 2 * ω (|b - a|) * (b - a) ^ 2 := by
      cases eq_or_ne a b <;> simp_all +decide [ abs_sub_comm ];
      cases lt_or_gt_of_ne ‹_› <;> simp_all +decide [ abs_sub_comm, mul_comm ];
      · have := taylor_single_step_bound_lt f hf ω hω_nonneg hω_mono hω_mod a b ‹_›; simp_all +decide [ mul_comm, mul_assoc, mul_left_comm ] ;
        simpa only [ abs_sub_comm ] using this;
      · convert taylor_single_step_bound_lt ( fun t => f ( a - t ) ) ( contDiff_comp_neg f hf a ) ω hω_nonneg hω_mono _ 0 ( a - b ) ( by linarith ) using 1 <;> norm_num [ abs_sub_comm ] ; ring;
        · rw [ show iteratedDeriv 2 ( fun t => f ( a - t ) ) 0 = iteratedDeriv 2 f a by simpa using iteratedDeriv_comp_neg f hf a 0 ] ; rw [ show deriv ( fun t => f ( a - t ) ) 0 = -deriv f a by simpa using deriv_comp_neg f hf a 0 ] ; rw [ ← abs_neg ] ; ring;
        · ring;
        · intro x y; convert hω_mod ( a - x ) ( a - y ) using 1 ; ring;
          · rw [ iteratedDeriv_comp_neg, iteratedDeriv_comp_neg ];
            · assumption;
            · assumption;
          · rw [ ← abs_neg ] ; ring;

/-! ### Main theorem: deterministic Taylor expansion for increments -/

/-- The maximum absolute increment of a sequence B over indices 0..n-1. -/
def maxAbsIncrement (B : ℕ → ℝ) (n : ℕ) : ℝ :=
  Finset.fold max 0 (fun k => |B (k + 1) - B k|) (Finset.range n)

/-- The telescoping identity for sums. -/
lemma telescoping_sum (f : ℝ → ℝ) (n : ℕ) (B : ℕ → ℝ) :
    f (B n) - f (B 0) = ∑ k ∈ range n, (f (B (k + 1)) - f (B k)) := by
  rw [Finset.sum_range_sub (fun k => f (B k))]

/-- Each |ΔBₖ| is at most the maximum absolute increment. -/
lemma le_maxAbsIncrement (B : ℕ → ℝ) (n : ℕ) (k : ℕ) (hk : k < n) :
    |B (k + 1) - B k| ≤ maxAbsIncrement B n := by
  unfold maxAbsIncrement
  induction hk <;> simp_all +decide [Finset.range_add_one]

/-
**Deterministic Taylor expansion for increments.**

Let f : ℝ → ℝ be a C² function and ω a modulus of continuity for f''.
For any finite sequence B : ℕ → ℝ and any n, there exists R such that

  f(B n) - f(B 0) = Σ_{k<n} f'(B k) · ΔBₖ + ½ Σ_{k<n} f''(B k) · (ΔBₖ)² + R

and |R| ≤ ½ · ω(maxΔ) · Σ_{k<n} (ΔBₖ)², where maxΔ = max_{k<n} |ΔBₖ|.
-/
theorem deterministic_taylor_expansion_aristotle
    (f : ℝ → ℝ) (hf : ContDiff ℝ 2 f)
    (ω : ℝ → ℝ) (hω_nonneg : ∀ x, 0 ≤ x → 0 ≤ ω x) (hω_mono : Monotone ω)
    (hω_mod : ∀ x y, |iteratedDeriv 2 f x - iteratedDeriv 2 f y| ≤ ω (|x - y|))
    (n : ℕ) (B : ℕ → ℝ) :
    ∃ R : ℝ,
      f (B n) - f (B 0) =
        ∑ k ∈ range n, deriv f (B k) * (B (k+1) - B k) +
        1 / 2 * ∑ k ∈ range n, iteratedDeriv 2 f (B k) * (B (k+1) - B k) ^ 2 + R ∧
      |R| ≤ 1 / 2 * ω (maxAbsIncrement B n) *
        ∑ k ∈ range n, (B (k+1) - B k) ^ 2 := by
          refine' ⟨ _, eq_add_of_sub_eq' rfl, _ ⟩;
          convert Finset.abs_sum_le_sum_abs _ _ |> le_trans <| Finset.sum_le_sum fun i hi => ?_ using 1;
          any_goals try infer_instance;
          rotate_left;
          rw [ Finset.mul_sum _ _ _ ];
          use fun i => f ( B ( i + 1 ) ) - f ( B i ) - deriv f ( B i ) * ( B ( i + 1 ) - B i ) - 1 / 2 * iteratedDeriv 2 f ( B i ) * ( B ( i + 1 ) - B i ) ^ 2;
          · refine' le_trans ( taylor_single_step_bound f hf ω hω_nonneg hω_mono hω_mod _ _ ) _;
            gcongr;
            exact hω_mono ( le_maxAbsIncrement B n i ( Finset.mem_range.mp hi ) );
          · rw [ show f ( B n ) - f ( B 0 ) = ∑ k ∈ Finset.range n, ( f ( B ( k + 1 ) ) - f ( B k ) ) by rw [ Finset.sum_range_sub ( fun k => f ( B k ) ) ] ] ; norm_num [ Finset.sum_add_distrib, mul_assoc, Finset.mul_sum _ _ _ ] ; ring;

end