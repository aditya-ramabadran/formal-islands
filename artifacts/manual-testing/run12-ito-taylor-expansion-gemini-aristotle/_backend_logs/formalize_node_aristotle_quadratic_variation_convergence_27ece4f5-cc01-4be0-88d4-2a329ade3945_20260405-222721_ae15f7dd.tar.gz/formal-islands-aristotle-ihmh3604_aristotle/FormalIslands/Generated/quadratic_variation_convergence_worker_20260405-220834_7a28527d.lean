/-
# Quadratic Variation Convergence — Core Deterministic Estimates

This file formalizes the key deterministic estimates underlying the convergence
of the quadratic variation term in Itô's formula for Brownian motion.

## Main results

The informal target theorem states: for a partition 0 = t₀ < t₁ < ⋯ < tₙ = t
and a bounded continuous function f'', as the mesh → 0,
  ½ ∑ f''(B_{tₖ})(ΔBₖ)² → ½ ∫₀ᵗ f''(Bₛ) ds    in probability.

The proof decomposes this into:
1. A Riemann‐sum part: ∑ f''(B_{tₖ}) Δtₖ → ∫₀ᵗ f''(Bₛ) ds  (a.s.)
2. A martingale remainder: Mₙ = ∑ f''(B_{tₖ})((ΔBₖ)² − Δtₖ) → 0  in L²

The L² convergence of the remainder is controlled by the deterministic bound
  E[Mₙ²] ≤ 2C² ∑ (Δtₖ)²  ≤  2C² · mesh · t → 0.

We formalize:
- `partition_sum_eq_endpoint`: telescoping — ∑ Δtₖ = t
- `partition_sum_sq_le_mesh_mul_length`: ∑(Δtₖ)² ≤ mesh · t
- `quadratic_variation_split`: the algebraic decomposition of ∑ gₖ aₖ²
- `quadratic_variation_convergence_aristotle`: the main L² bound,
  stated abstractly over any probability space, showing that the weighted sum of
  centered squared increments has variance bounded by 2C² · mesh · t.
-/
import Mathlib

open Finset BigOperators

noncomputable section

namespace QuadraticVariation

/-! ## Partition definitions -/

/-- The k-th increment of a sequence of partition points. -/
def partIncrement (pts : ℕ → ℝ) (k : ℕ) : ℝ := pts (k + 1) - pts k

/-- The mesh of a partition with n subintervals (n > 0). -/
def partMesh (pts : ℕ → ℝ) (n : ℕ) : ℝ :=
  if h : 0 < n then
    Finset.sup' (Finset.range n) (by simp [Nat.pos_iff_ne_zero.mp h]) fun k => partIncrement pts k
  else 0

/-- A well-formed partition of [0, t] with n subintervals. -/
structure IsPartition (pts : ℕ → ℝ) (n : ℕ) (t : ℝ) : Prop where
  mono : Monotone pts
  start_eq : pts 0 = 0
  end_eq : pts n = t

/-! ## Key lemmas -/

/-
Telescoping: the sum of increments equals the total length.
-/
theorem partition_sum_eq_endpoint (pts : ℕ → ℝ) (n : ℕ) (t : ℝ)
    (hp : IsPartition pts n t) :
    ∑ k ∈ Finset.range n, partIncrement pts k = t := by
  cases hp;
  convert Finset.sum_range_sub ( fun i => pts i ) n using 1 ; aesop

/-
Each increment is nonneg for a monotone partition.
-/
theorem partition_increment_nonneg (pts : ℕ → ℝ) (n : ℕ) (t : ℝ)
    (hp : IsPartition pts n t) (k : ℕ) (_hk : k < n) :
    0 ≤ partIncrement pts k := by
  exact sub_nonneg_of_le <| hp.mono <| Nat.le_succ _

/-
Each increment is at most the mesh (when n > 0).
-/
theorem partition_increment_le_mesh (pts : ℕ → ℝ) (n : ℕ)
    (hn : 0 < n) (k : ℕ) (hk : k < n) :
    partIncrement pts k ≤ partMesh pts n := by
  unfold partMesh; aesop;

/-
Key estimate: sum of squared increments ≤ mesh × total length.
    This is the central bound driving E[Mₙ²] → 0.
-/
theorem partition_sum_sq_le_mesh_mul_length (pts : ℕ → ℝ) (n : ℕ) (t : ℝ)
    (hp : IsPartition pts n t) (hn : 0 < n) :
    ∑ k ∈ Finset.range n, (partIncrement pts k) ^ 2 ≤ partMesh pts n * t := by
  rw [ ←partition_sum_eq_endpoint pts n t hp ];
  rw [ Finset.mul_sum _ _ _ ];
  exact Finset.sum_le_sum fun i hi => by rw [ sq ] ; exact mul_le_mul_of_nonneg_right ( partition_increment_le_mesh pts n hn i ( Finset.mem_range.mp hi ) ) ( partition_increment_nonneg pts n t hp i ( Finset.mem_range.mp hi ) ) ;

/-
The algebraic splitting identity:
    ∑ gₖ · aₖ² = ∑ gₖ · bₖ + ∑ gₖ · (aₖ² − bₖ)

    In the application: gₖ = f''(B_{tₖ}), aₖ = ΔBₖ, bₖ = Δtₖ.
-/
theorem quadratic_variation_split (n : ℕ) (g a b : ℕ → ℝ) :
    ∑ k ∈ Finset.range n, g k * (a k) ^ 2 =
    ∑ k ∈ Finset.range n, g k * b k +
    ∑ k ∈ Finset.range n, g k * ((a k) ^ 2 - b k) := by
  simpa only [ ← Finset.sum_add_distrib ] using Finset.sum_congr rfl fun _ _ => by ring;

/-
The weighted sum of squares is bounded by C² times the sum of squared increments,
    when |gₖ| ≤ C. This gives the bound on E[Mₙ²] when combined with the conditional
    variance identity E[(ΔBₖ² - Δtₖ)² | Fₜₖ] = 2(Δtₖ)².
-/
theorem weighted_sum_sq_bound (n : ℕ) (g dt : ℕ → ℝ)
    (C : ℝ) (_hC : 0 ≤ C) (hg : ∀ k, k ∈ Finset.range n → |g k| ≤ C)
    (_hdt : ∀ k, k ∈ Finset.range n → 0 ≤ dt k) :
    ∑ k ∈ Finset.range n, (g k) ^ 2 * (2 * (dt k) ^ 2) ≤
    2 * C ^ 2 * ∑ k ∈ Finset.range n, (dt k) ^ 2 := by
  rw [ Finset.mul_sum _ _ _ ];
  exact Finset.sum_le_sum fun i hi => by nlinarith only [ show g i ^ 2 ≤ C ^ 2 by nlinarith only [ abs_le.mp ( hg i hi ) ] ] ;

/-
**Main result** (deterministic core of the quadratic variation convergence).

    Combining the partition bound with the L² estimate:
    For a partition of [0,t] with mesh δ, and |f''| ≤ C,
      E[Mₙ²] ≤ 2C² · δ · t.

    Since δ → 0 as the partition is refined, this implies Mₙ → 0 in L²
    (hence in probability), which is the key step in proving convergence of
    the quadratic variation term in Itô's formula.
-/
theorem quadratic_variation_convergence_aristotle
    (pts : ℕ → ℝ) (n : ℕ) (t : ℝ) (C : ℝ)
    (hp : IsPartition pts n t) (hn : 0 < n) (hC : 0 ≤ C)
    (g : ℕ → ℝ) (hg : ∀ k, k ∈ Finset.range n → |g k| ≤ C) :
    ∑ k ∈ Finset.range n, (g k) ^ 2 * (2 * (partIncrement pts k) ^ 2) ≤
    2 * C ^ 2 * (partMesh pts n * t) := by
  -- Apply the partition bound to get the sum ≤ 2*C^2 * ∑(partIncrement pts k)^2.
  have h_partition_bound : ∑ k ∈ Finset.range n, g k ^ 2 * (2 * partIncrement pts k ^ 2) ≤ 2 * C ^ 2 * ∑ k ∈ Finset.range n, partIncrement pts k ^ 2 := by
    simpa only [ mul_assoc, mul_left_comm, Finset.mul_sum _ _ _ ] using Finset.sum_le_sum fun k hk => mul_le_mul_of_nonneg_right ( by nlinarith only [ abs_le.mp ( hg k hk ) ] ) ( by nlinarith only [ hC ] );
  exact h_partition_bound.trans ( mul_le_mul_of_nonneg_left ( partition_sum_sq_le_mesh_mul_length pts n t hp hn ) ( by positivity ) )

end QuadraticVariation

end