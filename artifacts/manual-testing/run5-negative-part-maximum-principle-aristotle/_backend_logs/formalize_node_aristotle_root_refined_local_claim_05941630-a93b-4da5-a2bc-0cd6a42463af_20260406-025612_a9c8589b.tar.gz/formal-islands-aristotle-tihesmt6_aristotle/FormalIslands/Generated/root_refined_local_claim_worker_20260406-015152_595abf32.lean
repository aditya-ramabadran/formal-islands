import Mathlib

open MeasureTheory Set Topology

noncomputable section

variable {d : ℕ}

/-
If a C¹ function on a connected open set has zero integral of ‖∇v‖²,
then fderiv ℝ v x = 0 for all x ∈ Ω.
-/
theorem fderiv_eq_zero_of_integral_sq_norm_eq_zero
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : ContDiffOn ℝ 1 v Ω)
    (hv_intg : Integrable (fun x => ‖fderiv ℝ v x‖ ^ 2) (volume.restrict Ω))
    (hv_grad : ∫ x in Ω, ‖fderiv ℝ v x‖ ^ 2 = 0) :
    ∀ x ∈ Ω, fderiv ℝ v x = 0 := by
  -- Since ‖fderiv ℝ v x‖^2 ≥ 0 everywhere, and its integral over Ω is 0, by `integral_eq_zero_iff_of_nonneg_ae` we get ‖fderiv ℝ v x‖^2 = 0 a.e. on Ω.
  have h_zero_ae : ∀ᵐ x ∂MeasureTheory.volume.restrict Ω, (‖fderiv ℝ v x‖ : ℝ) ^ 2 = 0 := by
    rwa [ MeasureTheory.integral_eq_zero_iff_of_nonneg ( fun x => sq_nonneg _ ) hv_intg ] at hv_grad;
  rw [ MeasureTheory.ae_restrict_iff' ] at h_zero_ae;
  · contrapose! h_zero_ae;
    -- Since $fderiv ℝ v x \neq 0$, there exists an open neighborhood $U$ around $x$ where $fderiv ℝ v y \neq 0$ for all $y \in U$.
    obtain ⟨x₀, hx₀Ω, hx₀_ne⟩ : ∃ x₀ ∈ Ω, fderiv ℝ v x₀ ≠ 0 := h_zero_ae
    obtain ⟨ε, hε⟩ : ∃ ε > 0, ∀ y ∈ Metric.ball x₀ ε, fderiv ℝ v y ≠ 0 := by
      have := hv_diff.continuousOn_fderiv_of_isOpen hΩ_open le_rfl;
      exact Metric.mem_nhds_iff.mp ( this.continuousAt ( hΩ_open.mem_nhds hx₀Ω ) |> fun h => h.eventually_ne hx₀_ne );
    -- Since $Ω$ is open, the intersection $Ω ∩ Metric.ball x₀ ε$ is also open and non-empty.
    have h_inter_open : IsOpen (Ω ∩ Metric.ball x₀ ε) ∧ (Ω ∩ Metric.ball x₀ ε).Nonempty := by
      exact ⟨ hΩ_open.inter Metric.isOpen_ball, ⟨ x₀, hx₀Ω, Metric.mem_ball_self hε.1 ⟩ ⟩;
    exact ne_of_gt ( lt_of_lt_of_le ( by exact ( h_inter_open.1.measure_pos ( MeasureTheory.MeasureSpace.volume ) h_inter_open.2 ) ) ( MeasureTheory.measure_mono fun x hx => by aesop ) );
  · exact hΩ_open.measurableSet

/-
A C¹ function on a connected open set with fderiv = 0 is constant.
-/
theorem exists_const_of_fderiv_eq_zero
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (hΩ_conn : IsConnected Ω)
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : DifferentiableOn ℝ v Ω)
    (hfderiv_zero : ∀ x ∈ Ω, fderiv ℝ v x = 0) :
    ∃ c : ℝ, ∀ x ∈ Ω, v x = c := by
  have := hΩ_conn.isPreconnected;
  -- By definition of $fderiv$, we know that if $fderiv ℝ v x = 0$, then $v$ is locally constant at $x$.
  have h_locally_const : ∀ x ∈ Ω, ∃ ε > 0, ∀ y ∈ Metric.ball x ε, y ∈ Ω → v y = v x := by
    intro x hx;
    have := Metric.isOpen_iff.mp hΩ_open x hx;
    obtain ⟨ ε, ε_pos, hε ⟩ := this; use ε, ε_pos; intro y hy hy' ; exact (by
    have h_const : ∀ t ∈ Set.Icc (0 : ℝ) 1, deriv (fun t => v (x + t • (y - x))) t = 0 := by
      intro t ht; rw [ deriv ] ;
      erw [ fderiv_comp ] <;> norm_num [ hfderiv_zero, hv_diff.differentiableAt ( hΩ_open.mem_nhds <| hε <| Metric.mem_ball.mpr <| show Dist.dist ( x + t • ( y - x ) ) x < ε from by simpa [ norm_smul, abs_of_nonneg ht.1 ] using lt_of_le_of_lt ( mul_le_of_le_one_left ( norm_nonneg _ ) ht.2 ) <| Metric.mem_ball.mp hy ) ];
      rw [ hfderiv_zero _ ( hε <| by rw [ Metric.mem_ball ] ; exact by rw [ dist_eq_norm ] ; exact by simpa [ norm_smul, abs_of_nonneg ht.1 ] using lt_of_le_of_lt ( mul_le_of_le_one_left ( norm_nonneg _ ) ht.2 ) <| Metric.mem_ball.mp hy ) ] ; norm_num;
    have h_const : ∀ a b : ℝ, 0 ≤ a → a ≤ b → b ≤ 1 → ∫ t in a..b, deriv (fun t => v (x + t • (y - x))) t = v (x + b • (y - x)) - v (x + a • (y - x)) := by
      intros a b _ _ _; rw [ intervalIntegral.integral_deriv_eq_sub' ] <;> norm_num;
      · intro t ht; exact DifferentiableAt.comp t ( hv_diff.differentiableAt ( hΩ_open.mem_nhds <| hε <| by
          simp_all +decide [ dist_eq_norm ];
          exact lt_of_le_of_lt ( by rw [ norm_smul, Real.norm_of_nonneg ( by linarith ) ] ; exact mul_le_of_le_one_left ( norm_nonneg _ ) ( by linarith ) ) hy ) ) ( DifferentiableAt.add ( differentiableAt_const _ ) <| differentiableAt_id.smul_const _ ) ;
      · exact ContinuousOn.congr ( continuousOn_const ) fun t ht => h_const t <| by constructor <;> cases Set.mem_uIcc.mp ht <;> linarith;
    have := h_const 0 1; norm_num at this;
    rw [ intervalIntegral.integral_congr fun t ht => ‹∀ t ∈ Icc ( 0 : ℝ ) 1, deriv ( fun t => v ( x + t • ( y - x ) ) ) t = 0› t <| by simpa using ht ] at this; norm_num at this; linarith;);
  -- Since $v$ is locally constant on $\Omega$, the set $\{ x \in \Omega \mid v(x) = v(x_0) \}$ is open for any $x_0 \in \Omega$.
  have h_open : ∀ x₀ ∈ Ω, IsOpen {x ∈ Ω | v x = v x₀} := by
    intro x₀ hx₀; rw [ isOpen_iff_mem_nhds ] ; intro x hx; rcases h_locally_const x hx.1 with ⟨ ε, ε_pos, hε ⟩ ; filter_upwards [ Metric.ball_mem_nhds x ε_pos, IsOpen.mem_nhds hΩ_open hx.1 ] with y hy₁ hy₂; aesop;
  -- Since $v$ is locally constant on $\Omega$, the set $\{ x \in \Omega \mid v(x) \neq v(x_0) \}$ is also open for any $x_0 \in \Omega$.
  have h_open_compl : ∀ x₀ ∈ Ω, IsOpen {x ∈ Ω | v x ≠ v x₀} := by
    intro x₀ hx₀;
    exact isOpen_iff_mem_nhds.mpr fun x hx => by rcases h_locally_const x hx.1 with ⟨ ε, ε_pos, hε ⟩ ; filter_upwards [ IsOpen.mem_nhds ( hΩ_open ) hx.1, Metric.ball_mem_nhds x ε_pos ] with y hy hy' using ⟨ hy, by specialize hε y hy' hy; aesop ⟩ ;
  contrapose! this;
  simp_all +decide [ IsPreconnected ];
  obtain ⟨ x₀, hx₀₁, hx₀₂ ⟩ := this ( v ( Classical.choose ( hΩ_conn.nonempty ) ) ) ; use { x | x ∈ Ω ∧ v x = v ( Classical.choose ( hΩ_conn.nonempty ) ) }, h_open _ ( Classical.choose_spec ( hΩ_conn.nonempty ) ), { x | x ∈ Ω ∧ ¬v x = v ( Classical.choose ( hΩ_conn.nonempty ) ) }, h_open_compl _ ( Classical.choose_spec ( hΩ_conn.nonempty ) ) ; simp_all +decide [ Set.Nonempty ] ;
  exact ⟨ fun x hx => by by_cases h : v x = v ( Classical.choose ( hΩ_conn.nonempty ) ) <;> aesop, Classical.choose ( hΩ_conn.nonempty ), Classical.choose_spec ( hΩ_conn.nonempty ), rfl ⟩

/-
**Zero-gradient H¹₀ function is identically zero.**

Let Ω ⊂ ℝ^d be a bounded connected open set. If v is C¹ on Ω and continuous on
the closure, v = 0 on ∂Ω, the squared norm of the gradient is integrable on Ω,
and ∫_Ω ‖∇v‖² = 0, then v ≡ 0 on Ω.
-/
theorem root_refined_local_claim_aristotle
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (hΩ_conn : IsConnected Ω)
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : ContDiffOn ℝ 1 v Ω)
    (hv_cont : ContinuousOn v (closure Ω))
    (hv_bdry : ∀ x ∈ frontier Ω, v x = 0)
    (hv_bdry_ne : (frontier Ω).Nonempty)
    (hv_intg : Integrable (fun x => ‖fderiv ℝ v x‖ ^ 2) (volume.restrict Ω))
    (hv_grad : ∫ x in Ω, ‖fderiv ℝ v x‖ ^ 2 = 0) :
    ∀ x ∈ Ω, v x = 0 := by
  -- Step 1: fderiv = 0 on Ω
  have hfz := fderiv_eq_zero_of_integral_sq_norm_eq_zero Ω hΩ_open v hv_diff hv_intg hv_grad
  -- Step 2: v is constant on Ω
  have hv_diffOn : DifferentiableOn ℝ v Ω := hv_diff.differentiableOn (by norm_num)
  obtain ⟨c, hc⟩ := exists_const_of_fderiv_eq_zero Ω hΩ_open hΩ_conn v hv_diffOn hfz
  -- Step 3: c = 0 from boundary condition
  -- Since v is continuous on closure Ω and v = c on Ω, and v = 0 on frontier Ω,
  -- we need frontier Ω ∩ closure Ω to be nonempty and use continuity.
  -- Since $v$ is continuous on the closure of $\Omega$ and $v = 0$ on the frontier, we can use the fact that the frontier is part of the closure.
  have h_cont_closure : ∀ x ∈ frontier Ω, v x = c := by
    intro x hx; rw [ frontier_eq_closure_inter_closure ] at hx; simp_all +decide [ mem_closure_iff_seq_limit ] ;
    rcases hx with ⟨ ⟨ y, hy, hy' ⟩, hx ⟩ ; have := hv_cont.continuousWithinAt ( show x ∈ closure Ω from mem_closure_of_tendsto hy' <| by aesop ) ; simp_all +decide [ ContinuousWithinAt ] ;
    exact tendsto_nhds_unique ( this.comp <| Filter.tendsto_inf.mpr ⟨ hy', Filter.tendsto_principal.mpr <| Filter.Eventually.of_forall fun n => subset_closure <| hy n ⟩ ) <| tendsto_const_nhds.congr' <| by filter_upwards [ Filter.eventually_gt_atTop 0 ] with n hn; aesop;
  cases' hv_bdry_ne with x hx ; aesop