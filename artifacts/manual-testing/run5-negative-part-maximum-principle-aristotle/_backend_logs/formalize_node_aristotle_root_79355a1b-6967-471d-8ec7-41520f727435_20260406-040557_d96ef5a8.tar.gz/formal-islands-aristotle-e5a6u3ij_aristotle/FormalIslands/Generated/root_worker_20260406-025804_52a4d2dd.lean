import Mathlib

open MeasureTheory Set Topology Filter

noncomputable section

variable {d : ℕ}

/-- The negative part of a real-valued function: u⁻(x) = max(-u(x), 0) -/
def fnNegPart (u : EuclideanSpace ℝ (Fin d) → ℝ) : EuclideanSpace ℝ (Fin d) → ℝ :=
  fun x => max (-u x) 0

lemma fnNegPart_eq_zero_iff_nonneg (u : EuclideanSpace ℝ (Fin d) → ℝ) (x : EuclideanSpace ℝ (Fin d)) :
    fnNegPart u x = 0 ↔ u x ≥ 0 := by
  simp only [fnNegPart, max_eq_right_iff, neg_nonpos]

lemma nonneg_of_fnNegPart_eq_zero {u : EuclideanSpace ℝ (Fin d) → ℝ} {x : EuclideanSpace ℝ (Fin d)}
    (h : fnNegPart u x = 0) : u x ≥ 0 := by
  rwa [fnNegPart_eq_zero_iff_nonneg] at h

/-
Step 1: Integral of ‖fderiv ℝ v‖² = 0 implies fderiv = 0 a.e. on Ω
-/
lemma fderiv_sq_ae_zero_of_integral_zero
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_intg : Integrable (fun x => ‖fderiv ℝ v x‖ ^ 2) (volume.restrict Ω))
    (hv_grad : ∫ x in Ω, ‖fderiv ℝ v x‖ ^ 2 = 0) :
    ∀ᵐ x ∂(volume.restrict Ω), fderiv ℝ v x = 0 := by
  rw [ MeasureTheory.integral_eq_zero_iff_of_nonneg ] at hv_grad;
  · filter_upwards [ hv_grad ] with x hx using norm_eq_zero.mp ( sq_eq_zero_iff.mp hx );
  · exact fun x => sq_nonneg _;
  · exact hv_intg

/-
Step 2: Continuous function a.e. zero on open set is zero everywhere on it
-/
lemma eq_zero_on_open_of_ae_zero_continuous
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (f : EuclideanSpace ℝ (Fin d) → (EuclideanSpace ℝ (Fin d) →L[ℝ] ℝ))
    (hf_cont : ContinuousOn f Ω)
    (hf_ae : ∀ᵐ x ∂(volume.restrict Ω), f x = 0) :
    ∀ x ∈ Ω, f x = 0 := by
  intro x hx;
  by_contra h_nonzero;
  -- Since $f$ is continuous on $\Omega$ and $f(x) \neq 0$, there exists an open neighborhood $U \subseteq \Omega$ around $x$ where $f \neq 0$.
  obtain ⟨U, hU_open, hU_subset, hU_nonzero⟩ : ∃ U : Set (EuclideanSpace ℝ (Fin d)), IsOpen U ∧ x ∈ U ∧ U ⊆ Ω ∧ ∀ y ∈ U, f y ≠ 0 := by
    have := hf_cont.continuousAt ( hΩ_open.mem_nhds hx );
    obtain ⟨ U, hU₁, hU₂ ⟩ := mem_nhds_iff.mp ( this.eventually_ne h_nonzero );
    exact ⟨ U ∩ Ω, hU₂.1.inter hΩ_open, ⟨ hU₂.2, hx ⟩, Set.inter_subset_right, fun y hy => hU₁ hy.1 ⟩;
  rw [ MeasureTheory.ae_iff ] at hf_ae;
  rw [ MeasureTheory.Measure.restrict_apply' ] at hf_ae;
  · exact absurd hf_ae ( by exact ne_of_gt ( lt_of_lt_of_le ( by exact ( hU_open.measure_pos ( MeasureTheory.MeasureSpace.volume ) ⟨ x, hU_subset ⟩ ) ) ( MeasureTheory.measure_mono ( show { a | ¬f a = 0 } ∩ Ω ⊇ U from fun y hy => ⟨ hU_nonzero.2 y hy, hU_nonzero.1 hy ⟩ ) ) ) );
  · exact hΩ_open.measurableSet

/-
Step 3: C¹ function with zero fderiv on connected open set with zero boundary is zero
-/
lemma eq_zero_of_fderiv_zero_bdry_zero
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (hΩ_conn : IsConnected Ω)
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : ContDiffOn ℝ 1 v Ω)
    (hv_cont : ContinuousOn v (closure Ω))
    (hv_bdry : ∀ x ∈ frontier Ω, v x = 0)
    (hv_bdry_ne : (frontier Ω).Nonempty)
    (hv_fderiv_zero : ∀ x ∈ Ω, fderiv ℝ v x = 0) :
    ∀ x ∈ Ω, v x = 0 := by
  -- For any x, y ∈ Ω in the same connected component, we can show v(x) = v(y).
  have h_connected : ∀ x y : EuclideanSpace ℝ (Fin d), x ∈ Ω → y ∈ Ω → v x = v y := by
    -- Since $fderiv ℝ v = 0$ on $\Omega$, the function $v$ is locally constant on $\Omega$.
    have h_locally_const : ∀ x ∈ Ω, ∃ U : Set (EuclideanSpace ℝ (Fin d)), IsOpen U ∧ x ∈ U ∧ U ⊆ Ω ∧ ∀ y ∈ U, v y = v x := by
      intro x hx
      obtain ⟨ε, hε_pos, hε⟩ : ∃ ε > 0, Metric.ball x ε ⊆ Ω := by
        exact Metric.isOpen_iff.mp hΩ_open x hx;
      use Metric.ball x ε;
      have h_const : ∀ y ∈ Metric.ball x ε, v y = v x := by
        intro y hy
        have h_diff : ∀ t ∈ Set.Icc (0 : ℝ) 1, HasDerivAt (fun t => v (x + t • (y - x))) (0 : ℝ) t := by
          intro t ht
          have h_diff : HasDerivAt (fun t => v (x + t • (y - x))) (fderiv ℝ v (x + t • (y - x)) (y - x)) t := by
            have h_diff : DifferentiableAt ℝ v (x + t • (y - x)) := by
              have h_diff : DifferentiableOn ℝ v Ω := by
                fun_prop;
              refine' h_diff.differentiableAt ( hΩ_open.mem_nhds _ );
              refine' hε _;
              simp_all +decide [ dist_eq_norm ];
              exact lt_of_le_of_lt ( by rw [ norm_smul, Real.norm_of_nonneg ht.1 ] ; exact mul_le_of_le_one_left ( norm_nonneg _ ) ht.2 ) hy;
            convert HasFDerivAt.hasDerivAt ( h_diff.hasFDerivAt.comp t ( HasFDerivAt.add ( hasFDerivAt_const _ _ ) ( HasFDerivAt.smul ( hasFDerivAt_id t ) ( hasFDerivAt_const _ _ ) ) ) ) using 1 ; norm_num;
          convert h_diff using 1;
          rw [ hv_fderiv_zero _ ( hε <| by exact mem_ball_iff_norm.mpr <| by simpa [ norm_smul, abs_of_nonneg ht.1 ] using by nlinarith [ ht.1, ht.2, norm_nonneg ( y - x ), mem_ball_iff_norm.mp hy ] ) ] ; norm_num
        have h_const : ∀ a b : ℝ, 0 ≤ a → a ≤ b → b ≤ 1 → ∫ t in a..b, deriv (fun t => v (x + t • (y - x))) t = v (x + b • (y - x)) - v (x + a • (y - x)) := by
          intros a b _ _ _; rw [ intervalIntegral.integral_deriv_eq_sub' ] <;> norm_num;
          · exact fun t ht => HasDerivAt.differentiableAt ( h_diff t ⟨ by cases Set.mem_uIcc.mp ht <;> linarith, by cases Set.mem_uIcc.mp ht <;> linarith ⟩ );
          · exact ContinuousOn.congr ( show ContinuousOn ( fun _ => 0 ) _ from continuousOn_const ) fun t ht => HasDerivAt.deriv ( h_diff t <| by constructor <;> cases Set.mem_uIcc.mp ht <;> linarith );
        have := h_const 0 1; rw [ intervalIntegral.integral_congr fun t ht => HasDerivAt.deriv ( h_diff t <| by simpa using ht ) ] at this; norm_num at this; linarith;
      exact ⟨ Metric.isOpen_ball, Metric.mem_ball_self hε_pos, hε, h_const ⟩;
    -- By the properties of locally constant functions on connected sets, $v$ must be constant on $\Omega$.
    have h_const_on_connected : ∀ S : Set (EuclideanSpace ℝ (Fin d)), IsOpen S → IsConnected S → (∀ x ∈ S, ∃ U : Set (EuclideanSpace ℝ (Fin d)), IsOpen U ∧ x ∈ U ∧ U ⊆ S ∧ ∀ y ∈ U, v y = v x) → ∀ x y : EuclideanSpace ℝ (Fin d), x ∈ S → y ∈ S → v x = v y := by
      intros S hS_open hS_conn hS_locally_const x y hx hy
      have h_const_on_S : IsPreconnected S → (∀ x ∈ S, ∃ U : Set (EuclideanSpace ℝ (Fin d)), IsOpen U ∧ x ∈ U ∧ U ⊆ S ∧ ∀ y ∈ U, v y = v x) → ∀ x y : EuclideanSpace ℝ (Fin d), x ∈ S → y ∈ S → v x = v y := by
        intros hS_preconnected hS_locally_const x y hx hy
        have h_const_on_S : ∀ c : ℝ, IsOpen {z ∈ S | v z = c} ∧ IsOpen {z ∈ S | v z ≠ c} := by
          intro c
          constructor;
          · rw [ isOpen_iff_mem_nhds ];
            intro x hx; rcases hS_locally_const x hx.1 with ⟨ U, hU_open, hxU, hUS, hU ⟩ ; filter_upwards [ hU_open.mem_nhds hxU ] with y hy; aesop;
          · rw [ isOpen_iff_mem_nhds ];
            intro x hx; rcases hS_locally_const x hx.1 with ⟨ U, hU_open, hxU, hUS, hU ⟩ ; filter_upwards [ hU_open.mem_nhds hxU ] with y hy; aesop;
        generalize_proofs at *; (
        contrapose! hS_preconnected;
        simp_all +decide [ IsPreconnected ];
        use { z ∈ S | v z = v x }, h_const_on_S ( v x ) |>.1, { z ∈ S | ¬v z = v x }, h_const_on_S ( v x ) |>.2; simp_all +decide [ Set.Nonempty ] ;
        exact ⟨ fun z hz => by by_cases h : v z = v x <;> aesop, ⟨ x, hx, rfl ⟩, ⟨ y, hy, by tauto ⟩ ⟩);
      exact h_const_on_S hS_conn.isPreconnected hS_locally_const x y hx hy;
    exact h_const_on_connected Ω hΩ_open hΩ_conn h_locally_const;
  -- By continuity on closure, v(x) = v(y) for all x, y ∈ closure Ω.
  have h_closure : ∀ x ∈ closure Ω, v x = v (Classical.choose (hΩ_conn.nonempty)) := by
    intro x hx;
    -- Since $x \in \overline{\Omega}$, there exists a sequence $\{x_n\}$ in $\Omega$ such that $x_n \to x$.
    obtain ⟨xn, hxn⟩ : ∃ xn : ℕ → EuclideanSpace ℝ (Fin d), (∀ n, xn n ∈ Ω) ∧ Filter.Tendsto xn Filter.atTop (nhds x) := by
      rwa [ mem_closure_iff_seq_limit ] at hx;
    have h_lim : Filter.Tendsto (fun n => v (xn n)) Filter.atTop (nhds (v x)) := by
      have h_cont : ContinuousOn v (closure Ω) := hv_cont
      exact h_cont.continuousWithinAt hx |> fun h => h.tendsto.comp <| Filter.tendsto_inf.mpr ⟨ hxn.2, Filter.tendsto_principal.mpr <| Filter.Eventually.of_forall fun n => subset_closure <| hxn.1 n ⟩;
    exact tendsto_nhds_unique h_lim ( tendsto_const_nhds.congr fun n => h_connected _ _ ( hxn.1 n ) ( Classical.choose_spec hΩ_conn.nonempty ) ▸ rfl );
  obtain ⟨ x, hx ⟩ := hv_bdry_ne;
  exact fun y hy => by linarith [ hv_bdry x hx, h_closure x ( frontier_subset_closure hx ), h_closure y ( subset_closure hy ) ] ;

/-- Zero-gradient H¹₀ function is identically zero. -/
theorem root_refined_local_claim_aristotle
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (hΩ_conn : IsConnected Ω)
    (v : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : ContDiffOn ℝ 1 v Ω)
    (hv_cont : ContinuousOn v (closure Ω))
    (hv_bdry : ∀ x ∈ frontier Ω, v x = 0)
    (hv_bdry_ne : (frontier Ω).Nonempty)
    (hv_intg : Integrable (fun x => ‖fderiv ℝ v x‖ ^ 2) (volume.restrict Ω))
    (hv_grad : ∫ x in Ω, ‖fderiv ℝ v x‖ ^ 2 = 0) :
    ∀ x ∈ Ω, v x = 0 := by
  -- Step 1: fderiv ℝ v = 0 a.e. on Ω
  have h_ae := fderiv_sq_ae_zero_of_integral_zero Ω v hv_intg hv_grad
  -- Step 2: fderiv ℝ v = 0 everywhere on Ω (continuity of fderiv on open set + a.e. zero)
  have h_cont_fderiv : ContinuousOn (fderiv ℝ v) Ω := by
    have h := hv_diff.continuousOn_fderivWithin (hΩ_open.uniqueDiffOn) le_rfl
    exact h.congr fun x hx => (fderivWithin_of_isOpen hΩ_open hx).symm
  have h_fderiv_zero : ∀ x ∈ Ω, fderiv ℝ v x = 0 :=
    eq_zero_on_open_of_ae_zero_continuous Ω hΩ_open (fderiv ℝ v) h_cont_fderiv h_ae
  -- Step 3: v = 0 on Ω
  exact eq_zero_of_fderiv_zero_bdry_zero Ω hΩ_open hΩ_conn v hv_diff hv_cont hv_bdry hv_bdry_ne h_fderiv_zero

/-- **Weak maximum principle via the negative part.**

Let Ω ⊆ ℝᵈ be a connected open set and u a function whose negative part
u⁻ = max(−u, 0) is C¹ on Ω and continuous on its closure.
If u ≥ 0 on the boundary ∂Ω (frontier Ω), and the gradient energy of the
negative part vanishes — i.e., ∫_Ω ‖∇u⁻‖² = 0 — then u ≥ 0 throughout Ω.

The gradient energy hypothesis is the analytical consequence of −Δu ≥ 0
combined with integration by parts and the gradient identity
∫ ∇u · ∇u⁻ = −∫ |∇u⁻|². These PDE steps require Sobolev-space infrastructure
not yet available in Mathlib, so they are encoded as a hypothesis here.
The present theorem captures the logical core of the weak maximum principle:
from the vanishing gradient energy, one deduces u⁻ ≡ 0 and hence u ≥ 0. -/
theorem root_aristotle
    (Ω : Set (EuclideanSpace ℝ (Fin d)))
    (hΩ_open : IsOpen Ω)
    (hΩ_conn : IsConnected Ω)
    (u : EuclideanSpace ℝ (Fin d) → ℝ)
    (hv_diff : ContDiffOn ℝ 1 (fnNegPart u) Ω)
    (hv_cont : ContinuousOn (fnNegPart u) (closure Ω))
    (hu_bdry : ∀ x ∈ frontier Ω, u x ≥ 0)
    (hbdry_ne : (frontier Ω).Nonempty)
    (hv_intg : Integrable (fun x => ‖fderiv ℝ (fnNegPart u) x‖ ^ 2) (volume.restrict Ω))
    (hv_grad : ∫ x in Ω, ‖fderiv ℝ (fnNegPart u) x‖ ^ 2 = 0) :
    ∀ x ∈ Ω, u x ≥ 0 := by
  have hv_bdry_zero : ∀ x ∈ frontier Ω, fnNegPart u x = 0 := by
    intro x hx; rw [fnNegPart_eq_zero_iff_nonneg]; exact hu_bdry x hx
  have hv_zero := root_refined_local_claim_aristotle Ω hΩ_open hΩ_conn (fnNegPart u)
    hv_diff hv_cont hv_bdry_zero hbdry_ne hv_intg hv_grad
  intro x hx
  exact nonneg_of_fnNegPart_eq_zero (hv_zero x hx)