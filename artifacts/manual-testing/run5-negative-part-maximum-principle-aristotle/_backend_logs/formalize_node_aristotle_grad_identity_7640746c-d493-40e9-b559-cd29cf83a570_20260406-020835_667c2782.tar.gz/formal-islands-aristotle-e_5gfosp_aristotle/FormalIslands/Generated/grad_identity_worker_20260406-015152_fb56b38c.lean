import Mathlib

open MeasureTheory

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
variable {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]

/-- Pointwise identity: if `w = 0` or `w = -v`, then `⟪v, w⟫_ℝ = -‖w‖²`.
This captures the two cases in the gradient identity for the negative part:
where `u ≥ 0` (so `∇u₋ = 0`) and where `u < 0` (so `∇u₋ = -∇u`). -/
lemma inner_eq_neg_norm_sq {v w : F}
    (h : w = 0 ∨ w = -v) : ⟪v, w⟫_ℝ = -(‖w‖ ^ 2) := by
  rcases h with rfl | rfl
  · simp [inner_self_eq_zero.mpr rfl]
  · simp [inner_neg_right, real_inner_self_eq_norm_sq, norm_neg]

/-- **Gradient identity for the negative part.**

For a sufficiently regular function `u` on `Ω` with gradient `grad_u`,
the gradient `grad_u_minus` of `u₋ = max(-u, 0)` satisfies:

  `∫ ⟪∇u, ∇u₋⟫ dμ = -∫ ‖∇u₋‖² dμ.`

This is formalized by abstracting the gradient as a given function
and assuming the key chain-rule consequences as hypotheses:
- `grad_u_minus = 0` a.e. where `u ≥ 0`
- `grad_u_minus = -grad_u` a.e. where `u < 0`

The proof performs case analysis on the sign of `u` at each point:
- Where `u(x) ≥ 0`: `u₋ = 0`, so `∇u₋ = 0`, and both sides vanish.
- Where `u(x) < 0`: `u₋ = -u`, so `∇u₋ = -∇u`, giving
  `∇u · ∇u₋ = ∇u · (-∇u) = -|∇u|² = -|∇u₋|²`.
-/
theorem grad_identity_aristotle
    (u : Ω → ℝ) (grad_u grad_u_minus : Ω → F)
    (h_ae : ∀ᵐ x ∂μ, (0 ≤ u x → grad_u_minus x = 0) ∧
                       (u x < 0 → grad_u_minus x = -grad_u x)) :
    ∫ x, ⟪grad_u x, grad_u_minus x⟫_ℝ ∂μ =
    - ∫ x, ‖grad_u_minus x‖ ^ 2 ∂μ := by
  rw [← integral_neg]
  apply integral_congr_ae
  filter_upwards [h_ae] with x hx
  rcases le_or_lt 0 (u x) with h | h
  · rw [hx.1 h]; simp
  · rw [hx.2 h]; simp [inner_neg_right, real_inner_self_eq_norm_sq, norm_neg]
