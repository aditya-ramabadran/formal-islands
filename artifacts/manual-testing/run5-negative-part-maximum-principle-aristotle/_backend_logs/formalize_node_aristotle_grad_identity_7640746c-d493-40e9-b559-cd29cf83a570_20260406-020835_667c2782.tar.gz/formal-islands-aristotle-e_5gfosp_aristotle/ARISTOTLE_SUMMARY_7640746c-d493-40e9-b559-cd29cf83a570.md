# Summary of changes
Successfully formalized the **Gradient identity for the negative part** as `grad_identity_aristotle` in `FormalIslands/Generated/grad_identity_worker_20260406-015152_fb56b38c.lean`.

## What was proved

The theorem states that for a function `u` on a measure space `Ω` with values in an inner product space `F`, if `grad_u` and `grad_u_minus` are the (abstract) gradients of `u` and `u₋ = max(-u, 0)` respectively, satisfying the chain-rule consequences:
- `grad_u_minus = 0` a.e. where `u ≥ 0`
- `grad_u_minus = -grad_u` a.e. where `u < 0`

then:
```
∫ ⟪∇u, ∇u₋⟫ dμ = -∫ ‖∇u₋‖² dμ
```

## Formalization approach

Since Mathlib lacks Sobolev space infrastructure and PDE gradient theory, the gradient is abstracted as a given function with the two key chain-rule consequences assumed as hypotheses. This cleanly separates the algebraic/measure-theoretic argument (which is fully proved) from the analytic regularity theory (which Mathlib does not yet support).

The proof follows the informal argument:
1. **Pointwise identity**: A helper lemma `inner_eq_neg_norm_sq` shows that if `w = 0` or `w = -v`, then `⟪v, w⟫ = -‖w‖²`.
2. **Case split on sign of u**: At each point, either `u(x) ≥ 0` (making both sides zero) or `u(x) < 0` (where `∇u₋ = -∇u` gives the identity).
3. **Integration**: `integral_congr_ae` and `integral_neg` lift the pointwise identity to the integral equation.

The proof is fully verified with no `sorry` statements and uses only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).