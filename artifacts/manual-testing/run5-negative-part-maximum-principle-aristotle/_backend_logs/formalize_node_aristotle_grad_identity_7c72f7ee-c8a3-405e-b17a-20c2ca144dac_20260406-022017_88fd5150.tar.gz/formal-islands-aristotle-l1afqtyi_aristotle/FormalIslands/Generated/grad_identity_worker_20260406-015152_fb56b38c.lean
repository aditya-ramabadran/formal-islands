import Mathlib

open MeasureTheory

variable {d : ℕ}

/-- The negative part of a real-valued function: `u₋(x) = max(-u(x), 0)`. -/
noncomputable def negPart (u : EuclideanSpace ℝ (Fin d) → ℝ) :
    EuclideanSpace ℝ (Fin d) → ℝ :=
  fun x => max (-u x) 0

/-- **Gradient identity for the negative part** (pointwise version).

For a function `u : ℝ^d → ℝ` and a point `x`, if
- `u(x) ≥ 0` implies `∇u₋(x) = 0`, and
- `u(x) < 0` implies `∇u₋(x) = -∇u(x)`,

then `⟪∇u(x), ∇u₋(x)⟫ = -‖∇u₋(x)‖²`. -/
lemma grad_neg_part_pointwise
    (u : EuclideanSpace ℝ (Fin d) → ℝ)
    (grad_u grad_u_minus : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (x : EuclideanSpace ℝ (Fin d))
    (h_nonneg : 0 ≤ u x → grad_u_minus x = 0)
    (h_neg : u x < 0 → grad_u_minus x = -grad_u x) :
    @inner ℝ _ _ (grad_u x) (grad_u_minus x) =
    -(‖grad_u_minus x‖ ^ 2) := by
  rcases le_or_lt 0 (u x) with h | h
  · rw [h_nonneg h]; simp
  · rw [h_neg h]; simp [inner_neg_right, real_inner_self_eq_norm_sq, norm_neg]

/-- **Gradient identity for the negative part.**

For a sufficiently regular function `u` on a domain in `ℝ^d`, the negative part
`u₋ = max(-u, 0)` satisfies

  `∫_Ω ⟪∇u, ∇u₋⟫ dx = -∫_Ω ‖∇u₋‖² dx`.

The proof proceeds by pointwise case analysis on the sign of `u`:
- Where `u(x) ≥ 0`: `u₋ = 0`, so `∇u₋ = 0`, and the integrand vanishes on both sides.
- Where `u(x) < 0`: `u₋ = -u`, so `∇u₋ = -∇u`, giving
  `⟪∇u, ∇u₋⟫ = ⟪∇u, -∇u⟫ = -|∇u|² = -|∇u₋|²`.

The chain-rule consequences (`∇u₋ = 0` where `u ≥ 0` and `∇u₋ = -∇u` where `u < 0`)
are taken as hypotheses, holding a.e. with respect to Lebesgue measure. -/
theorem grad_identity_aristotle
    (u : EuclideanSpace ℝ (Fin d) → ℝ)
    (grad_u grad_u_minus : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d))
    (h_ae : ∀ᵐ x ∂(volume : Measure (EuclideanSpace ℝ (Fin d))),
      (0 ≤ u x → grad_u_minus x = 0) ∧
      (u x < 0 → grad_u_minus x = -grad_u x)) :
    ∫ x, @inner ℝ _ _ (grad_u x) (grad_u_minus x) ∂volume =
    - ∫ x, ‖grad_u_minus x‖ ^ 2 ∂volume := by
  rw [← integral_neg]
  apply integral_congr_ae
  filter_upwards [h_ae] with x ⟨h_nonneg, h_neg⟩
  exact grad_neg_part_pointwise u grad_u grad_u_minus x h_nonneg h_neg
