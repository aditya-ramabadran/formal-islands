import Mathlib

open Real Set

/-- The function p * log p + (1 - p) * log (1 - p) - 2 * p^2,
    which is the core of F_q up to affine terms in q.
    Its convexity on (0,1) is equivalent to the second-derivative bound
    1/(p(1-p)) - 4 ≥ 0. -/
noncomputable def negBinEntQuad (p : ℝ) : ℝ :=
  p * log p + (1 - p) * log (1 - p) - 2 * p ^ 2

/-- F_q(p) = p log(p/q) + (1-p) log((1-p)/(1-q)) - 2(p-q)^2 -/
noncomputable def Fq (q : ℝ) (p : ℝ) : ℝ :=
  p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

/-- AM-GM: p(1-p) ≤ 1/4 for all p. -/
lemma mul_one_sub_le_quarter (p : ℝ) : p * (1 - p) ≤ 1 / 4 := by
  nlinarith [sq_nonneg (p - 1/2)]

/-
For p ∈ (0,1), 1/(p(1-p)) ≥ 4.
-/
lemma inv_mul_one_sub_ge_four {p : ℝ} (hp0 : 0 < p) (hp1 : p < 1) :
    4 ≤ (p * (1 - p))⁻¹ := by
  rw [ inv_eq_one_div, le_div_iff₀ ] <;> nlinarith [ sq_nonneg ( p - 1 / 2 ) ]

/-
The function p * log p + (1-p) * log(1-p) - 2p^2 is convex on (0,1).
    This is the core convexity step for Pinsker's inequality via the Bernoulli case.
    The second derivative is 1/(p(1-p)) - 4 ≥ 0.
-/
lemma negBinEntQuad_convexOn : ConvexOn ℝ (Ioo 0 1) negBinEntQuad := by
  apply convexOn_of_deriv2_nonneg' (convex_Ioo 0 1);
  · exact DifferentiableOn.sub ( DifferentiableOn.add ( differentiableOn_id.mul ( Real.differentiableOn_log.mono fun x hx => ne_of_gt hx.1 ) ) ( DifferentiableOn.mul ( differentiableOn_id.const_sub _ ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ ) fun x hx => ne_of_gt ( sub_pos.mpr hx.2 ) ) ) ) ( DifferentiableOn.mul ( differentiableOn_const _ ) ( differentiableOn_id.pow 2 ) );
  · refine' DifferentiableOn.congr _ _;
    exact fun x => Real.log x - Real.log ( 1 - x ) - 4 * x;
    · exact DifferentiableOn.sub ( DifferentiableOn.sub ( DifferentiableOn.log differentiableOn_id fun x hx => ne_of_gt hx.1 ) ( DifferentiableOn.log ( differentiableOn_id.const_sub 1 ) fun x hx => ne_of_gt ( sub_pos.mpr hx.2 ) ) ) ( differentiableOn_id.const_mul _ );
    · intro x hx;
      refine' HasDerivAt.deriv _;
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' x ) ( Real.hasDerivAt_log hx.1.ne' ) ) ( HasDerivAt.mul ( hasDerivAt_id' x |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( hasDerivAt_id' x |> HasDerivAt.const_sub 1 ) ( by linarith [ hx.1, hx.2 ] : ( 1 - x ) ≠ 0 ) ) ) ) ( HasDerivAt.const_mul 2 ( hasDerivAt_pow 2 x ) ) using 1 ; ring!;
      grind;
  · -- By definition of $negBinEntQuad$, we know that its second derivative is given by
    have h_deriv2 : ∀ p ∈ Set.Ioo 0 1, deriv^[2] negBinEntQuad p = p⁻¹ + (1 - p)⁻¹ - 4 := by
      -- By definition of $negBinEntQuad$, we know that its first derivative is given by
      have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv negBinEntQuad p = Real.log p - Real.log (1 - p) - 4 * p := by
        intros p hp; erw [ deriv_sub ] <;> norm_num [ hp.1.ne', hp.2.ne', hp.1.ne, hp.2.ne, mul_comm ] ; ring;
        · erw [ deriv_add, deriv_sub ] <;> norm_num [ hp.1.ne', hp.2.ne', Real.differentiableAt_log, sub_ne_zero.mpr hp.2.ne' ] ; ring;
          · erw [ deriv_mul, deriv.log, deriv_sub ] <;> norm_num [ hp.1.ne', hp.2.ne', sub_ne_zero.mpr hp.2.ne' ] ; ring;
            · grind;
            · fun_prop (disch := norm_num);
            · exact DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hp.1, hp.2 ] );
          · exact DifferentiableAt.mul ( differentiableAt_id ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hp.1, hp.2 ] ) );
          · exact DifferentiableAt.mul ( differentiableAt_id ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hp.1, hp.2 ] ) );
          · exact DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hp.1, hp.2 ] );
        · exact DifferentiableAt.mul ( differentiableAt_id.const_sub _ ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ ) ( by linarith [ hp.1, hp.2 ] ) );
      intro p hp; refine' HasDerivAt.deriv _ ; convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hp.1 hp.2 ) fun x hx => h_deriv x hx ) using 1 ; ring;
      convert HasDerivAt.add ( Real.hasDerivAt_log hp.1.ne' ) ( HasDerivAt.sub ( HasDerivAt.neg ( hasDerivAt_mul_const _ ) ) ( HasDerivAt.log ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( by linarith [ hp.1, hp.2 ] : ( 1 - p ) ≠ 0 ) ) ) using 1 ; ring!;
    exact fun p hp => h_deriv2 p hp ▸ by nlinarith [ hp.1, hp.2, inv_pos.2 hp.1, inv_pos.2 ( sub_pos.2 hp.2 ), mul_inv_cancel₀ ( ne_of_gt hp.1 ), mul_inv_cancel₀ ( ne_of_gt ( sub_pos.2 hp.2 ) ), mul_one_sub_le_quarter p ] ;

/-
F_q equals negBinEntQuad plus affine terms on (0,1).
-/
lemma Fq_eq_negBinEntQuad_add_affine (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (p : ℝ) (hp0 : 0 < p) (hp1 : p < 1) :
    Fq q p = negBinEntQuad p + (log (1 - q) - log q + 4 * q) * p +
      (-log (1 - q) - 2 * q ^ 2) := by
  unfold Fq negBinEntQuad;
  rw [ Real.log_div, Real.log_div ] <;> linarith

/-
F_q is convex on (0,1).
-/
theorem fq_convex_aristotle (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    ConvexOn ℝ (Ioo 0 1) (Fq q) := by
  have h_convex : ConvexOn ℝ (Set.Ioo 0 1) (fun p => negBinEntQuad p + (Real.log (1 - q) - Real.log q + 4 * q) * p + (-Real.log (1 - q) - 2 * q ^ 2)) := by
    apply ConvexOn.add_const;
    apply ConvexOn.add;
    · exact negBinEntQuad_convexOn;
    · exact ⟨ convex_Ioo _ _, fun x hx y hy a b ha hb hab => by simpa using by nlinarith ⟩;
  refine' h_convex.congr _;
  exact fun p hp => Eq.symm <| Fq_eq_negBinEntQuad_add_affine q hq0 hq1 p hp.1 hp.2