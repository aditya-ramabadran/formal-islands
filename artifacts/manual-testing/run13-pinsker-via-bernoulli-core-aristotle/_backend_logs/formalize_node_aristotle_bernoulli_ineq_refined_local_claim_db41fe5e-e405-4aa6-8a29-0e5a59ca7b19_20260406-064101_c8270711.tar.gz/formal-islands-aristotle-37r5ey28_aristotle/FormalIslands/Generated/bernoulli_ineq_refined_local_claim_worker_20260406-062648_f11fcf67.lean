import Mathlib

/-!
# Convex function on (0,1) with a zero critical point is nonnegative

If G : ℝ → ℝ is convex on (0,1) and differentiable on (0,1), and there exists q ∈ (0,1)
with G(q) = 0 and G'(q) = 0, then G(p) ≥ 0 for all p ∈ (0,1).

The proof uses the first-order convexity condition:
  G(p) ≥ G(q) + G'(q)(p - q) = 0 + 0·(p - q) = 0.
-/

open Set in
theorem bernoulli_ineq_refined_local_claim_aristotle
    (G : ℝ → ℝ)
    (hconv : ConvexOn ℝ (Ioo 0 1) G)
    (hdiff : DifferentiableOn ℝ G (Ioo 0 1))
    (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1)
    (hGq : G q = 0)
    (hG'q : deriv G q = 0)
    (p : ℝ) (hp : p ∈ Ioo (0 : ℝ) 1) :
    0 ≤ G p := by
  by_cases hp_lt_q : p < q;
  · have := hconv.slope_le_deriv ( show p ∈ Set.Ioo 0 1 from hp ) ( show q ∈ Set.Ioo 0 1 from hq ) hp_lt_q;
    simp_all +decide [ slope_def_field ];
    exact le_of_not_gt fun h => absurd ( this ( hdiff.differentiableAt ( Ioo_mem_nhds hq.1 hq.2 ) ) ) ( by rw [ div_le_iff₀ ] <;> linarith );
  · by_cases hp_gt_q : p > q;
    · have := hconv.deriv_le_slope ( hq ) ( hp ) hp_gt_q ( hdiff.differentiableAt ( Ioo_mem_nhds hq.1 hq.2 ) );
      simp_all +decide [ slope_def_field ];
      rw [ le_div_iff₀ ] at this <;> linarith;
    · grind