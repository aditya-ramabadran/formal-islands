import Mathlib

open Real Set

noncomputable def Fq (q : ℝ) (p : ℝ) : ℝ :=
  p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

theorem bernoulli_ineq_refined_local_claim_aristotle
    (G : ℝ → ℝ)
    (hconv : ConvexOn ℝ (Ioo 0 1) G)
    (hdiff : DifferentiableOn ℝ G (Ioo 0 1))
    (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1)
    (hGq : G q = 0)
    (hG'q : deriv G q = 0)
    (p : ℝ) (hp : p ∈ Ioo (0 : ℝ) 1) :
    0 ≤ G p := by
      nontriviality;
      have := hconv.2 hq hp;
      -- By definition of derivative, we know that
      have h_deriv : Filter.Tendsto (fun t => (G (q + t * (p - q)) - G q) / t) (nhdsWithin 0 (Set.Ioi 0)) (nhds (deriv G q * (p - q))) := by
        have h_deriv : HasDerivAt (fun t => G (q + t * (p - q))) (deriv G q * (p - q)) 0 := by
          convert HasDerivAt.comp _ _ _ using 1;
          · simpa using hdiff.hasDerivAt ( Ioo_mem_nhds hq.1 hq.2 );
          · simpa using hasDerivAt_mul_const ( p - q );
        simpa [ div_eq_inv_mul, hGq ] using h_deriv.tendsto_slope_zero_right;
      -- Applying the definition of the derivative to the inequality $G(q + t(p - q)) \leq tG(p)$, we get
      have h_ineq : ∀ t ∈ Set.Ioo 0 1, (G (q + t * (p - q)) - G q) / t ≤ G p := by
        intro t ht; have := @this ( 1 - t ) t ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ; simp_all +decide [ div_le_iff₀, mul_comm ] ;
        convert this using 1 ; ring;
      exact le_of_tendsto h_deriv ( Filter.eventually_of_mem ( Ioo_mem_nhdsGT_of_mem ⟨ by linarith [ hq.1, hq.2 ], by linarith [ hp.1, hp.2 ] ⟩ ) h_ineq ) |> fun h => by aesop;

lemma Fq_self (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) : Fq q q = 0 := by
  unfold Fq; aesop;

lemma Fq_differentiableOn (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    DifferentiableOn ℝ (Fq q) (Ioo 0 1) := by
      refine' DifferentiableOn.sub _ _;
      · exact DifferentiableOn.add ( DifferentiableOn.mul differentiableOn_id <| DifferentiableOn.log ( differentiableOn_id.div_const q ) fun p hp => ne_of_gt <| div_pos hp.1 hq.1 ) ( DifferentiableOn.mul ( differentiableOn_id.const_sub 1 ) <| DifferentiableOn.log ( differentiableOn_id.const_sub 1 |> DifferentiableOn.div_const <| 1 - q ) fun p hp => ne_of_gt <| div_pos ( sub_pos.mpr hp.2 ) <| sub_pos.mpr hq.2 );
      · fun_prop

lemma Fq_deriv_eq_zero (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    deriv (Fq q) q = 0 := by
      -- By definition of $Fq$, we can rewrite it as $Fq q = p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2$.
      have hFq_def : ∀ p ∈ Set.Ioo (0 : ℝ) 1, (Fq q p) = p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2 := by
        exact?;
      -- By definition of $Fq$, we can rewrite it as $Fq q = p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2$ and compute the derivative term by term.
      have hFq_deriv : deriv (Fq q) q = deriv (fun p => p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2) q := by
        exact Filter.EventuallyEq.deriv_eq ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hq.1 hq.2 ) hFq_def );
      convert hFq_deriv using 1 ; ring;
      norm_num [ show q ≠ 0 by linarith [ hq.1, hq.2 ], show ( 1 - q ) ≠ 0 by linarith [ hq.1, hq.2 ], show - ( q * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ≠ 0 by nlinarith [ hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
      rw [ show - ( q * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ = 1 by nlinarith [ hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; norm_num;
      linarith [ inv_mul_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ]

lemma Fq_convexOn (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    ConvexOn ℝ (Ioo 0 1) (Fq q) := by
      -- We'll use the fact that the second derivative of $F_q$ is non-negative on $(0,1)$ to show convexity.
      have h_second_deriv_nonneg : ∀ p ∈ Set.Ioo 0 1, 0 ≤ deriv^[2] (Fq q) p := by
        -- By definition of $Fq$, we know that its second derivative is given by:
        have h_second_deriv : ∀ p ∈ (Set.Ioo 0 1), deriv^[2] (Fq q) p = 1 / (p * (1 - p)) - 4 := by
          have h_second_deriv : ∀ p ∈ Set.Ioo 0 1, deriv^[2] (Fq q) p = deriv (fun p => Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q)) p := by
            intro p hp; refine' Filter.EventuallyEq.deriv_eq _ ; filter_upwards [ Ioo_mem_nhds hp.1 hp.2 ] with x hx ; unfold Fq ; norm_num [ sub_ne_zero, hx.1.ne', hx.2.ne', hq.1.ne', hq.2.ne', mul_comm, div_eq_mul_inv ] ; ring;
            norm_num [ show x ≠ 0 by linarith [ hx.1 ], show x ≠ 1 by linarith [ hx.2 ], show q ≠ 0 by linarith [ hq.1 ], show q ≠ 1 by linarith [ hq.2 ], show - ( x * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ≠ 0 by nlinarith [ hx.1, hx.2, hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
            grind;
          intro p hp; rw [ h_second_deriv p hp ] ; norm_num [ sub_div, hp.1.ne', hp.2.ne', hq.1.ne', hq.2.ne', mul_comm ] ; ring;
          norm_num [ show p ≠ 0 by linarith [ hp.1 ], show p ≠ 1 by linarith [ hp.2 ], show q ≠ 0 by linarith [ hq.1 ], show q ≠ 1 by linarith [ hq.2 ], show ( 1 - q ) ≠ 0 by linarith [ hq.2 ], show ( - ( p * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ) ≠ 0 by nlinarith [ hp.1, hp.2, hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
          grind;
        exact fun p hp => h_second_deriv p hp ▸ sub_nonneg_of_le ( by rw [ le_div_iff₀ ] <;> nlinarith [ hp.1, hp.2, sq_nonneg ( p - 1 / 2 ) ] );
      apply_rules [ convexOn_of_deriv2_nonneg, convex_Ioo ];
      · exact ContinuousOn.sub ( ContinuousOn.add ( ContinuousOn.mul continuousOn_id <| ContinuousOn.log ( continuousOn_id.div_const q ) <| by intro p hp; aesop ) <| ContinuousOn.mul ( continuousOn_const.sub continuousOn_id ) <| ContinuousOn.log ( continuousOn_const.sub continuousOn_id |> ContinuousOn.div_const <| 1 - q ) <| by intro p hp; exact ne_of_gt <| div_pos ( by linarith [ hp.1, hp.2 ] ) <| by linarith [ hq.1, hq.2 ] ) <| ContinuousOn.mul continuousOn_const <| ContinuousOn.pow ( continuousOn_id.sub continuousOn_const ) 2;
      · exact DifferentiableOn.mono ( Fq_differentiableOn q hq ) ( interior_subset );
      · -- By definition of $Fq$, we know that its first derivative is given by:
        have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (Fq q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
          intro p hp; rw [ show Fq q = fun p => p * Real.log ( p / q ) + ( 1 - p ) * Real.log ( ( 1 - p ) / ( 1 - q ) ) - 2 * ( p - q ) ^ 2 from funext fun _ => rfl ] ; norm_num [ hp.1.ne', hp.2.ne', sub_ne_zero, hq.1.ne', hq.2.ne', mul_comm, div_eq_mul_inv ] ; ring;
          norm_num [ show p ≠ 0 by linarith [ hp.1 ], show p ≠ 1 by linarith [ hp.2 ], show q ≠ 0 by linarith [ hq.1 ], show q ≠ 1 by linarith [ hq.2 ], show - ( p * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ≠ 0 by nlinarith [ hp.1, hp.2, hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
          grind;
        norm_num +zetaDelta at *;
        exact DifferentiableOn.congr ( fun p hp => DifferentiableAt.differentiableWithinAt <| by exact DifferentiableAt.sub ( DifferentiableAt.sub ( DifferentiableAt.log ( differentiableAt_id.div_const _ ) <| ne_of_gt <| div_pos hp.1 hq.1 ) ( DifferentiableAt.log ( differentiableAt_id.const_sub _ |> DifferentiableAt.div_const <| _ ) <| ne_of_gt <| div_pos ( sub_pos.mpr hp.2 ) <| sub_pos.mpr hq.2 ) ) <| DifferentiableAt.mul ( differentiableAt_const _ ) <| differentiableAt_id.sub_const _ ) fun p hp => h_deriv p hp.1 hp.2;
      · aesop

theorem bernoulli_ineq_aristotle (p q : ℝ) (hp : p ∈ Ioo (0 : ℝ) 1) (hq : q ∈ Ioo (0 : ℝ) 1) :
    p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) ≥ 2 * (p - q) ^ 2 := by
  have h := bernoulli_ineq_refined_local_claim_aristotle (Fq q) (Fq_convexOn q hq)
    (Fq_differentiableOn q hq) q hq (Fq_self q hq) (Fq_deriv_eq_zero q hq) p hp
  unfold Fq at h
  linarith