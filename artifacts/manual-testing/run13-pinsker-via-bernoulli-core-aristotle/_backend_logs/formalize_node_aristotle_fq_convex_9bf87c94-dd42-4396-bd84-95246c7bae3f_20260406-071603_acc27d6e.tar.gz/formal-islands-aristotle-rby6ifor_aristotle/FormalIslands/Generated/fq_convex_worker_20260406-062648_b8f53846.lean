import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.NegMulLog
import Mathlib.Topology.Algebra.Order.LiminfLimsup

open Real Set

/-- The function p * log p + (1 - p) * log (1 - p) - 2 * p^2,
    which is the core of F_q up to affine terms in q.
    Its convexity on (0,1) is equivalent to the second-derivative bound
    1/(p(1-p)) - 4 ≥ 0. -/
noncomputable def negBinEntQuad (p : ℝ) : ℝ :=
  p * log p + (1 - p) * log (1 - p) - 2 * p ^ 2

/-- F_q(p) = p log(p/q) + (1-p) log((1-p)/(1-q)) - 2(p-q)^2 -/
noncomputable def Fq (q : ℝ) (p : ℝ) : ℝ :=
  p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

/-- AM-GM: p(1-p) ≤ 1/4 for all p. -/
lemma mul_one_sub_le_quarter (p : ℝ) : p * (1 - p) ≤ 1 / 4 := by
  nlinarith [sq_nonneg (p - 1/2)]

/-
The function p * log p + (1-p) * log(1-p) - 2p^2 is convex on (0,1).
    The second derivative is 1/(p(1-p)) - 4 ≥ 0.
-/
lemma negBinEntQuad_convexOn : ConvexOn ℝ (Ioo 0 1) negBinEntQuad := by
  apply_rules [ convexOn_of_deriv2_nonneg', convex_Ioo ];
  · exact DifferentiableOn.sub ( DifferentiableOn.add ( differentiableOn_id.mul ( Real.differentiableOn_log.mono fun x hx => ne_of_gt hx.1 ) ) ( DifferentiableOn.mul ( differentiableOn_id.const_sub _ ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ ) fun x hx => ne_of_gt ( sub_pos.mpr hx.2 ) ) ) ) ( DifferentiableOn.mul ( differentiableOn_const _ ) ( differentiableOn_id.pow 2 ) );
  · -- Let's calculate the first derivative of $negBinEntQuad$.
    have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv negBinEntQuad p = Real.log p - Real.log (1 - p) - 4 * p := by
      intro p hp;
      apply_rules [ HasDerivAt.deriv ];
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' p ) ( Real.hasDerivAt_log hp.1.ne' ) ) ( HasDerivAt.mul ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( sub_ne_zero_of_ne hp.2.ne' ) ) ) ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 p ) ) using 1 ; ring!;
      grind;
    exact DifferentiableOn.congr ( by exact DifferentiableOn.sub ( DifferentiableOn.sub ( DifferentiableOn.log differentiableOn_id fun x hx => ne_of_gt hx.1 ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ ) fun x hx => ne_of_gt ( sub_pos.mpr hx.2 ) ) ) ( differentiableOn_id.const_mul _ ) ) h_deriv;
  · -- Let's calculate the first derivative of negBinEntQuad.
    have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv negBinEntQuad p = Real.log p - Real.log (1 - p) - 4 * p := by
      intro p hp;
      apply_rules [ HasDerivAt.deriv ];
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' p ) ( Real.hasDerivAt_log hp.1.ne' ) ) ( HasDerivAt.mul ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( sub_ne_zero_of_ne hp.2.ne' ) ) ) ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 p ) ) using 1 ; ring!;
      grind;
    -- Let's calculate the second derivative of negBinEntQuad.
    have h_deriv2 : ∀ p ∈ Set.Ioo 0 1, deriv^[2] negBinEntQuad p = 1 / p + 1 / (1 - p) - 4 := by
      intro p hp; refine' HasDerivAt.deriv _ ; convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hp.1 hp.2 ) fun x hx => h_deriv x hx ) using 1 ; ring;
      convert HasDerivAt.add ( Real.hasDerivAt_log hp.1.ne' ) ( HasDerivAt.sub ( HasDerivAt.neg ( hasDerivAt_mul_const _ ) ) ( HasDerivAt.log ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( sub_ne_zero_of_ne hp.2.ne' ) ) ) using 1 ; ring!;
    exact fun p hp => h_deriv2 p hp ▸ by rw [ div_add_div, le_sub_iff_add_le', le_div_iff₀ ] <;> nlinarith [ hp.1, hp.2, sq_nonneg ( p - 1 / 2 ) ] ;

/-
F_q equals negBinEntQuad plus affine terms on (0,1).
-/
lemma Fq_eq_negBinEntQuad_add_affine (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (p : ℝ) (hp0 : 0 < p) (hp1 : p < 1) :
    Fq q p = negBinEntQuad p + (log (1 - q) - log q + 4 * q) * p +
      (-log (1 - q) - 2 * q ^ 2) := by
  unfold Fq negBinEntQuad;
  rw [ Real.log_div, Real.log_div ] <;> linarith

/-
F_q is convex on (0,1), since it equals the convex function negBinEntQuad
    plus an affine function in p. This is the core convexity step for
    Pinsker's inequality via the Bernoulli case.
-/
theorem fq_convex_aristotle (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    ConvexOn ℝ (Ioo 0 1) (Fq q) := by
  have h_convex : ConvexOn ℝ (Ioo 0 1) (fun p => negBinEntQuad p + (log (1 - q) - log q + 4 * q) * p + (-log (1 - q) - 2 * q ^ 2)) := by
    apply ConvexOn.add_const;
    refine' ConvexOn.add _ _;
    · exact negBinEntQuad_convexOn;
    · exact ⟨ convex_Ioo _ _, fun x hx y hy a b ha hb hab => by simpa using by nlinarith ⟩;
  exact h_convex.congr fun x hx => by rw [ Fq_eq_negBinEntQuad_add_affine q hq0 hq1 x hx.1 hx.2 ] ;
