import Mathlib

open Real Set

noncomputable def Fq (q : ℝ) (p : ℝ) : ℝ :=
  p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

theorem bernoulli_ineq_refined_local_claim_aristotle
    (G : ℝ → ℝ)
    (hconv : ConvexOn ℝ (Ioo 0 1) G)
    (hdiff : DifferentiableOn ℝ G (Ioo 0 1))
    (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1)
    (hGq : G q = 0)
    (hG'q : deriv G q = 0)
    (p : ℝ) (hp : p ∈ Ioo (0 : ℝ) 1) :
    0 ≤ G p := by
      by_contra! h_contra;
      -- By the definition of convexity, for any $p \in (0, 1)$, we have $G(p) \geq G(q) + G'(q)(p - q)$.
      have h_convex : ∀ t ∈ Set.Ioo 0 1, G (t * p + (1 - t) * q) ≤ t * G p + (1 - t) * G q := by
        exact fun t ht => hconv.2 hp hq ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] );
      -- Taking the limit as $t$ approaches $0$ from the right, we get $G'(q)(p - q) \leq G(p)$.
      have h_lim : Filter.Tendsto (fun t => (G (t * p + (1 - t) * q) - G q) / t) (nhdsWithin 0 (Set.Ioi 0)) (nhds (deriv G q * (p - q))) := by
        have h_lim : HasDerivAt (fun t => G (t * p + (1 - t) * q)) (deriv G q * (p - q)) 0 := by
          convert HasDerivAt.comp _ _ _ using 1 <;> norm_num [ hG'q ];
          · exact hG'q ▸ hasDerivAt_deriv_iff.mpr ( hdiff.differentiableAt ( Ioo_mem_nhds hq.1 hq.2 ) );
          · convert HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id ( 0 : ℝ ) ) ( hasDerivAt_const _ _ ) ) ( HasDerivAt.mul ( hasDerivAt_id ( 0 : ℝ ) |> HasDerivAt.const_sub _ ) ( hasDerivAt_const _ _ ) ) using 1 ; norm_num ; ring;
        simpa [ div_eq_inv_mul, hGq ] using h_lim.tendsto_slope_zero_right;
      have := h_lim.eventually ( lt_mem_nhds <| show deriv G q * ( p - q ) > G p by aesop );
      replace := this.and ( Ioo_mem_nhdsGT_of_mem ⟨ le_rfl, zero_lt_one ⟩ ) ; obtain ⟨ t, ht₁, ht₂ ⟩ := this.exists; rw [ lt_div_iff₀ ] at ht₁ <;> nlinarith [ h_convex t ht₂ ] ;

lemma Fq_self (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) : Fq q q = 0 := by
  unfold Fq; aesop;

lemma Fq_differentiableOn (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    DifferentiableOn ℝ (Fq q) (Ioo 0 1) := by
      refine' DifferentiableOn.add _ _;
      · exact DifferentiableOn.add ( DifferentiableOn.mul differentiableOn_id ( DifferentiableOn.log ( differentiableOn_id.div_const _ ) fun p hp => ne_of_gt ( div_pos hp.1 hq.1 ) ) ) ( DifferentiableOn.mul ( differentiableOn_id.const_sub _ ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ |> DifferentiableOn.div_const <| _ ) fun p hp => ne_of_gt ( div_pos ( sub_pos.mpr hp.2 ) ( sub_pos.mpr hq.2 ) ) ) );
      · fun_prop

lemma Fq_deriv_eq_zero (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    deriv (Fq q) q = 0 := by
      convert HasDerivAt.deriv ( _ ) using 1;
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id q ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id q ) q ) ?_ ) ) ( HasDerivAt.mul ( HasDerivAt.const_sub 1 ( hasDerivAt_id q ) ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id q |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) ?_ ) ) ) ( HasDerivAt.mul ( HasDerivAt.const_mul 2 ( hasDerivAt_id q |> HasDerivAt.sub <| hasDerivAt_const q q ) ) ( hasDerivAt_id q |> HasDerivAt.sub <| hasDerivAt_const q q ) ) using 1 <;> norm_num [ hq.1.ne', hq.2.ne' ];
      · ext; unfold Fq; norm_num; ring;
      · grind;
      · linarith [ hq.1, hq.2 ]

lemma Fq_convexOn (q : ℝ) (hq : q ∈ Ioo (0 : ℝ) 1) :
    ConvexOn ℝ (Ioo 0 1) (Fq q) := by
      -- Prove that the second derivative of Fq q is nonnegative on Ioo 0 1.
      have h_second_deriv_nonneg : ∀ p ∈ Set.Ioo 0 1, 0 ≤ (deriv^[2] (Fq q)) p := by
        -- By definition of $Fq$, we know that its second derivative is given by:
        have h_second_deriv : ∀ p ∈ (Set.Ioo 0 1), deriv^[2] (Fq q) p = 1 / p + 1 / (1 - p) - 4 := by
          -- By definition of $Fq$, we know that its first derivative is given by:
          have h_first_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (Fq q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
            intro p hp; unfold Fq; norm_num [ hp.1.ne', hp.2.ne, hq.1.ne', hq.2.ne', Real.differentiableAt_log, mul_comm, sub_ne_zero.mpr ( ne_of_gt hp.2 ) ] ; ring;
            norm_num [ show p ≠ 0 by linarith [ hp.1 ], show q ≠ 0 by linarith [ hq.1 ], show ( 1 - q ) ≠ 0 by linarith [ hq.2 ], show ( - ( p * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ) ≠ 0 by nlinarith [ hp.1, hp.2, hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
            grind;
          intro p hp; refine' HasDerivAt.deriv _;
          convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hp.1 hp.2 ) h_first_deriv ) using 1;
          convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p ) q ) <| ne_of_gt <| div_pos hp.1 hq.1 ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) <| ne_of_gt <| div_pos ( sub_pos.mpr hp.2 ) <| sub_pos.mpr hq.2 ) ) ( HasDerivAt.const_mul 4 <| HasDerivAt.sub ( hasDerivAt_id' p ) <| hasDerivAt_const _ _ ) using 1 ; ring;
          grind +qlia;
        exact fun p hp => h_second_deriv p hp ▸ by rw [ div_add_div, le_sub_iff_add_le', le_div_iff₀ ] <;> nlinarith [ sq_nonneg ( p - 1 / 2 ), hp.1, hp.2 ] ;
      apply_rules [ convexOn_of_deriv2_nonneg', convex_Ioo ];
      · exact?;
      · refine' DifferentiableOn.congr _ _;
        use fun p => Real.log ( p / q ) - Real.log ( ( 1 - p ) / ( 1 - q ) ) - 4 * ( p - q );
        · exact DifferentiableOn.sub ( DifferentiableOn.sub ( DifferentiableOn.log ( differentiableOn_id.div_const _ ) fun x hx => ne_of_gt <| div_pos hx.1 hq.1 ) ( DifferentiableOn.log ( DifferentiableOn.div_const ( differentiableOn_id.const_sub _ ) _ ) fun x hx => ne_of_gt <| div_pos ( sub_pos.mpr hx.2 ) ( sub_pos.mpr hq.2 ) ) ) ( DifferentiableOn.mul ( differentiableOn_const _ ) ( differentiableOn_id.sub_const _ ) );
        · intro p hp; unfold Fq; norm_num [ hp.1.ne', hp.2.ne', hq.1.ne', hq.2.ne', Real.differentiableAt_log, mul_comm, sub_ne_zero.mpr ( ne_of_gt hp.2 ), sub_ne_zero.mpr ( ne_of_gt hq.2 ) ] ; ring;
          norm_num [ show p ≠ 0 by linarith [ hp.1 ], show q ≠ 0 by linarith [ hq.1 ], show 1 - q ≠ 0 by linarith [ hq.2 ], show - ( p * ( 1 - q ) ⁻¹ ) + ( 1 - q ) ⁻¹ ≠ 0 by nlinarith [ hp.1, hp.2, hq.1, hq.2, mul_inv_cancel₀ ( by linarith [ hq.1, hq.2 ] : ( 1 - q ) ≠ 0 ) ] ] ; ring;
          grind

theorem bernoulli_ineq_aristotle (p q : ℝ) (hp : p ∈ Ioo (0 : ℝ) 1) (hq : q ∈ Ioo (0 : ℝ) 1) :
    p * Real.log (p / q) + (1 - p) * Real.log ((1 - p) / (1 - q)) ≥ 2 * (p - q) ^ 2 := by
  have h := bernoulli_ineq_refined_local_claim_aristotle (Fq q) (Fq_convexOn q hq)
    (Fq_differentiableOn q hq) q hq (Fq_self q hq) (Fq_deriv_eq_zero q hq) p hp
  unfold Fq at h
  linarith