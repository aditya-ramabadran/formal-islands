import Mathlib

/-!
# Attainment of the Rayleigh-quotient infimum

This file formalizes the attainment of the Rayleigh-quotient infimum in
`EuclideanSpace ℝ (Fin d)`, the concrete finite-dimensional analogue of
the Sobolev-space result for `H₀¹(Ω) ⊂ L²(Ω)` on a bounded domain
`Ω ⊂ ℝ^d`.

## Main result

Given a continuous linear operator `T` on `EuclideanSpace ℝ (Fin d)`
(representing the action of `−Δ` via its bilinear form), the Rayleigh-quotient
infimum
  `λ₁ = inf { ⟪T x, x⟫_ℝ : x ∈ EuclideanSpace ℝ (Fin d), ‖x‖ = 1 }`
is attained: there exists `u₁` with `‖u₁‖ = 1` and `⟪T u₁, u₁⟫_ℝ = λ₁`.

The proof uses:
- compactness of the unit sphere in finite dimensions (analogue of
  Rellich–Kondrachov compact embedding `H₀¹(Ω) ↪ L²(Ω)`),
- continuity of the Rayleigh quotient,
- the extreme-value theorem (analogue of weak lower semicontinuity of the
  `H¹`-seminorm combined with strong `L²`-convergence).
-/

open scoped InnerProductSpace

/-- The Rayleigh-quotient infimum on `EuclideanSpace ℝ (Fin d)`:
`λ₁ = inf { ⟪T x, x⟫_ℝ : ‖x‖ = 1 }`.

In the PDE setting this corresponds to
`λ₁ = inf { ∫_Ω |∇u|² dx : u ∈ H₀¹(Ω), ∫_Ω u² dx = 1 }`. -/
noncomputable def rayleighInfEucl (d : ℕ)
    (T : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin d)) : ℝ :=
  sInf ((fun x => ⟪T x, x⟫_ℝ) '' Metric.sphere (0 : EuclideanSpace ℝ (Fin d)) 1)

/-- **Attainment of the Rayleigh-quotient infimum.**

On `EuclideanSpace ℝ (Fin d)` with `d ≥ 1`, the infimum of the Rayleigh
quotient `⟪T x, x⟫_ℝ` over unit vectors is attained: there exists `u₁` with
`‖u₁‖ = 1` and `⟪T u₁, u₁⟫_ℝ = rayleighInfEucl d T`.

This is the finite-dimensional analogue of: there exists `u₁ ∈ H₀¹(Ω)` with
`∫_Ω u₁² dx = 1` and `∫_Ω |∇u₁|² dx = λ₁`. -/
theorem attainment_aristotle (d : ℕ) [NeZero d]
    (T : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin d)) :
    ∃ u₁ : EuclideanSpace ℝ (Fin d),
      ‖u₁‖ = 1 ∧ ⟪T u₁, u₁⟫_ℝ = rayleighInfEucl d T := by
  -- The image of the unit sphere under the Rayleigh map is compact (compact set, continuous map).
  have h_image_compact : IsCompact ((fun x => ⟪T x, x⟫_ℝ) '' Metric.sphere (0 : EuclideanSpace ℝ (Fin d)) 1) :=
    IsCompact.image (isCompact_sphere _ _) (by fun_prop)
  -- The image is nonempty (the sphere is nonempty since d ≥ 1), so the infimum is attained.
  obtain ⟨u₁, hu₁⟩ := h_image_compact.sInf_mem (by simp)
  aesop
