import Mathlib

/-!
# Identification of the Lagrange multiplier as λ₁

In the setting of the Rayleigh quotient for the first Dirichlet eigenvalue on a bounded
domain Ω ⊂ ℝᵈ, the key algebraic step is: if u₁ ∈ H₀¹(Ω) satisfies

  ∫_Ω u₁² dx = 1,   ∫_Ω |∇u₁|² dx = λ₁,

and there exists μ ∈ ℝ such that

  ∫_Ω ∇u₁ · ∇φ dx = μ ∫_Ω u₁ φ dx   for all φ ∈ H₀¹(Ω),

then μ = λ₁.

**Proof.** Substitute φ = u₁ in the weak equation to obtain
  ∫_Ω |∇u₁|² dx = μ ∫_Ω u₁² dx.
The left-hand side equals λ₁ by hypothesis, and the right-hand side equals μ · 1 = μ
because ∫_Ω u₁² dx = 1. Hence μ = λ₁.

We formalize this in an abstract bilinear-form setting over a real vector space V
(standing in for H₀¹(Ω)), with two ℝ-bilinear forms:
  • `a : V →ₗ[ℝ] V →ₗ[ℝ] ℝ`  (the Dirichlet/stiffness form, (u, v) ↦ ∫ ∇u · ∇v)
  • `b : V →ₗ[ℝ] V →ₗ[ℝ] ℝ`  (the mass/L² form, (u, v) ↦ ∫ u v)

This captures the full inferential content of the node: the conclusion is a purely
algebraic consequence of substituting φ = u₁ and using two scalar equalities.
-/

/-- **Identification of the Lagrange multiplier as λ₁.**

Let `V` be a real vector space equipped with two bilinear forms `a` (Dirichlet form)
and `b` (mass form). If `u₁ ∈ V` satisfies `b u₁ u₁ = 1` (L²-normalization),
`a u₁ u₁ = eigenval₁` (energy equals the Rayleigh infimum), and the weak eigenvalue
equation `a u₁ φ = μ · b u₁ φ` for all `φ ∈ V`, then `μ = eigenval₁`. -/
theorem weak_eq_refined_local_claim_aristotle
    {V : Type*} [AddCommGroup V] [Module ℝ V]
    (a b : V →ₗ[ℝ] V →ₗ[ℝ] ℝ)
    (u₁ : V) (eigenval₁ μ : ℝ)
    (h_norm : b u₁ u₁ = 1)
    (h_energy : a u₁ u₁ = eigenval₁)
    (h_weak : ∀ φ : V, a u₁ φ = μ * b u₁ φ) :
    μ = eigenval₁ := by
  have h := h_weak u₁
  rw [h_energy, h_norm, mul_one] at h
  linarith
