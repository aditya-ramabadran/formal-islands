import Mathlib

/-!
# Identification of the Lagrange multiplier as λ₁

In the setting of the Rayleigh quotient for the first Dirichlet eigenvalue on a bounded
domain Ω ⊂ ℝᵈ, the key algebraic step is: if u₁ ∈ H₀¹(Ω) satisfies

  ∫_Ω u₁² dx = 1,   ∫_Ω |∇u₁|² dx = λ₁,

and there exists μ ∈ ℝ such that

  ∫_Ω ∇u₁ · ∇φ dx = μ ∫_Ω u₁ φ dx   for all φ ∈ H₀¹(Ω),

then μ = λ₁.

**Proof.** Substitute φ = u₁ in the weak equation to obtain
  ∫_Ω |∇u₁|² dx = μ ∫_Ω u₁² dx.
The left-hand side equals λ₁ by hypothesis, and the right-hand side equals μ · 1 = μ
because ∫_Ω u₁² dx = 1. Hence μ = λ₁.

We formalize this in the concrete setting of functions on Ω ⊂ ℝᵈ
(modeled as `EuclideanSpace ℝ (Fin d)`). The L² mass form is represented
by actual measure-theoretic integrals `∫ x in Ω, u₁ x * φ x ∂ν`. The
Dirichlet/stiffness form `(u, v) ↦ ∫_Ω ∇u · ∇v dx` is abstracted as a function
`dirichlet_form`, since Sobolev spaces H₀¹(Ω) are not available in Mathlib.
-/

open MeasureTheory

/-- **Identification of the Lagrange multiplier as λ₁.**

On a bounded domain `Ω ⊂ ℝᵈ` with measure `ν`, let `u₁ : ℝᵈ → ℝ` be a function
satisfying `∫_Ω u₁² dν = 1` (L²-normalization) and whose Dirichlet energy equals `λ₁`.
If the weak eigenvalue equation `dirichlet_form u₁ φ = μ · ∫_Ω u₁ φ dν` holds for
all test functions `φ`, then `μ = λ₁`.

The proof substitutes `φ = u₁` in the weak equation, then uses the normalization
and energy hypotheses to conclude `λ₁ = μ · 1 = μ`. -/
theorem weak_eq_refined_local_claim_aristotle
    {d : ℕ}
    {Ω : Set (EuclideanSpace ℝ (Fin d))}
    {ν : Measure (EuclideanSpace ℝ (Fin d))}
    (u₁ : EuclideanSpace ℝ (Fin d) → ℝ)
    (dirichlet_form : (EuclideanSpace ℝ (Fin d) → ℝ) →
                       (EuclideanSpace ℝ (Fin d) → ℝ) → ℝ)
    (λ₁ μ : ℝ)
    (h_norm : ∫ x in Ω, u₁ x * u₁ x ∂ν = 1)
    (h_energy : dirichlet_form u₁ u₁ = λ₁)
    (h_weak : ∀ φ : EuclideanSpace ℝ (Fin d) → ℝ,
      dirichlet_form u₁ φ = μ * ∫ x in Ω, u₁ x * φ x ∂ν) :
    μ = λ₁ := by
  have h := h_weak u₁
  rw [h_energy, h_norm, mul_one] at h
  linarith
