import Mathlib

/-!
# Attainment of the Rayleigh-quotient infimum

This file formalizes the attainment of the Rayleigh-quotient infimum in the
finite-dimensional setting.

## Main result

Given a continuous linear operator `T` on a nontrivial finite-dimensional real
inner product space `E`, the infimum of the Rayleigh quotient `⟪T x, x⟫_ℝ`
over the unit sphere `{x : ‖x‖ = 1}` is attained: there exists `u₁` with
`‖u₁‖ = 1` whose Rayleigh quotient equals the infimum.

In the PDE setting of the first Dirichlet eigenvalue, `E` plays the role of
`H₀¹(Ω)`, `T` plays the role of `−Δ`, `⟪T x, x⟫_ℝ` represents `∫_Ω |∇x|²`,
and `‖x‖² = 1` represents `∫_Ω x² = 1`.

The proof uses:
- compactness of the unit sphere in finite dimensions,
- continuity of the Rayleigh quotient,
- the extreme-value theorem (`IsCompact.exists_isMinOn`).

These correspond to the Rellich–Kondrachov compact embedding + weak lower
semicontinuity argument used in the infinite-dimensional case.
-/

open scoped InnerProductSpace

/-- The Rayleigh-quotient infimum: `λ₁ = inf { ⟪T x, x⟫_ℝ : ‖x‖ = 1 }`. -/
noncomputable def rayleighInf
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (T : E →L[ℝ] E) : ℝ :=
  sInf ((fun x => ⟪T x, x⟫_ℝ) '' Metric.sphere (0 : E) 1)

/-- **Attainment of the Rayleigh-quotient infimum.**

In a nontrivial finite-dimensional real inner product space,
the infimum of the Rayleigh quotient `⟪T x, x⟫_ℝ` over unit vectors
is attained: there exists `u₁` with `‖u₁‖ = 1` and
`⟪T u₁, u₁⟫_ℝ = rayleighInf T`.

This is the finite-dimensional analogue of the theorem that the first
Dirichlet eigenvalue `λ₁ = inf { ∫_Ω |∇u|² : u ∈ H₀¹(Ω), ∫_Ω u² = 1 }`
is attained. -/
theorem attainment_aristotle
    {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] [Nontrivial E]
    (T : E →L[ℝ] E) :
    ∃ u₁ : E, ‖u₁‖ = 1 ∧ ⟪T u₁, u₁⟫_ℝ = rayleighInf T := by
  have h_compact : IsCompact (Metric.sphere (0 : E) 1) := isCompact_sphere _ _
  have := h_compact.image (show Continuous fun x : E => ⟪T x, x⟫_ℝ from by fun_prop)
  obtain ⟨u₁, hu₁⟩ := this.sInf_mem (Set.Nonempty.image _ <| by simp)
  aesop
