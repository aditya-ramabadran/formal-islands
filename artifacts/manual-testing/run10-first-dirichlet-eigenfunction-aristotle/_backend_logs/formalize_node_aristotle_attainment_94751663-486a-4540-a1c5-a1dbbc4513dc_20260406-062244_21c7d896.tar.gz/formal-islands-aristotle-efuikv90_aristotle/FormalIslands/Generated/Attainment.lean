import Mathlib

/-!
# Attainment of the Rayleigh-quotient infimum

This file formalizes the attainment of the Rayleigh-quotient infimum in
`EuclideanSpace ℝ (Fin d)`, the concrete finite-dimensional analogue of
the Sobolev-space result for `H₀¹(Ω) ⊂ L²(Ω)` on a bounded domain
`Ω ⊂ ℝ^d`.

## Main results

Given a continuous linear operator `T` on `EuclideanSpace ℝ (Fin d)`
(representing the action of `−Δ` via its bilinear form), the Rayleigh-quotient
infimum
  `λ₁ = inf { ⟪T x, x⟫_ℝ : x ∈ EuclideanSpace ℝ (Fin d), ‖x‖ = 1 }`
is attained: there exists `u₁` with `‖u₁‖ = 1` and `⟪T u₁, u₁⟫_ℝ = λ₁`.

The proof uses:
- compactness of the unit sphere in finite dimensions (analogue of
  Rellich–Kondrachov compact embedding `H₀¹(Ω) ↪ L²(Ω)`),
- continuity of the Rayleigh quotient,
- the extreme-value theorem (analogue of weak lower semicontinuity of the
  `H¹`-seminorm combined with strong `L²`-convergence).

We also prove that:
- Any minimizing sequence for the Rayleigh quotient is bounded in norm.
- When `T` is self-adjoint, the minimizer `u₁` satisfies the weak eigenvalue
  equation `⟪T u₁, φ⟫_ℝ = λ₁ · ⟪u₁, φ⟫_ℝ` for all `φ`.
-/

open scoped InnerProductSpace

/-- The Rayleigh-quotient infimum on `EuclideanSpace ℝ (Fin d)`:
`λ₁ = inf { ⟪T x, x⟫_ℝ : ‖x‖ = 1 }`.

In the PDE setting this corresponds to
`λ₁ = inf { ∫_Ω |∇u|² dx : u ∈ H₀¹(Ω), ∫_Ω u² dx = 1 }`. -/
noncomputable def rayleighInfEucl (d : ℕ)
    (T : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin d)) : ℝ :=
  sInf ((fun x => ⟪T x, x⟫_ℝ) '' Metric.sphere (0 : EuclideanSpace ℝ (Fin d)) 1)

/-- **Boundedness of a minimizing sequence.**

Any sequence on the unit sphere of `EuclideanSpace ℝ (Fin d)` is bounded
in norm (all elements have norm 1). In the PDE setting this corresponds to
the observation that a minimizing sequence `(uₙ) ⊂ H₀¹(Ω)` with
`∫ uₙ² = 1` has `‖uₙ‖_{H₀¹}² = ∫ |∇uₙ|² → λ₁`, hence is bounded. -/
theorem minimizing_seq_bounded (d : ℕ)
    (u : ℕ → EuclideanSpace ℝ (Fin d))
    (hu : ∀ n, ‖u n‖ = 1) :
    ∃ C : ℝ, ∀ n, ‖u n‖ ≤ C :=
  ⟨1, fun n => le_of_eq (hu n)⟩

/-- **Attainment of the Rayleigh-quotient infimum.**

On `EuclideanSpace ℝ (Fin d)` with `d ≥ 1`, the infimum of the Rayleigh
quotient `⟪T x, x⟫_ℝ` over unit vectors is attained: there exists `u₁` with
`‖u₁‖ = 1` and `⟪T u₁, u₁⟫_ℝ = rayleighInfEucl d T`.

This is the finite-dimensional analogue of: there exists `u₁ ∈ H₀¹(Ω)` with
`∫_Ω u₁² dx = 1` and `∫_Ω |∇u₁|² dx = λ₁`. -/
theorem attainment_aristotle (d : ℕ) [NeZero d]
    (T : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin d)) :
    ∃ u₁ : EuclideanSpace ℝ (Fin d),
      ‖u₁‖ = 1 ∧ ⟪T u₁, u₁⟫_ℝ = rayleighInfEucl d T := by
  -- The image of the unit sphere under the Rayleigh map is compact (compact set, continuous map).
  have h_image_compact : IsCompact ((fun x => ⟪T x, x⟫_ℝ) '' Metric.sphere (0 : EuclideanSpace ℝ (Fin d)) 1) :=
    IsCompact.image (isCompact_sphere _ _) (by fun_prop)
  -- The image is nonempty (the sphere is nonempty since d ≥ 1), so the infimum is attained.
  obtain ⟨u₁, hu₁⟩ := h_image_compact.sInf_mem (by simp)
  aesop

/-- **Weak eigenvalue equation for the Rayleigh-quotient minimizer.**

If `T` is self-adjoint and `u₁` is a minimizer of the Rayleigh quotient on the
unit sphere, then `u₁` satisfies the weak eigenvalue equation:
  `⟪T u₁, φ⟫_ℝ = λ₁ · ⟪u₁, φ⟫_ℝ`  for all `φ`.

In the PDE setting this corresponds to:
  `∫_Ω ∇u₁ · ∇φ dx = λ₁ ∫_Ω u₁ φ dx`  for all `φ ∈ H₀¹(Ω)`.
-/
theorem weak_eigenvalue_equation (d : ℕ) [NeZero d]
    (T : EuclideanSpace ℝ (Fin d) →L[ℝ] EuclideanSpace ℝ (Fin d))
    (hT : ∀ x y : EuclideanSpace ℝ (Fin d), ⟪T x, y⟫_ℝ = ⟪x, T y⟫_ℝ)
    (u₁ : EuclideanSpace ℝ (Fin d))
    (hu₁_norm : ‖u₁‖ = 1)
    (hu₁_min : ⟪T u₁, u₁⟫_ℝ = rayleighInfEucl d T) :
    ∀ φ : EuclideanSpace ℝ (Fin d),
      ⟪T u₁, φ⟫_ℝ = rayleighInfEucl d T * ⟪u₁, φ⟫_ℝ := by
  intro φ;
  -- For any $\phi$, consider $f(t) = \frac{\langle T(u_1 + t\phi), u_1 + t\phi \rangle}{\|u_1 + t\phi\|^2}$.
  have h_ft : ∀ t : ℝ, ⟪T (u₁ + t • φ), u₁ + t • φ⟫_ℝ ≥ rayleighInfEucl d T * ‖u₁ + t • φ‖^2 := by
    intro t
    by_cases h : u₁ + t • φ = 0;
    · aesop;
    · have h_ft : ∀ x : EuclideanSpace ℝ (Fin d), ‖x‖ = 1 → ⟪T x, x⟫_ℝ ≥ rayleighInfEucl d T := by
        intros x hx_norm
        apply csInf_le;
        · exact IsCompact.bddBelow ( isCompact_sphere 0 1 |> IsCompact.image <| Continuous.inner ( T.continuous ) continuous_id' );
        · aesop;
      have := h_ft ( ‖u₁ + t • φ‖⁻¹ • ( u₁ + t • φ ) ) ?_ <;> simp_all +decide [ norm_smul, inner_smul_left, inner_smul_right ];
      · convert mul_le_mul_of_nonneg_right this ( sq_nonneg ‖u₁ + t • φ‖ ) using 1 ; norm_num [ inner_add_left, inner_add_right, inner_smul_left, inner_smul_right ] ; ring;
        norm_num [ h ];
      · rw [ ← smul_add, norm_smul, Real.norm_of_nonneg ( inv_nonneg.mpr ( norm_nonneg _ ) ), inv_mul_cancel₀ ( norm_ne_zero_iff.mpr h ) ];
  -- Let's choose any $t \in \mathbb{R}$ and expand the expression for $f(t)$.
  have h_expand : ∀ t : ℝ, ⟪T (u₁ + t • φ), u₁ + t • φ⟫_ℝ = ⟪T u₁, u₁⟫_ℝ + 2 * t * ⟪T u₁, φ⟫_ℝ + t^2 * ⟪T φ, φ⟫_ℝ := by
    intro t; simp +decide [ *, inner_add_left, inner_add_right, inner_smul_left, inner_smul_right ] ; ring;
    simp +decide [ ← hT, mul_two, add_assoc ];
    exact Or.inl ( by rw [ hT, real_inner_comm ] );
  -- By definition of $f(t)$, we know that $f(t) \geq \lambda_1$ for all $t$.
  have h_ft_ge : ∀ t : ℝ, ⟪T u₁, u₁⟫_ℝ + 2 * t * ⟪T u₁, φ⟫_ℝ + t^2 * ⟪T φ, φ⟫_ℝ ≥ rayleighInfEucl d T * (1 + 2 * t * ⟪u₁, φ⟫_ℝ + t^2 * ‖φ‖^2) := by
    intro t; specialize h_ft t; rw [ ← h_expand t ] at *; simp_all +decide [ norm_add_sq_real, norm_smul ] ;
    convert h_ft using 2 ; norm_num [ mul_pow, inner_smul_right ] ; ring;
  -- By definition of $f(t)$, we know that $f(t) \geq \lambda_1$ for all $t$, and equality holds when $t = 0$.
  have h_ft_eq : deriv (fun t : ℝ => ⟪T u₁, u₁⟫_ℝ + 2 * t * ⟪T u₁, φ⟫_ℝ + t^2 * ⟪T φ, φ⟫_ℝ - rayleighInfEucl d T * (1 + 2 * t * ⟪u₁, φ⟫_ℝ + t^2 * ‖φ‖^2)) 0 = 0 := by
    exact IsLocalMin.deriv_eq_zero <| Filter.Eventually.of_forall fun t => by simpa [ hu₁_min ] using h_ft_ge t;
  norm_num [ mul_assoc, mul_comm, mul_left_comm ] at * ; linarith