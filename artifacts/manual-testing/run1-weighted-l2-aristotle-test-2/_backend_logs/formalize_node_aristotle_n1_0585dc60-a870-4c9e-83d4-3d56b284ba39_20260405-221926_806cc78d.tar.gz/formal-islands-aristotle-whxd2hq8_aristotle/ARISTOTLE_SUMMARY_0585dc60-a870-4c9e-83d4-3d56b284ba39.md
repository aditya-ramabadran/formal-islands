# Summary of changes
Successfully formalized the **Weighted L² inequality** (Heisenberg uncertainty principle) in Lean 4.

### What was proved

The file `FormalIslands/Generated/n1_worker_20260405-213954_c0a757b9.lean` contains:

1. **`integral_mul_le_sqrt_mul_sqrt`** — A helper lemma establishing the Cauchy–Schwarz inequality for integrals of nonneg functions: `∫ g·h ≤ √(∫ g²) · √(∫ h²)`. This is proved from first principles using the classical discriminant argument (expanding `∫ (g - t·h)² ≥ 0`).

2. **`n1_aristotle`** — The main theorem, the d = 1 specialisation of the weighted L² inequality:
   ```
   ∫ ‖f(x)‖² dx  ≤  2 · √(∫ x² ‖f(x)‖² dx) · √(∫ ‖f'(x)‖² dx)
   ```
   This is the d = 1 case of `‖f‖² ≤ (2/d) ‖xf‖₂ ‖∇f‖₂`.

### Formalization design

- **Setting**: `f, f' : ℝ → ℂ` with appropriate integrability hypotheses.
- **IBP identity as hypothesis**: The integration-by-parts identity `∫ |f|² = −2 Re ∫ x f'(x) conj(f(x)) dx` (which requires regularity and decay at infinity) is taken as a hypothesis `hIBP`, cleanly separating the analytic/PDE content from the inequality chain.
- **Proof**: From the IBP identity, the theorem follows by chaining three standard inequalities: `|Re z| ≤ ‖z‖` (`Complex.abs_re_le_norm`), the triangle inequality for integrals (`norm_integral_le_integral_norm`), and Cauchy–Schwarz (`integral_mul_le_sqrt_mul_sqrt`).
- **No sorries**: The file compiles clean with no `sorry` statements and uses only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).