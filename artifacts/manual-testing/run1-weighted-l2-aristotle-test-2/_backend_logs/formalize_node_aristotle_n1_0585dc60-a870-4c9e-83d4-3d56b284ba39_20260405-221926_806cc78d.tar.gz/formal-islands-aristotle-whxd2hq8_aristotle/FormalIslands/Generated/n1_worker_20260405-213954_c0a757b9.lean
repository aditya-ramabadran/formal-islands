/-
Weighted L² inequality (Heisenberg uncertainty principle), d = 1 case.

The general inequality states:
  ‖f‖² ≤ (2/d) ‖x f‖₂ ‖∇f‖₂.

For d = 1, this specialises to:
  ∫ ‖f(x)‖² dx  ≤  2 · √(∫ x²‖f(x)‖² dx) · √(∫ ‖f'(x)‖² dx).

The proof begins with the integration-by-parts identity
  ∫ |f|² = −2 Re ∫ x f'(x) conj(f(x)) dx,
which is taken as a hypothesis (it requires regularity and decay at infinity).
The remainder is a chain of standard inequalities:
|Re z| ≤ |z|, triangle inequality for integrals, and Cauchy–Schwarz.
-/
import Mathlib

open MeasureTheory Complex Real

noncomputable section

/-! ### Helper: Cauchy–Schwarz for the product of two nonneg L² functions -/

/-
Cauchy–Schwarz for integrals of nonneg functions:
    ∫ g * h ≤ √(∫ g²) * √(∫ h²)  when g, h ≥ 0.
-/
lemma integral_mul_le_sqrt_mul_sqrt
    {g h : ℝ → ℝ}
    (hg : ∀ x, 0 ≤ g x)
    (hh : ∀ x, 0 ≤ h x)
    (hg_sq : Integrable (fun x => g x ^ 2) volume)
    (hh_sq : Integrable (fun x => h x ^ 2) volume)
    (hgh : Integrable (fun x => g x * h x) volume) :
    ∫ x, g x * h x ≤
      Real.sqrt (∫ x, g x ^ 2) * Real.sqrt (∫ x, h x ^ 2) := by
  rw [ ← Real.sqrt_mul ( MeasureTheory.integral_nonneg fun _ ↦ sq_nonneg _ ) ];
  refine' Real.le_sqrt_of_sq_le _;
  -- By the properties of the integral, we can write
  have h_eq : ∫ x, (g x - (∫ x, g x * h x ∂volume) / (∫ x, h x ^ 2 ∂volume) * h x) ^ 2 ∂volume ≥ 0 := by
    exact MeasureTheory.integral_nonneg fun x => sq_nonneg _;
  by_cases h : ∫ x : ℝ, h x ^ 2 = 0 <;> simp_all +decide [ sub_sq, mul_pow ];
  · rw [ MeasureTheory.integral_eq_zero_iff_of_nonneg ( fun x => sq_nonneg _ ) ] at h;
    · exact MeasureTheory.integral_eq_zero_of_ae ( h.mono fun x hx => by aesop );
    · exact hh_sq;
  · rw [ MeasureTheory.integral_add, MeasureTheory.integral_sub ] at h_eq;
    · simp_all +decide [ mul_assoc, mul_comm, mul_left_comm, MeasureTheory.integral_const_mul, MeasureTheory.integral_mul_const ];
      simp_all +decide [ ← mul_assoc, MeasureTheory.integral_mul_const ];
      nlinarith [ mul_div_cancel₀ ( ∫ x, g x * ‹ℝ → ℝ› x ) h, show 0 ≤ ∫ x, g x ^ 2 from MeasureTheory.integral_nonneg fun _ => sq_nonneg _, show 0 ≤ ∫ x, ‹ℝ → ℝ› x ^ 2 from MeasureTheory.integral_nonneg fun _ => sq_nonneg _ ];
    · exact hg_sq;
    · convert hgh.mul_const ( 2 * ( ( ∫ x, g x * ‹ℝ → ℝ› x ) / ∫ x, ‹ℝ → ℝ› x ^ 2 ) ) using 2 ; ring;
    · refine' MeasureTheory.Integrable.sub hg_sq _;
      convert hgh.mul_const ( 2 * ( ( ∫ x, g x * ‹ℝ → ℝ› x ) / ∫ x, ‹ℝ → ℝ› x ^ 2 ) ) using 2 ; ring;
    · exact hh_sq.const_mul _

/-! ### Main theorem -/

/-
**Weighted L² inequality** (Heisenberg uncertainty principle, d = 1).

Under the stated regularity and decay assumptions (encapsulated in the
integration-by-parts hypothesis `hIBP`), one has

  ∫ ‖f(x)‖² dx  ≤  2 · √(∫ x² ‖f(x)‖² dx) · √(∫ ‖f'(x)‖² dx).

This is the d = 1 specialisation of
  ‖f‖² ≤ (2/d) ‖x f‖₂ ‖∇f‖₂.
-/
theorem n1_aristotle
    (f f' : ℝ → ℂ)
    -- Integrability hypotheses
    (hf_sq : Integrable (fun x : ℝ => ‖f x‖ ^ 2) volume)
    (hxf_sq : Integrable (fun x : ℝ => x ^ 2 * ‖f x‖ ^ 2) volume)
    (hf'_sq : Integrable (fun x : ℝ => ‖f' x‖ ^ 2) volume)
    (h_int : Integrable (fun x : ℝ => (↑x : ℂ) * f' x * starRingEnd ℂ (f x)) volume)
    (h_prod_int : Integrable (fun x : ℝ => |x| * ‖f x‖ * ‖f' x‖) volume)
    -- Integration-by-parts identity (the analytic core)
    (hIBP : ∫ x : ℝ, ‖f x‖ ^ 2 =
      -2 * (∫ x : ℝ, (↑x : ℂ) * f' x * starRingEnd ℂ (f x)).re) :
    -- Conclusion: the weighted L² inequality
    (∫ x : ℝ, ‖f x‖ ^ 2) ≤
      2 * Real.sqrt (∫ x : ℝ, x ^ 2 * ‖f x‖ ^ 2) *
        Real.sqrt (∫ x : ℝ, ‖f' x‖ ^ 2) := by
  -- Applying the helper `integral_mul_le_sqrt_mul_sqrt` with g(x) = |x| * ‖f x‖ and h(x) = ‖f' x‖:
  have h_cauchy_schwarz : ∫ x, |x| * ‖f x‖ * ‖f' x‖ ≤ Real.sqrt (∫ x, x^2 * ‖f x‖^2) * Real.sqrt (∫ x, ‖f' x‖^2) := by
    convert integral_mul_le_sqrt_mul_sqrt ( fun x => ?_ ) ( fun x => ?_ ) ( ?_ ) ( ?_ ) ( ?_ ) using 3 <;> norm_num [ mul_pow ];
    · positivity;
    · exact hxf_sq;
    · exact hf'_sq;
    · exact h_prod_int;
  -- Since $|Re(z)| \leq |z|$ for any complex number $z$, we have:
  have h_re_le_abs : |(∫ x, x * f' x * (starRingEnd ℂ) (f x)).re| ≤ ∫ x, |x| * ‖f x‖ * ‖f' x‖ := by
    refine' le_trans ( Complex.abs_re_le_norm _ ) ( MeasureTheory.norm_integral_le_integral_norm _ ) |> le_trans <| le_of_eq _;
    norm_num [ mul_assoc, mul_comm, mul_left_comm ];
  linarith [ abs_le.mp h_re_le_abs ]

end