# Summary of changes
The Bernoulli scalar inequality (Pinsker bound for binary distributions) is fully formalized and verified in:

- `FormalIslands/Generated/bernoulli_ineq_worker_20260405-220409_91c26eb8.lean` (and identical copy at `FormalIslands/Generated/BernoulliIneq.lean`)

The file contains a complete, sorry-free proof of:

**Main theorem** (`bernoulli_ineq_aristotle`): For all p, q ∈ (0,1),
  p · log(p/q) + (1-p) · log((1-p)/(1-q)) ≥ 2·(p-q)²

The proof follows the informal proof sketch exactly, formalizing all components:

1. **Setup** (`bernstein_F`): Defines F_q(p) = p·log(p/q) + (1-p)·log((1-p)/(1-q)) - 2·(p-q)²
2. **Value at p=q** (`bernstein_F_self`): F_q(q) = 0
3. **First derivative** (`bernstein_F_hasDerivAt`): F_q'(p) = log(p/q) - log((1-p)/(1-q)) - 4(p-q)
4. **Critical point** (`bernstein_F_deriv_self`): F_q'(q) = 0
5. **Convexity** (`bernstein_F_convexOn`): F_q is convex on (0,1), proved via F_q''(p) = 1/(p(1-p)) - 4 ≥ 0 using the AM-GM bound p(1-p) ≤ 1/4 (`mul_one_sub_le_quarter`)
6. **Nonnegativity** (`bernstein_F_nonneg`): F_q(p) ≥ 0 for all p,q ∈ (0,1), combining convexity with the critical point being a global minimum

The proof compiles cleanly with `lake build` and uses only standard axioms (propext, Classical.choice, Quot.sound). The lean-toolchain was corrected from v4.29.0 to v4.28.0 to match the installed Mathlib version.