/-
Data-processing inequality for KL divergence.

Let P, Q be probability measures on (X, F) with P ≪ Q, and let T : (X, F) → (Y, G) be
measurable. Then D_KL(P ‖ Q) ≥ D_KL(T_# P ‖ T_# Q).

This is a direct consequence of the conditional Jensen inequality applied to the convex
function `klFun`. The result is available in Mathlib as `klDiv_comp_le`.
-/
import Mathlib

open MeasureTheory InformationTheory MeasureTheory.Measure

variable {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]

/-- **Data-Processing Inequality for KL Divergence.**
Let `P` and `Q` be finite measures on `(X, 𝓕)` with `P ≪ Q`, and let
`T : (X, 𝓕) → (Y, 𝓖)` be a measurable map. Then the KL divergence does not increase
under the pushforward by `T`:

  `klDiv (T_# P) (T_# Q) ≤ klDiv P Q`

Equivalently, `D_KL(P ‖ Q) ≥ D_KL(T_# P ‖ T_# Q)`.

The proof uses the chain rule for KL divergence: by decomposing the original divergence
into the divergence of the pushforwards plus a nonneg conditional KL term,
`D_KL(P ‖ Q) = D_KL(T_# P ‖ T_# Q) + E_{T_# P}[D_KL(P(· | T) ‖ Q(· | T))]`,
the inequality follows from nonnegativity of the conditional KL divergence.

Applied with `T = 𝟙_A` (indicator of a measurable set), this shows that passing to a
binary observation cannot increase relative entropy — the key reduction step in the
proof of Pinsker's inequality. -/
theorem dpi_aristotle
    (P Q : Measure X) [IsFiniteMeasure P] [IsFiniteMeasure Q]
    (hac : P ≪ Q)
    (T : X → Y) (hT : Measurable T) :
    klDiv (P.map T) (Q.map T) ≤ klDiv P Q :=
  klDiv_comp_le hac hT
