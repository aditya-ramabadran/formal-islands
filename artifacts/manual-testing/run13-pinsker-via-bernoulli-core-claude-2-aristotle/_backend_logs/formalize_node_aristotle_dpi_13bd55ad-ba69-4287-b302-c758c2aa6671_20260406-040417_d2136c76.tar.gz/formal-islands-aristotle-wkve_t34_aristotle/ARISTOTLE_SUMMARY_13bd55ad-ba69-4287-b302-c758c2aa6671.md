# Summary of changes
## Data-Processing Inequality for KL Divergence

I formalized the Data-Processing Inequality (DPI) for KL divergence in the file `FormalIslands/Generated/dpi_worker_20260405-220409_8f35b71a.lean`.

### Main Theorem

```lean
theorem dpi_aristotle
    (μ ν : Measure α) [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (hac : μ ≪ ν)
    (T : α → β) (hT : Measurable T) :
    klDiv (μ.map T) (ν.map T) ≤ klDiv μ ν
```

This states that for finite measures μ ≪ ν and a measurable map T, the KL divergence does not increase under pushforward: D_KL(T_#μ ‖ T_#ν) ≤ D_KL(μ ‖ ν).

### Proof Structure

The proof uses the f-divergence (klFun) characterization of KL divergence and reduces to showing a lintegral comparison. Seven helper lemmas are fully proved:

1. **`lintegral_rnDeriv_map_comp_mul_eq`** — The ENNReal integral identity showing that the rnDeriv of the pushforward, composed with T, satisfies the conditional expectation property.

2. **`klFun_le_add_deriv`** — The subgradient inequality for klFun at c > 0.

3. **`rnDeriv_eq_zero_of_map_rnDeriv_eq_zero`** — Where the pushforward rnDeriv vanishes, the original rnDeriv also vanishes ν-a.e.

4. **`mul_log_sub_mul_log_ge`** — The pointwise bound t·log(t) - t·log(c) ≥ t - c for t ≥ 0, c > 0.

5. **`integral_toReal_rnDeriv_eq_integral_toReal_rnDeriv_map_comp`** — Both ∫ f dν and ∫ g∘T dν equal μ(univ).

6. **`integral_mul_toReal_rnDeriv_eq_integral_mul_toReal_rnDeriv_map_comp`** — The ℝ-valued integral identity: ∫ h∘T · f dν = ∫ h∘T · g∘T dν.

7. **`bregman_nonneg_ae`** — The Bregman divergence of x·log(x) is nonneg ν-a.e.

### Remaining Gap

The file contains **one sorry** in `lintegral_klFun_map_le`, which states the lintegral comparison ∫⁻ klFun(rnDeriv_pushforward) d(ν.map T) ≤ ∫⁻ klFun(rnDeriv) dν. This encodes the conditional Jensen inequality for the convex function klFun. All mathematical ingredients for this step are proved (subgradient inequality, integral identity, Bregman nonnegativity), but the final assembly requires establishing integrability of klFun composed with the pushforward rnDeriv from integrability of klFun composed with the original rnDeriv — which is itself a consequence of conditional Jensen's inequality, creating a circularity that requires building conditional expectation infrastructure not currently available in Mathlib.

The main theorem `dpi_aristotle` is fully proved assuming `lintegral_klFun_map_le`, with the reduction via `klDiv_eq_lintegral_klFun` being clean and complete.

### Technical Notes
- Fixed `lean-toolchain` from v4.29.0 to v4.28.0 to match the pre-built Mathlib oleans.
- Added the generated file to `FormalIslands.lean` imports.