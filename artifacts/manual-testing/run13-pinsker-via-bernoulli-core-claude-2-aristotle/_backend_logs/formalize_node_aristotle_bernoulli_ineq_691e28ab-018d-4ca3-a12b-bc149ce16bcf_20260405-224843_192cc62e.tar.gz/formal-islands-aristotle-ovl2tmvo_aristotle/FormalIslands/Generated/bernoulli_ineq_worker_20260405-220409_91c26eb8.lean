import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

open Real Set

/-- p * (1 - p) ≤ 1/4 for all real p. Follows from (2p - 1)² ≥ 0. -/
lemma mul_one_sub_le_quarter (p : ℝ) : p * (1 - p) ≤ 1 / 4 := by
  nlinarith [sq_nonneg (2 * p - 1)]

/-- 1 / (p * (1 - p)) ≥ 4 for p ∈ (0, 1). -/
lemma inv_mul_one_sub_ge_four {p : ℝ} (hp0 : 0 < p) (hp1 : p < 1) :
    4 ≤ 1 / (p * (1 - p)) := by
  rw [le_div_iff₀ (mul_pos hp0 (by linarith))]
  linarith [mul_one_sub_le_quarter p]

/-- The function whose nonnegativity we establish:
  F_q(p) = p * log(p/q) + (1-p) * log((1-p)/(1-q)) - 2*(p-q)² -/
noncomputable def bernstein_F (q : ℝ) (p : ℝ) : ℝ :=
  p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

/-
bernstein_F q q = 0, since log(1) = 0
-/
lemma bernstein_F_self (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    bernstein_F q q = 0 := by
  unfold bernstein_F; norm_num [ hq0.ne', hq1.ne' ] ;

/-
bernstein_F q is convex on (0, 1).
    The second derivative is 1/(p(1-p)) - 4 ≥ 0 by the AM-GM bound p(1-p) ≤ 1/4.
-/
lemma bernstein_F_convexOn (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    ConvexOn ℝ (Ioo 0 1) (bernstein_F q) := by
  apply_rules [ convexOn_of_deriv2_nonneg', convex_Ioo ];
  · refine' DifferentiableOn.sub _ _;
    · exact DifferentiableOn.add ( DifferentiableOn.mul differentiableOn_id ( DifferentiableOn.log ( differentiableOn_id.div_const _ ) fun x hx => ne_of_gt ( div_pos hx.1 hq0 ) ) ) ( DifferentiableOn.mul ( differentiableOn_id.const_sub _ ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ |> DifferentiableOn.div_const <| _ ) fun x hx => ne_of_gt ( div_pos ( sub_pos.mpr hx.2 ) ( sub_pos.mpr hq1 ) ) ) );
    · exact Differentiable.differentiableOn ( by norm_num );
  · -- Let's calculate the first derivative of $F_q(p)$.
    have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (bernstein_F q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
      intro p hp;
      refine' HasDerivAt.deriv _;
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' p ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p ) q ) ?_ ) ) ( HasDerivAt.mul ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) ?_ ) ) ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 ( p - q ) |> HasDerivAt.comp p <| hasDerivAt_id' p |> HasDerivAt.sub <| hasDerivAt_const _ _ ) ) using 1 <;> norm_num [ hp.1.ne', hp.2.ne', hq0.ne', hq1.ne' ] ; ring!;
      · grind;
      · exact ⟨ by linarith [ hp.1, hp.2 ], by linarith [ hp.1, hp.2 ] ⟩;
    exact DifferentiableOn.congr ( by exact DifferentiableOn.sub ( DifferentiableOn.sub ( DifferentiableOn.log ( differentiableOn_id.div_const _ ) ( by intro x hx; exact ne_of_gt ( div_pos hx.1 hq0 ) ) ) ( DifferentiableOn.log ( differentiableOn_id.const_sub _ |> DifferentiableOn.div_const <| _ ) ( by intro x hx; exact ne_of_gt ( div_pos ( sub_pos.mpr hx.2 ) ( sub_pos.mpr hq1 ) ) ) ) ) ( DifferentiableOn.mul ( differentiableOn_const _ ) ( differentiableOn_id.sub_const _ ) ) ) h_deriv;
  · -- Let's calculate the first derivative of $F_q(p)$.
    have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (bernstein_F q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
      intro p hp;
      refine' HasDerivAt.deriv _;
      convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' p ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p ) q ) ?_ ) ) ( HasDerivAt.mul ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) ?_ ) ) ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( hasDerivAt_pow 2 ( p - q ) |> HasDerivAt.comp p <| hasDerivAt_id' p |> HasDerivAt.sub <| hasDerivAt_const _ _ ) ) using 1 <;> norm_num [ hp.1.ne', hp.2.ne', hq0.ne', hq1.ne' ] ; ring!;
      · grind;
      · exact ⟨ by linarith [ hp.1, hp.2 ], by linarith [ hp.1, hp.2 ] ⟩;
    -- Let's calculate the second derivative of $F_q(p)$.
    have h_deriv2 : ∀ p ∈ Set.Ioo 0 1, deriv^[2] (bernstein_F q) p = (1 / p) + (1 / (1 - p)) - 4 := by
      intro p hp; refine' HasDerivAt.deriv _ ; convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hp.1 hp.2 ) h_deriv ) using 1 ;
      convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p ) q ) <| ne_of_gt <| div_pos hp.1 hq0 ) <| HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) <| ne_of_gt <| div_pos ( sub_pos.2 hp.2 ) <| sub_pos.2 hq1 ) <| HasDerivAt.const_mul 4 <| hasDerivAt_id' p |> HasDerivAt.sub <| hasDerivAt_const _ _ using 1 ; norm_num ; ring;
      grind;
    exact fun x hx => h_deriv2 x hx ▸ by rw [ div_add_div, div_sub', le_div_iff₀ ] <;> nlinarith [ hx.1, hx.2, sq_nonneg ( x - 1 / 2 ) ] ;

/-
The derivative of bernstein_F q at p is
    log(p/q) - log((1-p)/(1-q)) - 4*(p-q)
-/
lemma bernstein_F_hasDerivAt (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (p : ℝ) (hp0 : 0 < p) (hp1 : p < 1) :
    HasDerivAt (bernstein_F q) (log (p / q) - log ((1 - p) / (1 - q)) - 4 * (p - q)) p := by
  convert HasDerivAt.sub ( HasDerivAt.add ( HasDerivAt.mul ( hasDerivAt_id' _ ) ( HasDerivAt.log ( hasDerivAt_deriv_iff.mpr _ ) _ ) ) ( HasDerivAt.mul ( hasDerivAt_id' _ |> HasDerivAt.const_sub _ ) ( HasDerivAt.log ( hasDerivAt_deriv_iff.mpr _ ) _ ) ) ) ( HasDerivAt.mul ( hasDerivAt_const _ _ ) ( hasDerivAt_deriv_iff.mpr _ ) ) using 1 <;> norm_num;
  · erw [ deriv_sub ] <;> norm_num ; ring;
    grind;
  · grind +revert;
  · fun_prop;
  · exact ⟨ by linarith, by linarith ⟩

/-
The derivative of bernstein_F q at p = q is 0
-/
lemma bernstein_F_deriv_at_q (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    HasDerivAt (bernstein_F q) 0 q := by
  convert bernstein_F_hasDerivAt q hq0 hq1 q hq0 hq1 using 1 ; ring;
  grind +splitImp

/-
bernstein_F q p ≥ 0 for all p ∈ (0,1).
    Since bernstein_F q is convex, has value 0 at q, and derivative 0 at q,
    q is a global minimizer, so bernstein_F q p ≥ 0.
-/
lemma bernstein_F_nonneg (p q : ℝ) (hp0 : 0 < p) (hp1 : p < 1)
    (hq0 : 0 < q) (hq1 : q < 1) :
    0 ≤ bernstein_F q p := by
  by_cases hpq : p = q;
  · unfold bernstein_F; aesop;
  · cases lt_or_gt_of_ne hpq;
    · have := ConvexOn.slope_le_of_hasDerivAt ( bernstein_F_convexOn q hq0 hq1 ) ⟨ hp0, hp1 ⟩ ⟨ hq0, hq1 ⟩ ‹_› ( bernstein_F_deriv_at_q q hq0 hq1 );
      rw [ slope ] at this;
      simp_all +decide [ bernstein_F_self ];
    · have := ConvexOn.deriv_le_slope ( bernstein_F_convexOn q hq0 hq1 ) ( show q ∈ Set.Ioo 0 1 from ⟨ hq0, hq1 ⟩ ) ( show p ∈ Set.Ioo 0 1 from ⟨ hp0, hp1 ⟩ ) ‹_›;
      contrapose! this;
      exact ⟨ HasDerivAt.differentiableAt ( bernstein_F_deriv_at_q q hq0 hq1 ), by rw [ slope_def_field ] ; rw [ bernstein_F_deriv_at_q q hq0 hq1 |> HasDerivAt.deriv ] ; rw [ div_lt_iff₀ ] <;> nlinarith [ bernstein_F_self q hq0 hq1 ] ⟩

/-- **Bernoulli scalar inequality (Pinsker bound for binary distributions)**:
    For all p, q ∈ (0,1),
    p * log(p/q) + (1-p) * log((1-p)/(1-q)) ≥ 2 * (p-q)². -/
theorem bernoulli_ineq_aristotle (p q : ℝ) (hp0 : 0 < p) (hp1 : p < 1)
    (hq0 : 0 < q) (hq1 : q < 1) :
    p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) ≥ 2 * (p - q) ^ 2 := by
  have h := bernstein_F_nonneg p q hp0 hp1 hq0 hq1
  simp only [bernstein_F] at h
  linarith