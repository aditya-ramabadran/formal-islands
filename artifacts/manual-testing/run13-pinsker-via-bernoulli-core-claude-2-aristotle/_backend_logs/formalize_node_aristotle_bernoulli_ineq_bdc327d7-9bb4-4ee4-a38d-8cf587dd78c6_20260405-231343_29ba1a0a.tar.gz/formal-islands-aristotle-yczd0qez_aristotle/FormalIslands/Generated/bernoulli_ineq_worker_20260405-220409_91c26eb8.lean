import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

open Real Set

/-- p * (1 - p) ≤ 1/4 for all real p. Follows from (2p - 1)² ≥ 0. -/
lemma mul_one_sub_le_quarter (p : ℝ) : p * (1 - p) ≤ 1 / 4 := by
  nlinarith [sq_nonneg (2 * p - 1)]

/-- The function whose nonnegativity we establish:
  F_q(p) = p * log(p/q) + (1-p) * log((1-p)/(1-q)) - 2*(p-q)² -/
noncomputable def bernstein_F (q : ℝ) (p : ℝ) : ℝ :=
  p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) - 2 * (p - q) ^ 2

lemma bernstein_F_self (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    bernstein_F q q = 0 := by
  unfold bernstein_F
  simp [div_self (ne_of_gt hq0), div_self (ne_of_gt (sub_pos.mpr hq1))]

lemma bernstein_F_hasDerivAt (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1)
    (p : ℝ) (hp0 : 0 < p) (hp1 : p < 1) :
    HasDerivAt (bernstein_F q)
      (log (p / q) - log ((1 - p) / (1 - q)) - 4 * (p - q)) p := by
  have h_deriv : HasDerivAt (fun p => p * Real.log (p / q)) (Real.log (p / q) + 1) p := by
    convert HasDerivAt.mul ( hasDerivAt_id p ) ( HasDerivAt.log ( hasDerivAt_id p |> HasDerivAt.div_const <| q ) _ ) using 1 <;> ring <;> norm_num [ hp0.ne', hq0.ne' ];
    grind;
  have h_deriv2 : HasDerivAt (fun p => (1 - p) * Real.log ((1 - p) / (1 - q))) (-Real.log ((1 - p) / (1 - q)) - 1) p := by
    convert HasDerivAt.mul ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) _ ) _ ) using 1 <;> norm_num;
    · grind;
    · exact ⟨ by linarith, by linarith ⟩;
  convert HasDerivAt.sub ( HasDerivAt.add h_deriv h_deriv2 ) ( HasDerivAt.const_mul 2 ( hasDerivAt_pow 2 ( p - q ) |> HasDerivAt.comp p <| hasDerivAt_id p |> HasDerivAt.sub <| hasDerivAt_const _ q ) ) using 1 ; ring!

lemma bernstein_F_deriv_self (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    HasDerivAt (bernstein_F q) 0 q := by
  have h := bernstein_F_hasDerivAt q hq0 hq1 q hq0 hq1
  simp [div_self (ne_of_gt hq0), div_self (ne_of_gt (sub_pos.mpr hq1))] at h
  exact h

lemma bernstein_F_convexOn (q : ℝ) (hq0 : 0 < q) (hq1 : q < 1) :
    ConvexOn ℝ (Ioo 0 1) (bernstein_F q) := by
  apply_rules [ convexOn_of_deriv2_nonneg', convex_Ioo ];
  · exact fun x hx ↦ DifferentiableAt.differentiableWithinAt ( by exact HasDerivAt.differentiableAt ( bernstein_F_hasDerivAt q hq0 hq1 x hx.1 hx.2 ) ) ;
  · -- Let's calculate the first derivative of $F_q(p)$.
    have h_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (bernstein_F q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
      intro p hp; exact HasDerivAt.deriv ( bernstein_F_hasDerivAt q hq0 hq1 p hp.1 hp.2 ) ;
    exact DifferentiableOn.congr ( fun p hp => DifferentiableAt.differentiableWithinAt <| by exact DifferentiableAt.sub ( DifferentiableAt.sub ( DifferentiableAt.log ( differentiableAt_id.div_const _ ) <| ne_of_gt <| div_pos hp.1 hq0 ) <| DifferentiableAt.log ( DifferentiableAt.div ( differentiableAt_id.const_sub _ ) ( differentiableAt_const _ ) <| by linarith ) <| ne_of_gt <| div_pos ( by linarith [ hp.2 ] ) <| by linarith ) <| DifferentiableAt.mul ( differentiableAt_const _ ) <| differentiableAt_id.sub_const _ ) h_deriv;
  · -- Let's calculate the second derivative of $F_q(p)$.
    have h_second_deriv : ∀ p ∈ Set.Ioo 0 1, deriv^[2] (bernstein_F q) p = 1 / p + 1 / (1 - p) - 4 := by
      -- Let's calculate the first derivative of $F_q(p)$.
      have h_first_deriv : ∀ p ∈ Set.Ioo 0 1, deriv (bernstein_F q) p = Real.log (p / q) - Real.log ((1 - p) / (1 - q)) - 4 * (p - q) := by
        intro p hp; exact HasDerivAt.deriv ( bernstein_F_hasDerivAt q hq0 hq1 p hp.1 hp.2 ) ;
      intro p hp; refine' HasDerivAt.deriv _;
      convert HasDerivAt.congr_of_eventuallyEq _ ( Filter.eventuallyEq_of_mem ( Ioo_mem_nhds hp.1 hp.2 ) h_first_deriv ) using 1;
      convert HasDerivAt.sub ( HasDerivAt.sub ( HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p ) q ) <| ne_of_gt <| div_pos hp.1 hq0 ) <| HasDerivAt.log ( HasDerivAt.div_const ( hasDerivAt_id' p |> HasDerivAt.const_sub 1 ) ( 1 - q ) ) <| ne_of_gt <| div_pos ( sub_pos.2 hp.2 ) <| sub_pos.2 hq1 ) <| HasDerivAt.const_mul 4 <| HasDerivAt.sub ( hasDerivAt_id' p ) <| hasDerivAt_const _ _ using 1 ; ring!;
      grind;
    exact fun x hx => h_second_deriv x hx ▸ sub_nonneg.2 ( by rw [ div_add_div, le_div_iff₀ ] <;> nlinarith [ hx.1, hx.2, sq_nonneg ( 2 * x - 1 ) ] )

lemma bernstein_F_nonneg (p q : ℝ) (hp0 : 0 < p) (hp1 : p < 1)
    (hq0 : 0 < q) (hq1 : q < 1) :
    0 ≤ bernstein_F q p := by
  by_contra! h_contra;
  -- Since $q$ is the point where the derivative of $F_q$ is zero, and $F_q$ is convex, we have $F_q(p) \geq F_q(q) + F_q'(q)(p - q)$.
  have h_convex : ∀ p ∈ Set.Ioo 0 1, bernstein_F q p ≥ bernstein_F q q + (deriv (bernstein_F q) q) * (p - q) := by
    have h_convex : ConvexOn ℝ (Set.Ioo 0 1) (bernstein_F q) := by
      exact?;
    intros p hp; have := h_convex.2 ( show 0 < q ∧ q < 1 from ⟨ by linarith, by linarith ⟩ ) hp; simp_all +decide [ sub_eq_iff_eq_add ] ;
    -- Apply the definition of the derivative to get the inequality.
    have h_deriv : Filter.Tendsto (fun t => (bernstein_F q (q + t * (p - q)) - bernstein_F q q) / t) (nhdsWithin 0 (Set.Ioi 0)) (nhds (deriv (bernstein_F q) q * (p - q))) := by
      have h_deriv : HasDerivAt (fun t => bernstein_F q (q + t * (p - q))) (deriv (bernstein_F q) q * (p - q)) 0 := by
        convert HasDerivAt.comp 0 ( show HasDerivAt ( fun x => bernstein_F q x ) _ _ from hasDerivAt_deriv_iff.mpr ?_ ) ( HasDerivAt.add ( hasDerivAt_const _ _ ) ( HasDerivAt.mul ( hasDerivAt_id 0 ) ( hasDerivAt_const _ _ ) ) ) using 1 <;> norm_num;
        exact HasDerivAt.differentiableAt ( bernstein_F_deriv_self q hq0 hq1 );
      simpa [ div_eq_inv_mul ] using h_deriv.tendsto_slope_zero_right;
    -- Apply the definition of the derivative to get the inequality for $t > 0$.
    have h_deriv_pos : ∀ᶠ t in nhdsWithin 0 (Set.Ioi 0), (bernstein_F q (q + t * (p - q)) - bernstein_F q q) / t ≤ bernstein_F q p - bernstein_F q q := by
      filter_upwards [ Ioo_mem_nhdsGT_of_mem ⟨ le_rfl, zero_lt_one ⟩ ] with t ht using by have := @this ( 1 - t ) t ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ( by linarith [ ht.1, ht.2 ] ) ; rw [ div_le_iff₀ ht.1 ] ; ring_nf at *; linarith;
    exact le_of_tendsto h_deriv h_deriv_pos |> fun h => by linarith;
  specialize h_convex p ⟨ hp0, hp1 ⟩ ; rw [ show deriv ( bernstein_F q ) q = 0 from HasDerivAt.deriv ( bernstein_F_deriv_self q hq0 hq1 ) ] at h_convex ; linarith [ bernstein_F_self q hq0 hq1 ] ;

/-- **Bernoulli scalar inequality (Pinsker bound for binary distributions)**:
    For all p, q ∈ (0,1),
    p * log(p/q) + (1-p) * log((1-p)/(1-q)) ≥ 2 * (p-q)². -/
theorem bernoulli_ineq_aristotle (p q : ℝ) (hp0 : 0 < p) (hp1 : p < 1)
    (hq0 : 0 < q) (hq1 : q < 1) :
    p * log (p / q) + (1 - p) * log ((1 - p) / (1 - q)) ≥ 2 * (p - q) ^ 2 := by
  have h := bernstein_F_nonneg p q hp0 hp1 hq0 hq1
  simp only [bernstein_F] at h
  linarith
