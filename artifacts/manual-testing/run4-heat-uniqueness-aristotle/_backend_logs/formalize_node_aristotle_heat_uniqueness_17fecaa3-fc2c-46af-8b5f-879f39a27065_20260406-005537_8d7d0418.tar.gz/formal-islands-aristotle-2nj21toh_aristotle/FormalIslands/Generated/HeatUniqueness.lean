import Mathlib

open MeasureTheory Set intervalIntegral

/-!
# Heat equation uniqueness by the energy method

We formalize the uniqueness theorem for the heat equation via the energy method.
Given `u, v : ℝ → ℝ → ℝ` (functions of space and time) that are solutions to
the heat equation on `[0,L] × [0,T]` with the same initial data and homogeneous
Dirichlet boundary conditions, we prove `u = v`.

The proof sets `w = u - v`, defines the energy `E(t) = ∫₀ᴸ w(x,t)² dx`,
and uses:
1. `E(0) = 0` (from the same initial data),
2. `E(t) ≥ 0` (integral of a square),
3. `E'(t) ≤ 0` (energy dissipation, assumed from the PDE + integration by parts),
4. A verified lemma showing that a nonincreasing nonneg function starting at 0 must vanish,
5. `∫ f² = 0` with `f` continuous implies `f = 0`.
-/

/-
The energy vanishing lemma: a nonneg, nonincreasing, continuous function starting at 0
is identically 0. This is a verified supporting lemma.
-/
theorem heat_uniqueness_refined_local_claim_aristotle
    {T : ℝ} (hT : 0 ≤ T) {E : ℝ → ℝ}
    (hcont : ContinuousOn E (Icc 0 T))
    (hdiff : DifferentiableOn ℝ E (Ioo 0 T))
    (hderiv : ∀ t ∈ Ioo 0 T, deriv E t ≤ 0)
    (hE0 : E 0 = 0)
    (hnneg : ∀ t ∈ Icc 0 T, 0 ≤ E t) :
    ∀ t ∈ Icc 0 T, E t = 0 := by
      intro t ht; by_contra h_contra; simp_all +decide [ lintegral_const ] ;
      -- Apply the mean value theorem to the interval $[0, t]$.
      obtain ⟨c, hc⟩ : ∃ c ∈ Set.Ioo 0 t, deriv E c = (E t - E 0) / (t - 0) := by
        apply_rules [ exists_deriv_eq_slope ];
        · exact ht.1.lt_of_ne ( by aesop );
        · exact hcont.mono ( Set.Icc_subset_Icc le_rfl ht.2 );
        · exact hdiff.mono <| Set.Ioo_subset_Ioo_right ht.2;
      exact h_contra ( by nlinarith [ hderiv c hc.1.1 ( by linarith [ hc.1.2 ] ), hnneg t ht.1 ht.2, mul_div_cancel₀ ( E t - E 0 ) ( sub_ne_zero.2 ( by aesop : t ≠ 0 ) ) ] )

/-
If a continuous function has zero interval integral of its square on `[0, L]` with `L > 0`,
    then the function vanishes on `[0, L]`.
-/
lemma eq_zero_of_sq_interval_integral_zero {L : ℝ} (hL : 0 < L)
    {f : ℝ → ℝ} (hf_cont : Continuous f)
    (hf_int : IntervalIntegrable (fun x => f x ^ 2) volume 0 L)
    (hf_zero : ∫ x in (0:ℝ)..L, f x ^ 2 = 0) :
    ∀ x ∈ Icc 0 L, f x = 0 := by
      -- By `integral_eq_zero_iff_of_le_of_nonneg_ae`, f² =ᵐ[volume.restrict (Ioc 0 L)] 0.
      have h_ae_zero : f^2 =ᵐ[volume.restrict (Ioc 0 L)] 0 := by
        rw [ intervalIntegral.integral_of_le hL.le ] at hf_zero;
        rw [ MeasureTheory.integral_eq_zero_iff_of_nonneg ( fun x => sq_nonneg _ ) ] at hf_zero ; aesop;
        exact hf_int.1;
      -- Since $f$ is continuous on $[0, L]$, if $f$ were non-zero at some point in $[0, L]$, then there would be an open interval around that point where $f$ is non-zero.
      have h_cont_zero : ∀ x ∈ Set.Icc 0 L, f x = 0 := by
        intro x hx
        by_contra h_nonzero
        obtain ⟨ε, hε⟩ : ∃ ε > 0, ∀ y ∈ Metric.ball x ε, f y ≠ 0 := by
          exact Metric.mem_nhds_iff.mp ( hf_cont.continuousAt.eventually_ne h_nonzero )
        rw [ Filter.EventuallyEq, MeasureTheory.ae_restrict_iff' ] at h_ae_zero <;> simp_all +decide [ Filter.EventuallyEq ];
        rw [ MeasureTheory.ae_iff ] at h_ae_zero; contrapose! h_ae_zero; simp_all +decide [ Filter.eventually_inf_principal ] ;
        -- Since $f$ is non-zero on the interval $(x - \epsilon, x + \epsilon)$, the measure of this interval is positive.
        have h_pos_measure : 0 < MeasureTheory.MeasureSpace.volume (Set.Ioo (max 0 (x - ε)) (min L (x + ε))) := by
          simp +zetaDelta at *;
          exact ⟨ ⟨ hL, by linarith ⟩, by linarith, by linarith ⟩;
        exact ne_of_gt ( lt_of_lt_of_le h_pos_measure ( MeasureTheory.measure_mono fun y hy => ⟨ by cases max_cases 0 ( x - ε ) <;> linarith [ hy.1, hy.2 ], by cases min_cases L ( x + ε ) <;> linarith [ hy.1, hy.2 ], hε.2 y <| abs_lt.2 ⟨ by cases max_cases 0 ( x - ε ) <;> linarith [ hy.1, hy.2 ], by cases min_cases L ( x + ε ) <;> linarith [ hy.1, hy.2 ] ⟩ ⟩ ) );
      assumption

/-- **Heat equation uniqueness by the energy method.**

Given functions `u, v : ℝ → ℝ → ℝ` (of space `x` and time `t`) satisfying:
- the same initial data: `u(x,0) = v(x,0)` for `x ∈ [0,L]`,
- sufficient regularity so that `u - v` is continuous in `x` for each fixed `t`,
- an energy functional `E(t) = ∫₀ᴸ (u(x,t) - v(x,t))² dx` that is continuous on `[0,T]`,
  differentiable on `(0,T)`, and satisfies `E'(t) ≤ 0` (energy dissipation,
  which follows from the heat equation and integration by parts),

we conclude `u(x,t) = v(x,t)` for all `(x,t) ∈ [0,L] × [0,T]`.

The energy dissipation `E'(t) ≤ 0` is assumed as a hypothesis because deriving it from
the PDE requires integration-by-parts machinery not yet available in Mathlib. In the
informal proof, this step is referred to as "the energy dissipation lemma."
-/
theorem heat_uniqueness_aristotle
    {L T : ℝ} (hL : 0 < L) (hT : 0 ≤ T)
    {u v : ℝ → ℝ → ℝ}
    -- Same initial data
    (hinit : ∀ x ∈ Icc 0 L, u x 0 = v x 0)
    -- Continuity of u - v in x for each t (regularity)
    (hcont : ∀ t ∈ Icc 0 T, Continuous (fun x => u x t - v x t))
    -- Energy functional E(t) = ∫₀ᴸ (u(x,t) - v(x,t))² dx
    {E : ℝ → ℝ}
    (hE_def : ∀ t ∈ Icc 0 T, E t = ∫ x in (0:ℝ)..L, (u x t - v x t) ^ 2)
    -- Regularity of E
    (hE_cont : ContinuousOn E (Icc 0 T))
    (hE_diff : DifferentiableOn ℝ E (Ioo 0 T))
    -- Energy dissipation (from the heat equation + integration by parts)
    (hE_dissip : ∀ t ∈ Ioo 0 T, deriv E t ≤ 0)
    -- Integrability
    (hint : ∀ t ∈ Icc 0 T, IntervalIntegrable (fun x => (u x t - v x t) ^ 2) volume 0 L) :
    ∀ x ∈ Icc 0 L, ∀ t ∈ Icc 0 T, u x t = v x t := by
  -- Step 1: E(0) = 0 from same initial data
  have h0T : (0 : ℝ) ∈ Icc 0 T := left_mem_Icc.mpr hT
  have hE0 : E 0 = 0 := by
    rw [hE_def 0 h0T]
    apply intervalIntegral.integral_zero_ae
    filter_upwards with x
    intro hx
    rw [Set.uIoc_of_le (le_of_lt hL)] at hx
    have : x ∈ Icc 0 L := Ioc_subset_Icc_self hx
    rw [hinit x this, sub_self, zero_pow (by norm_num : 2 ≠ 0)]
  -- Step 2: E(t) ≥ 0 for all t (integral of nonneg function)
  have hEnneg : ∀ t ∈ Icc 0 T, 0 ≤ E t := by
    intro t ht
    rw [hE_def t ht]
    exact intervalIntegral.integral_nonneg (le_of_lt hL) (fun x _ => sq_nonneg _)
  -- Step 3: Apply energy vanishing lemma
  have hEzero : ∀ t ∈ Icc 0 T, E t = 0 :=
    heat_uniqueness_refined_local_claim_aristotle hT hE_cont hE_diff hE_dissip hE0 hEnneg
  -- Step 4: Conclude u = v
  intro x hx t ht
  have hEt : ∫ x in (0:ℝ)..L, (u x t - v x t) ^ 2 = 0 := by
    have := hEzero t ht
    rwa [hE_def t ht] at this
  have hw := eq_zero_of_sq_interval_integral_zero hL (hcont t ht) (hint t ht) hEt x hx
  linarith