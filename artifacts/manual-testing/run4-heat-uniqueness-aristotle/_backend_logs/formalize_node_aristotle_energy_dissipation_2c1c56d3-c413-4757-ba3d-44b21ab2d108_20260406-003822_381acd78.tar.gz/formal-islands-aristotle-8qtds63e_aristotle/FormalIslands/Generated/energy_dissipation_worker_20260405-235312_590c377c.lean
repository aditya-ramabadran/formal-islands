import Mathlib

open MeasureTheory Set intervalIntegral

/-!
# Energy dissipation for the heat equation

We formalize the core computation of the energy method for uniqueness of the heat equation.

Given `w` with spatial derivative `w'` and second spatial derivative `w''` on `[0, L]`,
and boundary conditions `w(0) = w(L) = 0`, integration by parts gives:

  ∫₀ᴸ w(x) · w''(x) dx = -∫₀ᴸ (w'(x))² dx ≤ 0

In the energy method for the heat equation, `w = u - v` satisfies `wₜ = w_xx` with
homogeneous Dirichlet boundary conditions. The energy `E(t) = ½∫₀ᴸ w² dx` satisfies
`E'(t) = ∫₀ᴸ w · wₜ dx = ∫₀ᴸ w · w_xx dx` (by differentiation under the integral
and PDE substitution). The result below then gives `E'(t) = -∫₀ᴸ (w_x)² dx ≤ 0`,
proving that the energy is nonincreasing.
-/

/-- **Integration by parts identity with vanishing boundary conditions.**

At a fixed time `t`, let `w` satisfy homogeneous Dirichlet boundary conditions `w(0) = w(L) = 0`
on `[0, L]`, with spatial derivative `w'` and second spatial derivative `w''`. Then

  `∫₀ᴸ w · w'' dx = -∫₀ᴸ (w')² dx`

This is the identity at the heart of the energy method: combined with `E'(t) = ∫ w · w_t`
(differentiation under the integral sign) and the PDE `w_t = w_xx`, it gives
`E'(t) = -∫₀ᴸ (w_x)² dx ≤ 0`, proving energy dissipation. -/
theorem ibp_boundary_vanishing
    (L : ℝ) (_hL : 0 < L)
    (w w' w'' : ℝ → ℝ)
    (hw : ∀ x ∈ Set.uIcc 0 L, HasDerivWithinAt w (w' x) (Set.uIcc 0 L) x)
    (hw' : ∀ x ∈ Set.uIcc 0 L, HasDerivWithinAt w' (w'' x) (Set.uIcc 0 L) x)
    (hw'_int : IntervalIntegrable w' volume 0 L)
    (hw''_int : IntervalIntegrable w'' volume 0 L)
    (hbc0 : w 0 = 0) (hbcL : w L = 0) :
    ∫ x in (0:ℝ)..L, w x * w'' x = -(∫ x in (0:ℝ)..L, w' x ^ 2) := by
  have h_parts : ∫ x in (0:ℝ)..L, w x * w'' x =
      (w L * w' L - w 0 * w' 0) - ∫ x in (0:ℝ)..L, w' x * w' x :=
    integral_mul_deriv_eq_deriv_mul_of_hasDerivWithinAt hw hw' hw'_int hw''_int
  rw [h_parts, hbc0, hbcL]
  simp [sq]

/-- **Energy dissipation for the heat equation (E'(t) ≤ 0).**

Let `w` be a sufficiently regular solution of `wₜ = w_xx` on `(0,L)` with homogeneous
Dirichlet boundary conditions `w(0,t) = w(L,t) = 0`. Define the energy
`E(t) = ½∫₀ᴸ w(x,t)² dx`. Then `E'(t) = -∫₀ᴸ (w_x)² dx ≤ 0`.

This theorem takes as hypotheses the regularity of `w` (differentiability and integrability
of spatial derivatives) and the boundary conditions, and concludes that the energy derivative
(expressed as `∫₀ᴸ w · w_xx dx` after differentiation under the integral and PDE substitution)
is nonpositive. -/
theorem energy_dissipation_aristotle
    (L : ℝ) (hL : 0 < L)
    (w w' w'' : ℝ → ℝ)
    (hw : ∀ x ∈ Set.uIcc 0 L, HasDerivWithinAt w (w' x) (Set.uIcc 0 L) x)
    (hw' : ∀ x ∈ Set.uIcc 0 L, HasDerivWithinAt w' (w'' x) (Set.uIcc 0 L) x)
    (hw'_int : IntervalIntegrable w' volume 0 L)
    (hw''_int : IntervalIntegrable w'' volume 0 L)
    (hbc0 : w 0 = 0) (hbcL : w L = 0) :
    (∫ x in (0:ℝ)..L, w x * w'' x) = -(∫ x in (0:ℝ)..L, w' x ^ 2)
    ∧ (∫ x in (0:ℝ)..L, w x * w'' x) ≤ 0 := by
  refine ⟨ibp_boundary_vanishing L hL w w' w'' hw hw' hw'_int hw''_int hbc0 hbcL, ?_⟩
  rw [ibp_boundary_vanishing L hL w w' w'' hw hw' hw'_int hw''_int hbc0 hbcL]
  have h_nn : 0 ≤ ∫ x in (0:ℝ)..L, w' x ^ 2 :=
    intervalIntegral.integral_nonneg hL.le (fun u _ => sq_nonneg (w' u))
  linarith
