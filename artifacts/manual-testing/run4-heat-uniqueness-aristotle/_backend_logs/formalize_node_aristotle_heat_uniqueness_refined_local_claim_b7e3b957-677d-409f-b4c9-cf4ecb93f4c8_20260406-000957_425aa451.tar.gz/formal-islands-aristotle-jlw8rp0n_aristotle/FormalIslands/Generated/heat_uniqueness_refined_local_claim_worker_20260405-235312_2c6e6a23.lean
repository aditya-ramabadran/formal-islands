import Mathlib

/-!
# Nonincreasing nonneg energy vanishing from zero

Let `E : [0,T] → ℝ` satisfy `E(0) = 0`, `E'(t) ≤ 0` for all `t ∈ [0,T]`, and `E(t) ≥ 0`
for all `t ∈ [0,T]`. Then `E(t) = 0` for all `t ∈ [0,T]`.

This is the key analytic lemma in the energy-method proof of uniqueness for the heat equation:
it converts the energy-dissipation inequality and the zero-initial-data condition into E ≡ 0.
-/

open Set in
/-- **Nonincreasing nonneg energy vanishing from zero.**
Let `E : ℝ → ℝ` be continuous on `[0, T]`, differentiable on `(0, T)`, with `deriv E t ≤ 0`
for all `t ∈ (0, T)`, `E 0 = 0`, and `E t ≥ 0` for all `t ∈ [0, T]`. Then `E t = 0` for all
`t ∈ [0, T]`. -/
theorem heat_uniqueness_refined_local_claim_aristotle
    {T : ℝ} (hT : 0 ≤ T) {E : ℝ → ℝ}
    (hcont : ContinuousOn E (Icc 0 T))
    (hdiff : DifferentiableOn ℝ E (Ioo 0 T))
    (hderiv : ∀ t ∈ Ioo 0 T, deriv E t ≤ 0)
    (hE0 : E 0 = 0)
    (hnneg : ∀ t ∈ Icc 0 T, 0 ≤ E t) :
    ∀ t ∈ Icc 0 T, E t = 0 := by
  -- Because E'(t) ≤ 0 on (0,T), the function E is nonincreasing (antitone) on (0,T) by `antitoneOn_of_deriv_nonpos`.
  have h_antitone : AntitoneOn E (Set.Icc 0 T) := by
    apply_rules [ antitoneOn_of_deriv_nonpos ];
    · exact convex_Icc _ _;
    · aesop;
    · aesop;
  exact fun t ht => le_antisymm ( le_trans ( h_antitone ( show 0 ∈ Set.Icc 0 T by norm_num; linarith ) ht ( by linarith [ ht.1 ] ) ) hE0.le ) ( hnneg t ht )